make pex
run mmmh