make pex
run syouka
