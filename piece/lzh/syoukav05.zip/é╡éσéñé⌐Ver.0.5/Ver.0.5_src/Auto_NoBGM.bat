make -fmakefile_nobgm pex
run syouka