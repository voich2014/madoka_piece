#include <musdef.h>

#include "snd\\i_DEFSND.h"
#include "snd\\i_HANDCLAP.h"
#include "snd\\i_CYMBD.h"
#include "snd\\i_BD909.h"
#include "snd\\i_HC909.h"
#include "snd\\i_HO909.h"
#include "snd\\i_SD909.h"
#include "snd\\i_SDGATE.h"
#include "snd\\i_TOMH1.h"
#include "snd\\i_TOML1.h"
#include "snd\\i_TOMM1.h"

INST *inst[] = {
	(INST*)&i_square0,		// 0
	(INST*)&i_saw0,			// 1
	(INST*)&i_triangle0,	// 2
	(INST*)&i_square,		// 3
	(INST*)&i_saw,			// 4
	(INST*)&i_triangle,		// 5
	(INST*)&i_BD909,		// 6  bdr
	(INST*)&i_SDGATE,		// 7  sdr
	(INST*)&i_SD909,		// 8  rim
	(INST*)&i_HO909,		// 9  ohh
	(INST*)&i_HC909,		// 10 chh
	(INST*)&i_CYMBD,		// 11 ccy
	(INST*)&i_CYMBD,		// 12 rcy
	(INST*)&i_TOMH1,		// 13 htm
	(INST*)&i_TOMM1,		// 14 mtm
	(INST*)&i_TOML1,		// 15 ltm
	(INST*)&i_HANDCLAP,		// 16 hcp
};



