make pex
run mmc_pce
