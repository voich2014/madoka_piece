//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MMC_Comm.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MMC_COMM_DIALOG             102
#define IDS_PIECE_NOREADY               102
#define IDS_CONNECT                     103
#define IDS_DISCONNECT                  104
#define IDS_READY                       105
#define IDS_RECV                        106
#define IDS_SEND                        107
#define IDS_INIT                        108
#define IDR_MAINFRAME                   128
#define ID_EXIT                         1000
#define IDC_FRAME_LOG                   1001
#define IDC_LIST_LOG                    1002
#define IDC_STATIC_STATUS               1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
