make pex
run mp3mmc
