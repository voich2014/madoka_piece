
	.code

	.global	mmcGetInitResult
mmcGetInitResult:
	xld.w	%r9,[%r8+0x20+237*4]
	jp	%r9

