
	.code

	.global	mmcExit
mmcExit:
	xld.w	%r9,[%r8+0x20+225*4]
	jp	%r9

