
	.code

	.global	mmcFileFindNext
mmcFileFindNext:
	xld.w	%r9,[%r8+0x20+228*4]
	jp	%r9

