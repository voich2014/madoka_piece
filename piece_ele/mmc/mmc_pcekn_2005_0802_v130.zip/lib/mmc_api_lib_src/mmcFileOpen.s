
	.code

	.global	mmcFileOpen
mmcFileOpen:
	xld.w	%r9,[%r8+0x20+230*4]
	jp	%r9

