
	.code

	.global	mmcAppExecFile
mmcAppExecFile:
	xld.w	%r9,[%r8+0x20+224*4]
	jp	%r9

