
	.code

	.global	mmcFileClose
mmcFileClose:
	xld.w	%r9,[%r8+0x20+226*4]
	jp	%r9

