
	.code

	.global	mmcFileFindClose
mmcFileFindClose:
	xld.w	%r9,[%r8+0x20+227*4]
	jp	%r9

