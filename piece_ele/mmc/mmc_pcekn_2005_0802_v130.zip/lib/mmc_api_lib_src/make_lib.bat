pcc33 -c -g mmcAppExecFile.s
pcc33 -c -g mmcExit.s
pcc33 -c -g mmcFileClose.s
pcc33 -c -g mmcFileFindClose.s
pcc33 -c -g mmcFileFindNext.s
pcc33 -c -g mmcFileFindOpen.s
pcc33 -c -g mmcFileOpen.s
pcc33 -c -g mmcFileReadMMCSct.s
pcc33 -c -g mmcFileReadSct.s
pcc33 -c -g mmcGetCIDInfo.s
pcc33 -c -g mmcGetCSDInfo.s
pcc33 -c -g mmcInit.s
pcc33 -c -g mmcReadSector.s
pcc33 -c -g mmcGetInitResult.s

del mmc_api.lib

lib33 -a mmc_api.lib mmcAppExecFile.o
lib33 -a mmc_api.lib mmcExit.o
lib33 -a mmc_api.lib mmcFileClose.o
lib33 -a mmc_api.lib mmcFileFindClose.o
lib33 -a mmc_api.lib mmcFileFindNext.o
lib33 -a mmc_api.lib mmcFileFindOpen.o
lib33 -a mmc_api.lib mmcFileOpen.o
lib33 -a mmc_api.lib mmcFileReadMMCSct.o
lib33 -a mmc_api.lib mmcFileReadSct.o
lib33 -a mmc_api.lib mmcGetCIDInfo.o
lib33 -a mmc_api.lib mmcGetCSDInfo.o
lib33 -a mmc_api.lib mmcInit.o
lib33 -a mmc_api.lib mmcReadSector.o
lib33 -a mmc_api.lib mmcGetInitResult.o








