
	.code

	.global	mmcFileFindOpen
mmcFileFindOpen:
	xld.w	%r9,[%r8+0x20+229*4]
	jp	%r9

