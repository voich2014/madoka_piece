
	.code

	.global	mmcGetCIDInfo
mmcGetCIDInfo:
	xld.w	%r9,[%r8+0x20+233*4]
	jp	%r9

