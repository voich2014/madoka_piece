
	.code

	.global	mmcFileReadSct
mmcFileReadSct:
	xld.w	%r9,[%r8+0x20+232*4]
	jp	%r9

