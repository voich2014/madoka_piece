
	.code

	.global	mmcInit
mmcInit:
	xld.w	%r9,[%r8+0x20+235*4]
	jp	%r9

