
	.code

	.global	mmcFileReadMMCSct
mmcFileReadMMCSct:
	xld.w	%r9,[%r8+0x20+231*4]
	jp	%r9

