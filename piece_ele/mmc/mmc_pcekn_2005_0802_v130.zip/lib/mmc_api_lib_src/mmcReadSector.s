
	.code

	.global	mmcReadSector
mmcReadSector:
	xld.w	%r9,[%r8+0x20+236*4]
	jp	%r9

