
	.code

	.global	mmcGetCSDInfo
mmcGetCSDInfo:
	xld.w	%r9,[%r8+0x20+234*4]
	jp	%r9

