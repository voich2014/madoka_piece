
#include <piece.h>
#include <s1c33cpu.h>
#include <piecezl.h>

#define DATATOP 0x102c00
#define WORKS ((void *)0x139000)
#define EXTBUFF ((unsigned char *)0x138000)
#define EXTSIZE 0x0400

// crc32.c
unsigned long calcrc( void *c, unsigned n );
void calcrc_init( void );

unsigned long crc32v;
unsigned long declen;
char nores;

static unsigned short *fwrtp;


#define LEDOFF (*(unsigned char *)0x402d1 |= 0x28)
#define LEDON  (*(unsigned char *)0x402d1 &= 0xd7)
#define LEDREV (*(unsigned char *)0x402d1 |= 0x28)

int flash_erase( volatile unsigned short *sp )
{
	volatile unsigned short *c1p = (unsigned short *)(0xc00000 + 0x5555*2);
	volatile unsigned short *c2p = (unsigned short *)(0xc00000 + 0x2aaa*2);
#if 0
	static void *va[16];
	static int vn = 0;
	va[(vn++)&15] = sp;
	return 0;
#endif
	*c1p = 0xaa;
	*c2p = 0x55;
	*c1p = 0x80;
	*c1p = 0xaa;
	*c2p = 0x55;
	if ( sp == NULL ) {
		*c1p = 0x10;	// 0x10 : chip erase
	}
	else {
		*sp = 0x30;		// 0x30 : sector erase
//		*sp = 0x50;		// 0x50 : block erase
	}

//	LEDON;
	{
		int i;
		for ( i = 0; i < 8; i++ ) {
			unsigned short a;
			int n=100*1000;
			while ( *sp != 0xffff ) {
				if ( --n < 0 ) {
					LEDOFF;
					return 1;
				}
			}
			a = *sp++;
		}
	}
//	LEDOFF;

	return 0;
}



int flash_write( unsigned short *sp, unsigned len )
{
	volatile unsigned short *wp = fwrtp;
	volatile unsigned short *c1p = (unsigned short *)(0xc00000+0x5555*2);
	volatile unsigned short *c2p = (unsigned short *)(0xc00000+0x2aaa*2);

//	LEDON;
	do {
		unsigned short d = *sp++;
		if ( d != 0xffff && d != *wp ) {
			//*c1p = 0xf0;
			*c1p = 0xaa;
			*c2p = 0x55;
			*c1p = 0xa0;
			*wp  = d;
			asm( "nop" );
#if 0
			{
				unsigned short an, ao = *wp;
				while ( 1 ) {
					an = *wp;
					if ( !( ( an ^ ao ) & 0x40 ) ) break;
					ao = an;
				}
			}
#else
			while ( (d ^ *wp) & 0x80 );
#endif
			//*c1p = 0xf0;
		}
		wp++;
	} while ( --len );
//	LEDOFF;

	return 0;
}

#if 0
static int check_same( unsigned short *sp, int len )
{
	unsigned short *wp = fwrtp;

	do {
		if ( *wp++ != *sp++ ) break;
	} while ( --len );

	return len;
}
#else
#define check_same(a,b) 1
#endif

#if 1
static int check_erase( unsigned short *sp )
{
	int len = 0x1000/2;

	do {
		if ( *sp++ != 0xffff ) break;
	} while ( --len );

	return len;
}
#else
#define check_erase(a) 1
#endif

static void DecodeProc0( zlibIO *zi )
{
	int n = zi->ptr - zi->ptr0;

	crc32v = calcrc( zi->ptr0, n );
	declen += n;

	zi->ptr = zi->ptr0;
}


static void DecodeProc1( zlibIO *zi )
{
	int n = zi->ptr - zi->ptr0;

	n >>= 1;

	if ( check_same( (unsigned short *)zi->ptr0, n ) ) {
		if ( ((int)fwrtp & 0xfff) == 0 ) {
			if ( check_erase( fwrtp ) ) {
				flash_erase( fwrtp );
			}
		}
		flash_write( (unsigned short *)zi->ptr0, n );
	}

	fwrtp += n;

	zi->ptr = zi->ptr0;
}

static int dummy( zlibIO *zi )
{
	return 0xff;
}

static void nmi_off( void )
{
	*(volatile unsigned char *)0x40170 = 0x80;
	*(volatile unsigned char *)0x40171 = 0x00;
}


int FlashWrite( int mode )
{
	pffsFileHEADER *pfh = (pffsFileHEADER *)DATATOP;
	unsigned long *datap;
	zlibIO Zin, Zout;
#if 0
	DISABLE;
	datap = (unsigned long *)0xc20000;
	do {
		flash_erase( (unsigned short *)datap );
		datap += 0x1000/4;
	} while ( datap < (unsigned long *)0xc80000 );
	ENABLE;
	return 0;
#endif
	//pceUSBDisconnect();

	if ( pfh->mark != 'X' ) {
		return 2;
	}

	//MMC�Ή��J�[�l��Ver.1.23�ȍ~�p�ɃR�����g�A�E�g
	//nores = ( pfh->top_adrs >= 0xc10000 );

	datap = (unsigned long *)(((unsigned)pfh) + pfh->ofs_data);

	if ( mode == 1 ) {
		calcrc_init();

		Zin.ptr = (unsigned char *)(datap+2);
		Zin.ptre = (unsigned char *)-1;
		Zin.fn.fil = dummy;

		Zout.ptr0 = EXTBUFF;
		Zout.ptr = EXTBUFF;
		Zout.ptre = EXTBUFF + EXTSIZE;
		Zout.fn.fls = DecodeProc0;

		declen = 0;
		pceZlibExpand( &Zin, &Zout, WORKS );

		if ( declen != datap[0] || crc32v != datap[1] ) return 1;

		return 0;
	}

	fwrtp = (unsigned short *)pfh->top_adrs;

	DISABLE;
	LEDOFF;
	nmi_off();


	Zin.ptr = (unsigned char *)(datap+2);
	Zin.ptre = (unsigned char *)-1;
	Zin.fn.fil = dummy;

	Zout.ptr0 = EXTBUFF;
	Zout.ptr = EXTBUFF;
	Zout.ptre = EXTBUFF + EXTSIZE;
	Zout.fn.fls = DecodeProc1;

	pceZlibExpand( &Zin, &Zout, WORKS );

	if ( nores ) {
		ENABLE;
	}
	else {
#if 1
		// �^�����Z�b�g
		asm( "xld.w	%r9,0xc00000");
		asm( "jp	%r9");
#else
		while (1) {
			int i;
			for ( i = 0; i < 1000*66; i++ ) LEDOFF;
			for ( i = 0; i < 1000*33; i++ ) LEDON;
		}
#endif
	}

	return 0;
}



