
#include <stddef.h>
#include "string2.h"
#include "llmemmap.h"

static u_char textbuff[4096];

//#define INIT_D 0



// ---------------------------------------------------------------------------
// LZ77 ��v��=4bit �o�b�t�@��=12bit
//

#define N     4096  /* ��o�b�t�@�̑傫�� */
#define F       18  /* �Œ���v�� */
#define MM       3  /* �ŒZ��v�� */
#define SS	 4  /* �����̃r�b�g�� */


#if 0
typedef u_long redword;
#define ini1b() (dd=((*(redword*)((int)inptr&~3))>>(((int)inptr&3)<<3)))
#define red1b() ((u_char)dd)
#define inc1b() (dd>>=8);if((((int)++inptr)&3)==0)dd=*(redword*)inptr
#else
typedef u_long redword;
#define ini1b() (void)(dd)
#define red1b() (*inptr)
#define inc1b() (inptr++)
#endif


unsigned lz4decode( u_char *inptr, unsigned size, u_char *data )
{
	int i, j, r;
	u_char *p = data, *endptr;
	int flags;
	redword dd;
	u_char *text = textbuff;

	endptr = data + size;

	r = N - F;
	ini1b();
	flags = 0x100;
	while ( 1 ) {
		if ( (flags>>=1) & 0x80 ) {
			flags = 0x8000 + red1b();
			inc1b();
		}
		if ( flags & 1 ) {
			*p++ = text[r++] = red1b();
			if ( p >= endptr ) goto _end;
			inc1b();
			r &= (N - 1);
		}
		else {
			i = red1b();
			inc1b();
			i += ( red1b() << 8 );
			inc1b();
			j = ( i & ((1<<SS)-1) ) + MM;
			i >>= SS;
			do {
				*p++ = text[r++] = text[i++ & (N - 1)];
				if ( p >= endptr ) goto _end;
				r &= (N - 1);
			} while ( --j );
		}
	}
_end:
	return (unsigned)( p - data );
}



// ---------------------------------------------------------------------------
// LZ77 ��v��=7bit �o�b�t�@��=9bit
//

#undef N
#undef F
#undef MM
#undef SS

#define N      512  /* ��o�b�t�@�̑傫�� */
#define F      130  /* �Œ���v�� */
#define MM       3  /* �ŒZ��v�� */
#define SS	 7  /* �����̃r�b�g�� */

//�y�����W�J�Ή��z
// �p���W�J����ꍇ��
// �� inptr = NULL �ŌĂԁB
// �� ����(�X�N���b�`�p�b�h)�͑O��I�����̓��e�̂܂ܕۑ����Ă����B

/*	����	*/


unsigned lz7decode( u_char *inptr, unsigned size, u_char *data )
{
	int i = 0, j = 0, r = 0;
	u_char *p = data, *endptr;
	int flags;
	redword dd = 0;
	u_char *text = (u_char *)LLMEM_LLUNPACKWK;	// �X�N���b�`�p�b�h

	endptr = data + size;

	static int save_i;
	static int save_j;
	static int save_r;
	static redword save_dd;
	static u_char *save_inptr;
	static int save_flags;

	if ( inptr != NULL ) {
		r = N - F;
		ini1b();
		flags = 0x100;
	}
	else {
		r = save_r;
		dd = save_dd;
		inptr = save_inptr;
		flags = save_flags;
		i = save_i;
		j = save_j;
		if ( j ) goto yyy;
		goto xxx;
	}

	while ( 1 ) {
		if ( (flags>>=1) & 0x80 ) {
			flags = 0x8000 + red1b();
			inc1b();
		}
		if ( flags & 1 ) {
			*p++ = text[r++] = red1b();
			if ( p >= endptr ) goto _end;
xxx:			inc1b();
			r &= (N - 1);
		}
		else {
			i = red1b();
			inc1b();
			i += ( red1b() << 8 );
			inc1b();
			j = ( i & ((1<<SS)-1) ) + MM;
			i >>= SS;
			do {
				*p++ = text[r++] = text[i++ & (N - 1)];
				if ( p >= endptr ) goto _end;
yyy:				r &= (N - 1);
			} while ( --j );
		}
	}
_end:

	save_i = i;
	save_j = j;
	save_r = r;
	save_dd = dd;
	save_inptr = inptr;
	save_flags = flags;

	return (unsigned)( p - data );
}


// ---------------------------------------------------------------------------
// LZ77 ��v��=7bit �o�b�t�@��=12bit + Huffman
// 

#undef N
#undef F
#undef MM
#undef SS

#define N       (256+128)	/* �����̎�� */
#define CHARBITS  9             /* 1�o�C�g�̃r�b�g�� */

#define LBIT	12		/* �����ʒu�̃r�b�g�� */
#define MM	3		/* �ŏ���v�� */


// Lzss - Huffman �f�R�[�h

// �r�b�g�ǂݍ��݂̃}�N��
// �g�p�ϐ� a, x, n

#define FILBIT 1

#if FILBIT==0
#define INITBIT() {					\
	bitp = bitc = 0;				\
}

#define GETBIT() {					\
	if(--bitc<0){					\
		bitp=*inptr++;				\
		bitc=32-1;				\
	}						\
	x=bitp&1;					\
	bitp>>=1;					\
}

#define GETBITS(NBIT) {					\
	n=(NBIT);x=0;					\
	if ( n > bitc ) {				\
		x=bitp; n-=bitc;			\
		bitp=*inptr++;				\
		bitc=32;				\
	}						\
	x |= ( bitp << ((NBIT)-n) ) & ((1<<(NBIT))-1);	\
	bitc -= n;					\
	bitp >>= n;					\
}
#else
#define INITBIT() {					\
	bitp=*inptr++;					\
	bitq = bitc = 0;				\
}

#define GETBIT() {					\
	x=bitp&1;					\
	bitp>>=1;					\
	if(bitc--==0){					\
		bitq=*inptr++;				\
		bitc=32-1;				\
	}						\
	bitp|=(bitq<<31);				\
	bitq>>=1;					\
}

#define FILBITS(NBIT) {					\
	n=(NBIT);					\
	bitp |= ( bitq << (32-(NBIT)));			\
	if( (bitc-=n) < 0 ) {				\
		bitq=*inptr++;				\
		n=-bitc;				\
		bitp |= ( bitq << (bitc = 32-n) );	\
	}						\
	bitq >>= n;					\
}

#define ABNBITS(NBIT) {					\
	bitp >>=(NBIT);					\
	FILBITS(NBIT);					\
}

#define GETBITS(NBIT) {					\
	x = bitp & ((1<<(NBIT))-1);			\
	ABNBITS(NBIT);					\
}
#endif

#define NN (1<<LBIT)

#define HUFDP	8		// �����̈ʒu���n�t�}����
#define NNA	(N-(1<<HUFDP))
#define NNB	8 //17
#define NNX	(NNA+NNB)

static short treebuff[2][(N-1)+1][2];	/* Huffman�� 0:left 1:right */

// --------
//   ����
// --------
static unsigned lzhdecode( u_long *inptr, unsigned size, u_char *data )
{
	int n, bitc;
	u_long x, bitp;
#if FILBIT
	u_long bitq;
#endif
	INITBIT();

	// ----- �؂�ǂ� -------------------------------------------------
	{
	int i;

	for ( i = 0; i < 2; i++ ) {
	int avail = N;
	struct SP { int i; } *s = (SP *)textbuff, *sp = s-1;
	short *tree = treebuff[i][-N+1];

	while ( 1 ) {
		GETBIT();
		if ( x ) {  /* bit=1: �t�łȂ��� */
			sp++;
			if ( (x = avail++) >= 2*N-1 ) return 0; //�W�J���s
			sp->i = (x << 1);
		}
		else {
			GETBITS(CHARBITS);  /* ���� */
			while ( 1 ) {
				tree[sp->i] = x;
				if ( !(sp->i & 1) ) {
					sp->i++;
					break;
				}
				x = (sp->i >> 1);
				if ( --sp < s ) goto _next;
			}
		}
	}
_next:
	tree[2*N-2] = x;	// root
	//printf( "avail=%d ", avail );
	}

	}

	// ----- �W�J���� -------------------------------------------------
	{
#if 0
	u_char *p = (u_char *)data;
#else
#  define p data
#endif
	u_char *ep = (u_char *)p + size;
	u_char *text = textbuff;
	short (*tree0)[2] = (short (*)[2])treebuff[0][-N+1];
	short (*tree1)[2] = (short (*)[2])treebuff[1][-N+1];
#if 1
	int root0 = tree0[N-1][0];
	int root1 = tree1[N-1][0];
#else
#  define root0 tree0[N-1][0]
#  define root1 tree1[N-1][0]
#endif
	int r = 0;
#if 0
	int nnm1 = NN-1;
#else
#  define nnm1 (NN-1)
#endif

	while ( 1 ) {	 		/* �e�����𕜌� */
		int j = root0; //tree0[N-1][0];	/* �� */
#if FILBIT==0
		do {
			GETBIT();
			j = tree0[j][x];
		} while ( j >= N );
#else
		n = 0;
		do {
			j = tree0[j][bitp & 1]; bitp>>=1;
			n++;
		} while ( j >= N );
#endif
		if ( j >= 256 ) {
			j = (j - 256 + MM + r) & nnm1;
#if FILBIT==0
			n = root1; //tree1[N-1][0];	/* �� */
			do {
				GETBIT();
				n = tree1[n][x];
			} while ( n >= N );
			if ( n >= NNX ) {
				int s = n;
				GETBITS(LBIT-HUFDP);
				n = ( (s-NNA) << (LBIT-HUFDP) ) | x;
			}
			x = n;
#else
			x = root1; //tree1[N-1][0];	/* �� */
			do {
				x = tree1[x][bitp & 1]; bitp>>=1;
				n++;
			} while ( x >= N );
			if ( x >= NNX ) {
				x = ( (x-NNA) << (LBIT-HUFDP) ) |
					( bitp & ((1<<(LBIT-HUFDP))-1) );
				bitp >>= (LBIT-HUFDP);
				n += (LBIT-HUFDP);
			}
#endif
			do {
				*p++ = text[r++] = text[(r - x) & nnm1];
				if ( p >= ep ) goto _end;
				r &= nnm1;
			} while ( r != j );
		}
		else {
			*p++ = text[r++] = j;
			if ( p >= ep ) goto _end;
			r &= nnm1;
		}
#if FILBIT
		FILBITS(n);
#endif
	}

	}
_end:
	return size;
}

// ---------------------------------------------------------------------------
// 

unsigned lldecode( int method, void *pIn, unsigned len, void *pOut )
{
	//printf( "%08x\n", (int)pIn );

	switch ( method ) {
		case 0:	memcpy( pOut, pIn, len ); return len;
		case 4:	return lz4decode( (u_char *)pIn, len, (u_char *)pOut );
		case 7:	return lz7decode( (u_char *)pIn, len, (u_char *)pOut );
		case 9:	return lzhdecode( (u_long *)pIn, len, (u_char *)pOut );
	}
	return 0;
}



