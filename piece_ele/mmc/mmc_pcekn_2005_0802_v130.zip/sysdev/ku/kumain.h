
#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char vpal[4];
extern unsigned char vref;

void gra_start( void );
void gra_end( void );
void gra_proc( void );
void gra_ope( void );
void gra_putc( int x, int y, int code );

#define VREF_BUF 1
#define VREF_PAL 2

#define FONTADR 0xc10000

#ifdef __cplusplus
};
#endif
