
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE APPLICATION : Kernel Update : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
// �J�[�l���X�V
//
//  v1.00 2001.11.09 MIO.H
//



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <piece.h>
#include "kumain.h"

unsigned char *vbuff = (unsigned char *)0x13d400;

static unsigned char *data;
static unsigned long *idx;
static unsigned char stat = 0;


static void putsub1( unsigned char *p, unsigned char *q, int x, int y, int w, int h, int w0 )
{
	int t = 0;

	w0>>=3;

	if ( x+w > 128 ) w=128-x;
	if ( y+h >  88 ) h= 88-y;

	{
		w0*=3;
		if ( y < 0 ) {
			h+=y;
			p-=y*w0;
			q-=(y<<7);
		}
		if ( x < 0 ) {
			x=-x;
			w-=x;
			p+=(x>>3)*3;
			q+=x;
			t=x&7;
		}
		for ( y = 0; y < h; y++ ) {
			unsigned long a = 0;
			unsigned char *pp = p;
			if ( t ) {
				a  = *pp++; a<<=8;
				a |= *pp++; a<<=8;
				a |= *pp++; a<<=8;
				a++;
				a<<=t;
			}
			for ( x = 0; x < w; x++ ) {
				if ( !(a & 0xff) ) {
					a  = *pp++; a<<=8;
					a |= *pp++; a<<=8;
					a |= *pp++; a<<=8;
					a++;
				}
				if ( a & 0x8000 ) {
					unsigned char g = 0;
					if ( a & 0x80000000 ) g|=1;
					if ( a & 0x800000 ) g|=2;
					q[x] = g;
				}
				a<<=1;
			}
			p += w0;
			q += 128;
		}
	}
}

static void putsub2( unsigned char *p, unsigned char *q, int x, int y, int w, int h, int w0 )
{
	int t = 0;

	w0>>=3;

	if ( x+w > 128 ) w=128-x;
	if ( y+h >  88 ) h= 88-y;

	{
		w0<<=1;
		if ( y < 0 ) {
			h+=y;
			p-=y*w0;
			q-=(y<<8);
		}
		if ( x < 0 ) {
			x=-x;
			w-=x;
			p+=((x>>3)<<1);
			q+=x;
			t=(x&7);
		}
		for ( y = 0; y < h; y++ ) {
			unsigned long a = 0;
			unsigned char g, *pp = p;
			if ( t ) {
				a  = *pp++; a<<=8;
				a |= *pp++; a<<=8;
				a++;
				a<<=t;
			}
			for ( x = 0; x < w; x++ ) {
				if ( !(a & 0xff) ) {
					a  = *pp++; a<<=8;
					a |= *pp++; a<<=8;
					a++;
				}
				g = 0;
				if ( a & 0x800000 ) g|=1;
				if ( a & 0x8000 ) g|=2;
				q[x] = g;
				a<<=1;
			}
			p += w0;
			q += 128;
		}
	}
}


static void putsub( int no, int x, int y )
{
	unsigned char *p, *q;
	int w, h;

	p = data + idx[no];

//	for ( w = 0; w < 4; w++ ) vpal[w] = p[w];

	q = vbuff + (y<<7) + x;

	w = p[4] + (p[5]<<8);
	h = p[6];

	p += 8;

	if ( p[-1] & 0x80 ) {
		putsub1( p, q, x, y, w, h, w );
	}
	else {
		putsub2( p, q, x, y, w, h, w );
	}
}



void gra_start( void )
{
	data = (unsigned char *)FONTADR;
	idx = (unsigned long *)data;

	putsub( 0, 0, 0 );
}

void gra_end( void )
{
}


void gra_proc( void )
{
	//putsub(0,0,0);
	memset( vbuff, 0, 128*88 );
}



void putstr( int x, int y, char *p )
{
	union {
		unsigned short s;
		struct {
			unsigned char w;
			unsigned char h;
		} b;
	} m;

	m.s = 0;

	while ( 1 ) {
		unsigned char c1 = *p++;
		if ( !c1 ) break;
		if ( (c1>=0x81 && c1<=0x9f) || (c1>=0xe0 && c1<=0xfc) ) {
			if ( x > 128-12 ) {
				x = 0;
				y += m.b.h;
			}
			if ( *p ) {
				unsigned char c2 = *p++;
				m.s = pceFontPut( x, y, (c1<<8) + c2 );
			}
			x += m.b.w;
		}
		else if ( c1 == 0x0a ) {
			x = 0;
			y += m.b.h;
		}
		else {
			if ( x > 128-6 ) {
				x = 0;
				y += m.b.h;
			}
			m.s = pceFontPut( x, y, c1 );
			x += m.b.w;
		}
	}
}


static char *msg[] = {
	// [0]
	"���ق����ްĂ��܂�\n"
	"\n"
	"A���݂������ĉ�����\n"
	"�܂���10�b�҂��ĉ�����"
	,
	// [1]
	"�`�F�b�N��"
	,
	// [2]
	"�������ݒ�\n"
	"\n"
	"����ق𔲂�����Aؾ�Ă����肵�Ȃ��ŉ�����"
	,
	// [3]
	"�I�����܂���"
	,
	// [4]
	"�f�[�^�����Ă��܂�\n"
	"\n"
	"������x��蒼���ĉ�����"
	,
	// [5]
	"�������ݒ�\n"
	,
};




extern unsigned long crc32v;
extern unsigned long declen;
extern char nores;

static int acnt = 10*10;		// wait 10sec


void disp_stat( void )
{
	char buff[32];
	int s = stat;

	if ( s == 2 && nores ) s = 5;
	putstr( 0, 0, msg[s] );

	sprintf( buff, "����%d�b %3d:%3d",
		acnt/10,
		pceLCDSetBright(INVALIDVAL),
		pceAppSetProcPeriod(INVALIDVAL) );

	putstr( 24, 88-12, buff );


	if ( stat > 2 ) {
		sprintf( buff, "(%08lx-%08lx)", declen, crc32v );
		putstr( 0, 88-24, buff );
	}
}

int FlashWrite( int mode );

void gra_ope( void )
{
	switch ( stat ) {
		case 0:
			stat++;
			break;
		case 1:
			if ( FlashWrite(1) ) stat = 4; else stat++;
			break;
		case 2:
			FlashWrite(2);
			stat++;
			break;
		case 3:
			pceAppReqExit(0);
			break;
	}
}



void pceAppInit( void )
{
	pceDebugSetMon(0);
	pceLCDSetBuffer( vbuff );
	pceLCDDispStart();
	pceAppSetProcPeriod( 100 );
	stat = 0;
	gra_start();
}



void pceAppProc( int cnt )
{
	int a;

	gra_proc();
	disp_stat();
	pceLCDTrans();
	if ( !stat ) {
		a = pcePadGet();
		if (a & TRG_A) gra_ope();
		else if ( --acnt == 0 ) gra_ope();
	}
	else {
		gra_ope();
	}
}


