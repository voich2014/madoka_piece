/*
   *************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1997 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	PROTODMA.H
   // Author:		Wenkai Du
   // Created:		19 Dec 97
   // Modified:
   // Revision:		2.0
   //
   *************************************************************************
   //
   *************************************************************************
*/


#ifndef __PROTODMA_H__
#define __PROTODMA_H__

/*
   *************************************************************************
   // USB vendor device requests
   *************************************************************************
*/

void read_write_register(void);

#endif