/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by Katsumasa Tsuneyoshi
//
// Comments:
//
//  LCD��ʕϊ��̃R�A���[�`���ł��B�i�A�Z���u�������o�[�W�����j
//  �c�\���p
//
//  v1.00 2001.11.09 Katsumasa Tsuneyoshi
//
;
;
;
;//
;// LCD ���z��� -> VRAM �ϊ�
;//
;
;void disp2ts( unsigned char *vp, unsigned char *gp, unsigned char *gpe )
;{
;	do {
;		signed long r=0x800000;
;		do {
;			int a = *gp;
;			gp += 128;
;			r<<=1;
;			r |= (a&1);
;			r |= ((a<<7)&0x100);
;		} while ( r >= 0 );
;		gp -= (128*8-1);
;		*vp++ = r>>8;
;		*vp++ = r;
;	} while ( gp < gpe );
;}
;	r5		r4
;___0___1___2___3___4___5___6___7
;__40__51__62__73
;4062 5173
; r5   r4
;
;___3___2___1___0___7___6___5___4 
;__37__26__15__04
;37152604
;     
;r4  tbltag
;r5  temp
;r6  *$1fe
;r7  temp2
;r10 *cvttbl
;r11 *nextdot(-width*7+1)
;r12 dst
;r13 src
;r14 max_src
;r15 width
;
;disp2ts:
;	xld.w	%r6,0x1fe
;	xld.w	%r10,cvttbl
;	ld.w	r11,r15
;	sll	r11,3
;	sub	r11,r15
; 
;	add	r11,1
;
;	move.b	(src),tbltag
;	add	width,src
;	lsl.l	#8,tbltag
;	move.b	(src),temp2
;	add	width,src
;	or	temp2,tbltag
;	lsl.l	#8,tbltag
;	move.b	(src),temp2
;	add	width,src
;	or	temp2,tbltag
;	lsl.l	#8,tbltag
;	move.b	(src),temp2
;	add	width,src
;	or	temp2,tbltag
;	move.b	(src),temp
;	add	width,src
;	lsl.l	#8,temp
;	move.b	(src),temp2
;	add	width,src
;	or	temp2,temp
;	lsl.l	#8,temp
;	move.b	(src),temp2
;	add	width,src
;	or	temp2,temp
;	lsl.l	#8,temp
;	move.b	(src),temp2
;	add	nextdot,src
;	or	temp2,temp
;
;	lsl.l	#2,tbltag
;	or	tbltag,temp
;	move.uw	temp,tbltagl
;	lsr.l	#8,temp
;	lsr.l	#4,temp
;	or	temp,tbltag
;	lsl.w	#1,tbltag
;	move.l	tbltag,temp
;	and	#$1fe,tbltag
;	add	#cvttbl,tbltag
;	move.w	(tbltag),tbltag
;	lsr.w	#8,temp
;	lsl.w	#1,tbltag
;	and	#$1fe,temp
;	add	#cvttbl,temp
;	move.w	(temp),temp
;	or	temp,tbltag
;	move.w	tbltag,(dst)+
;
;	cmp	max_src,src
;	blt	disp2ts_loop
;
	.global	disp2ts
disp2ts:
	xld.w	%r6,0x1fe
	xld.w	%r10,cvttbl
	ld.w	%r11,0
	sub	%r11,%r15
	sll	%r11,3
	add	%r11,%r15
	add	%r11,1

disp2ts_loop:
	ld.ub	%r5,[%r13]
	add	%r13,%r15
	sll	%r5,4
	ld.ub	%r4,[%r13]
	add	%r13,%r15
	sll	%r4,4
	ld.ub	%r7,[%r13]
	add	%r13,%r15
	or	%r5,%r7
	ld.ub	%r7,[%r13]
	add	%r13,%r15
	or	%r4,%r7

	ld.ub	%r7,[%r13]
	add	%r13,%r15
	sll	%r7,6
	or	%r5,%r7
	ld.ub	%r7,[%r13]
	add	%r13,%r15
	sll	%r7,6
	or	%r4,%r7
	ld.ub	%r7,[%r13]
	add	%r13,%r15
	sll	%r7,2
	or	%r5,%r7
	ld.ub	%r7,[%r13]
	add	%r13,%r11
	sll	%r7,2
	or	%r4,%r7

	sll	%r4,1
	add	%r4,%r10
	ld.h	%r4,[%r4]
	sll	%r5,1
	add	%r5,%r10
	ld.h	%r5,[%r5]
	sll	%r5,1
	or	%r4,%r5
	ld.h	[%r12]+,%r4

	cmp	%r13,%r14
	jrult	disp2ts_loop
	
	ret
