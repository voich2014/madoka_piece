
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by Katsumasa Tsuneyoshi
//
// Comments:
//
//  LCD��ʕϊ��̃R�A���[�`���ł��B�i�A�Z���u�������o�[�W�����j
//  �ʏ�\���p(��)
//
//  v1.00 2001.11.09 Katsumasa Tsuneyoshi
//

;r4 low
;r5 high
;r6 temp
;r10  0xfffffffe
;r11  0x80000000
;r12 dist adr
;r13 source adr
;r14 comp adr
;r15 width
	.global disp2ns
;
;disp2ns:
;        xld.w   %r10,0xfffffffe
;        xld.w   %r11,0x80000000
;disp2ns_loop:
;        ld.ub   %r4,[%r13]+
;        ld.w    %r5,%r4
;        and     %r4,0x1
;        srl     %r5,0x1
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        ld.ub   %r6,[%r13]+
;        add     %r6,%r10
;        adc     %r5,%r5
;        rr      %r6,0x1
;        add     %r6,%r11
;        adc     %r4,%r4
;
;        mirror  %r4,%r4
;        mirror  %r5,%r5
;
;        ld.b    [%r12]+,%r5
;        ld.b    [%r12]+,%r4
;
;        xadd    %r13,%r13,120
;
;        cmp     %r13,%r14
;        jrult   disp2ns_loop
;
;        ret

;disp2ns:
;	xld.w	%r7,0xff
;	xld.w	%r10,cvttbl
;	xld.w	%r11,120
;disp2ns_loop:
;	ld.uh	%r5,[%r13]+
;	ld.uh	%r15,[%r13]+
;	ld.w	%r4,%r5
;	srl	%r5,2
;	sll	%r4,4
;	or	%r5,%r4
;	or	%r5,%r15
;	srl	%r15,6
;	or	%r5,%r15
;	and	%r5,%r7
;	add	%r5,%r5
;	add	%r5,%r10
;	ld.uh	%r6,[%r5]
;	ld.uh	%r5,[%r13]+
;	srl	%r6,4
;
;	ld.w	%r4,%r5
;	srl	%r5,2
;	sll	%r4,4
;	ld.uh	%r15,[%r13]+
;	or	%r5,%r4
;	or	%r5,%r15
;	srl	%r15,6
;	or	%r5,%r15
;	and	%r5,%r7
;	add	%r5,%r5
;	add	%r5,%r10
;	ld.uh	%r4,[%r5]
;	add	%r13,%r11
;	or	%r6,%r4
;	ld.h	[%r12]+,%r6
;
;	cmp	%r13,%r14
;	jrult	disp2ns_loop
;	
;	ret

disp2ns:
	xld.w	%r6,0x1fe
	xld.w	%r10,cvttbl
	sub	%r15,4
	sub	%r14,%r15
;	xld.w	%r4,320		;���̓������̃E�F�C�g�����܂��悤�ɁI
;disp2ns_wait:
;	sub	%r4,0x1
;	jrne	disp2ns_wait
disp2ns_loop:
	ld.w	%r4,[%r13]+
	ld.w	%r5,[%r13]
	sll	%r4,2
	or	%r4,%r5
	ld.w	%r5,%r4
	srl	%r5,8
	srl	%r5,4
	or	%r5,%r4
	sll	%r5,1
	ld.w	%r4,%r5
	and	%r4,%r6
	add	%r4,%r10
	ld.h	%r4,[%r4]
	srl	%r5,8
	and	%r5,%r6
	add	%r5,%r10
	ld.h	%r5,[%r5]
	sll	%r5,1
	or	%r4,%r5
	ld.h	[%r12]+,%r4

	cmp	%r13,%r14
	jrult.d	disp2ns_loop
	add	%r13,%r15	;delay
	
	ret
