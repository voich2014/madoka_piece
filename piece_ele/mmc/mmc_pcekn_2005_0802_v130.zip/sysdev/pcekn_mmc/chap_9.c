/*
   *************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1997 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  ---
   //
   // File Name:	CHAP_9.C
   // Author:		Wenkai Du
   // Created:		19 Dec 97
   // Modified:
   // Revision:		2.0
   //
   *************************************************************************
   // Modified:     15 Sep 99  Support USB mass storage class (Buan Huat)
   *************************************************************************
   //  v1.19 2003.02.26 N.SAWA usbcmdbuff[]�T�C�Y��128->64�ɕύX�B(�錾�̂݁B��`��mainloop.c)
*/

#include <stdio.h>
#include <string.h>

#ifdef __C51__
// #include <reg51.h>                /* special function register declarations   */
#else
 #include <piece.h>
 #include "pcekn.h"
#endif

#include "d12ci.h"
#include "mainloop.h"
#include "usb100.h"
#include "chap_9.h"
#include "pceusb.h"

#define NUM_ENDPOINTS	2
#define CONFIG_DESCRIPTOR_LENGTH (9+9+(NUM_ENDPOINTS*7))

//		sizeof(USB_CONFIGURATION_DESCRIPTOR) \
//		+ sizeof(USB_INTERFACE_DESCRIPTOR) \
//		+ (NUM_ENDPOINTS * sizeof(USB_ENDPOINT_DESCRIPTOR))

extern CONTROL_XFER		ControlData;
extern IO_REQUEST idata ioRequest;
extern EPPFLAGS			bEPPflags;

#if 1
//extern unsigned char usbcmdbuff[128];	// 128�o�C�g�K�v�ł�
extern unsigned char usbcmdbuff[64];	// 2003.02.26 N.SAWA 64�o�C�g�ő���܂�
#define tmpbuff usbcmdbuff
#else
//static unsigned char tmpbuff[256];
#endif


//  �e�f�B�X�N���v�^�̒�`
//
//


//  BASIC ���[�h�̂��߂̐ݒ�

code USB_DEVICE_DESCRIPTOR DeviceDescr =
{
    0x12,
    USB_DEVICE_DESCRIPTOR_TYPE,
    SWAP(0x0110),
    0,
    0, 0,
    EP0_PACKET_SIZE,
    SWAP(PCE_VENDOR_ID),		// VID
    SWAP(PCE_PRODUCT_ID_BASIC),	// PID
    SWAP(0x0100),
    1, 2, 0,
    1				// num of config.
};

code USB_CONFIGURATION_DESCRIPTOR ConfigDescr =
{
    0x09,
    USB_CONFIGURATION_DESCRIPTOR_TYPE,
    SWAP(CONFIG_DESCRIPTOR_LENGTH),
    1,				// num of interface
    1,
    4,
    0x80,
    100/2		// 100mA
};

code USB_INTERFACE_DESCRIPTOR InterfaceDescr =
{
    0x09,
    USB_INTERFACE_DESCRIPTOR_TYPE,
    0,
    0,
    NUM_ENDPOINTS,
    0x00,
    0x00,
    0x00,
    5
};

/*
code USB_ENDPOINT_DESCRIPTOR EP1_TXDescr =
{
    sizeof(USB_ENDPOINT_DESCRIPTOR),
    USB_ENDPOINT_DESCRIPTOR_TYPE,
    0x81,
    USB_ENDPOINT_TYPE_INTERRUPT,
    SWAP(EP1_PACKET_SIZE),
    10
};



code USB_ENDPOINT_DESCRIPTOR EP1_RXDescr =
{
    sizeof(USB_ENDPOINT_DESCRIPTOR),
    USB_ENDPOINT_DESCRIPTOR_TYPE,
    0x1,
    USB_ENDPOINT_TYPE_INTERRUPT,
    SWAP(EP1_PACKET_SIZE),
    10
};*/

code USB_ENDPOINT_DESCRIPTOR EP2_TXDescr =
{
    7,
    USB_ENDPOINT_DESCRIPTOR_TYPE,
    0x82,
    USB_ENDPOINT_TYPE_BULK,
    SWAP(EP2_PACKET_SIZE),
    0
};

code USB_ENDPOINT_DESCRIPTOR EP2_RXDescr =
{
    7,
    USB_ENDPOINT_DESCRIPTOR_TYPE,
    0x2,
    USB_ENDPOINT_TYPE_BULK,
    SWAP(EP2_PACKET_SIZE),
    0
};



// 
// USB�p�b�h�̂��߂̐ݒ�
// 

code USB_DEVICE_DESCRIPTOR DeviceDescr2 =
{
    0x12,
    USB_DEVICE_DESCRIPTOR_TYPE,
    SWAP(0x0110),
    0,
    0, 0,
    EP0_PACKET_SIZE,
    SWAP(PCE_VENDOR_ID),			// VID
    SWAP(PCE_PRODUCT_ID_GAMEPAD),	// PID
    SWAP(0x0100),
    1, 6, 0,
    1				// num of config.
};

#define CONFIG_DESCRIPTOR_LENGTH2 (9+9+9+7)

code USB_CONFIGURATION_DESCRIPTOR ConfigDescr2 =
{
    0x09,
    USB_CONFIGURATION_DESCRIPTOR_TYPE,
    SWAP(CONFIG_DESCRIPTOR_LENGTH2),
    1,
    1,
    4,
    0x80,
    100/2		// 100mA
};

code USB_INTERFACE_DESCRIPTOR InterfaceDescr2 =
{
    0x09,
    USB_INTERFACE_DESCRIPTOR_TYPE,
    0,	// index no.
    0,
    1, //NUM_ENDPOINTS,
    USB_DEVICE_CLASS_HUMAN_INTERFACE,
    1,
    2,
    5
};

code USB_ENDPOINT_DESCRIPTOR EP1_TXDescr2 =
{
    7,
    USB_ENDPOINT_DESCRIPTOR_TYPE,
    0x81,
    USB_ENDPOINT_TYPE_INTERRUPT,
    3,	// �]���o�C�g��
	20	// interval 20ms
};


typedef unsigned char USB_REPORT_DESCRIPTOR[];

code USB_REPORT_DESCRIPTOR RepoDescr2 =
{
	5,  	1,		//  UsagePage(Generic Desktop),
	9,		5,		//  Usage(Game Pad),
//	9,		4,		//  Usage(Joystick),
	0xa1,	1,		//  Collection(Application),

	5,  	1,		//  	UsagePage(Generic Desktop),
	9,		1,		//		Usage (Pointer),
	0xa1,	0,		//		Collection (Physical),
	9,		0x30,	//			Usage (X),
	9,		0x31,	//			Usage (Y),
	0x15,	-127,	//			Logical Minimum (-127),
	0x25,	127,	//			Logical Maximum (127),
	0x35,	1,		//			Physical Minimum (1),
	0x45,	0xff,	//			Physical Maximum (255),
	0x95,	2,		//			Report Count (2),
	0x75,	8,		//			Report Size (8),
	0x81,	2,		//			Input (Data, Variable, Absolute, No Null),
	0xc0,			//		End Collection(),

	5,		9,		//  	Usage Page (Buttons), ; Buttons on the stick
	0x19,	1,		//  	Usage Minimum (Button 1),
	0x29,	4,		//  	Usage Maximum (Button 4),
	0x15,	0,		//  	Logical Minimum (0),
	0x25,	1,		//  	Logical Maximum (1),
	0x95,	4,		//  	Report Count (4),
	0x75,	1,		//  	Report Size (1),
	0x81,	2,		//  	Input (Data, Variable, Absolute),

	0x95,	4,		//  	Report Count (4),
	0x75,	1,		//  	Report Size (1),
	0x81,	3,		//  	Input (Constant, Variable, Absolute),

	0xc0,			//  End Collection()
};

typedef unsigned char USB_HID_DESCRIPTOR[9];

code USB_HID_DESCRIPTOR HIDDescr2 =
{
    0x09,
    0x21, 					// USB_HID_DESCRIPTOR_TYPE,
    0x10,0x01,				// 1.10
    0,						// country
    1,						// num. descr.
    0x22,					// repo. descr. type
    sizeof(RepoDescr2),0,	// repo. descr. size
};


//static const signed char padtbl1[] = { 0, 127, -127, 0 };
static const signed char padtbl1[] = { 128, 255,  1, 128 };

static const unsigned char padtbl2[] = {
	0x00, 0x20, 0x10, 0x30,
	0x80, 0xa0, 0x90, 0xb0,
	0x40, 0x60, 0x50, 0x70,
	0xc0, 0xe0, 0xd0, 0xf0,
};


void padsend( void )
{
	int a = pcePadGetDirect();
	usbcmdbuff[0] = padtbl1[a&3];
	usbcmdbuff[1] = padtbl1[(a>>2)&3];
	usbcmdbuff[2] = padtbl2[(a>>4)&15]/16;
	D12_WriteEndpoint(3, usbcmdbuff, 3);
}



static const char *const string[] = {
	NULL,
	"OeRSTED, Inc.",		// 1
	"PIECE PME-001",		// 2
	NULL,					// 3
	"PieceConfig",			// 4
	"PieceInterface",		// 5
	"PIECE USB Game Pad",	// 6
	NULL,
};

static const unsigned char st0[] = { 4, 3, 9, 4 };



/*
   *************************************************************************
   // USB Protocol Layer
   *************************************************************************
*/

void reserved(void)
{
    stall_ep0();
}

/*
   *************************************************************************
   // USB standard device requests
   *************************************************************************
*/


void get_status(void)
{
	unsigned char endp, txdat[2];
	unsigned char bRecipient = ControlData.DeviceRequest.bmRequestType & USB_RECIPIENT;
	unsigned char c;

	if (bRecipient == USB_RECIPIENT_DEVICE) {
		if(bEPPflags.bits.remote_wakeup == 1)
			txdat[0] = 3;
		else
			txdat[0] = 1;
		txdat[1]=0;
		single_transmit(txdat, 2);
	} else if (bRecipient == USB_RECIPIENT_INTERFACE) {
		txdat[0]=0;
		txdat[1]=0;
		single_transmit(txdat, 2);
	} else if (bRecipient == USB_RECIPIENT_ENDPOINT) {
		endp = (unsigned char)(ControlData.DeviceRequest.wIndex & MAX_ENDPOINTS);
		if (ControlData.DeviceRequest.wIndex & (unsigned char)USB_ENDPOINT_DIRECTION_MASK)
			c = D12_SelectEndpoint(endp*2 + 1);	/* Control-in */
		else
			c = D12_SelectEndpoint(endp*2);	/* Control-out */
		if(c & D12_STALL)
			txdat[0] = 1;
		else
			txdat[0] = 0;
		txdat[1] = 0;
		single_transmit(txdat, 2);
	} else
		stall_ep0();
}



void clear_feature(void)
{
	unsigned char endp;
	unsigned char bRecipient = ControlData.DeviceRequest.bmRequestType & USB_RECIPIENT;

	if (bRecipient == USB_RECIPIENT_DEVICE
		&& ControlData.DeviceRequest.wValue == USB_FEATURE_REMOTE_WAKEUP) {
		DISABLE;
		bEPPflags.bits.remote_wakeup = 0;
		ENABLE;
		single_transmit(0, 0);
	}
	else if (bRecipient == USB_RECIPIENT_ENDPOINT
		&& ControlData.DeviceRequest.wValue == USB_FEATURE_ENDPOINT_STALL) {
		endp = (unsigned char)(ControlData.DeviceRequest.wIndex & MAX_ENDPOINTS);
		if (ControlData.DeviceRequest.wIndex & (unsigned char)USB_ENDPOINT_DIRECTION_MASK)
			/* clear TX stall for IN on EPn. */
			D12_SetEndpointStatus(endp*2 + 1, 0);
		else
			/* clear RX stall for OUT on EPn. */
			D12_SetEndpointStatus(endp*2, 0);
		single_transmit(0, 0);
	} else
		stall_ep0();
}




void set_feature(void)
{
	unsigned char endp;
	unsigned char bRecipient = ControlData.DeviceRequest.bmRequestType & USB_RECIPIENT;

	if (bRecipient == USB_RECIPIENT_DEVICE
		&& ControlData.DeviceRequest.wValue == USB_FEATURE_REMOTE_WAKEUP) {
		DISABLE;
		bEPPflags.bits.remote_wakeup = 1;
		ENABLE;
		single_transmit(0, 0);
	}
	else if (bRecipient == USB_RECIPIENT_ENDPOINT
		&& ControlData.DeviceRequest.wValue == USB_FEATURE_ENDPOINT_STALL) {
		endp = (unsigned char)(ControlData.DeviceRequest.wIndex & MAX_ENDPOINTS);
		if (ControlData.DeviceRequest.wIndex & (unsigned char)USB_ENDPOINT_DIRECTION_MASK)
			/* clear TX stall for IN on EPn. */
			D12_SetEndpointStatus(endp*2 + 1, 1);
		else
			/* clear RX stall for OUT on EPn. */
			D12_SetEndpointStatus(endp*2, 1);
		single_transmit(0, 0);
	} else
		stall_ep0();
}




void set_address(void)
{
	D12_SetAddressEnable((unsigned char)(ControlData.DeviceRequest.wValue &
		DEVICE_ADDRESS_MASK), 1);
	single_transmit(0, 0);
}




static unsigned char *dscpy( unsigned char *ptr, const void *src, int len )
{
	memcpy( ptr, src, len );
	return ptr+len;
}


void get_descriptor(void)
{
	unsigned char bDescriptor = MSB(ControlData.DeviceRequest.wValue);

	//printf( "bDescriptor = %02x\n", bDescriptor );
	//printf( "size = %02x\n", sizeof(USB_DEVICE_DESCRIPTOR) );

	if (bDescriptor == USB_DEVICE_DESCRIPTOR_TYPE) {
		if (!usbmode) code_transmit((unsigned char code *)&DeviceDescr, 0x12);
		else code_transmit((unsigned char code *)&DeviceDescr2, 0x12);
	} else if (bDescriptor == USB_CONFIGURATION_DESCRIPTOR_TYPE) {
		unsigned char *p = tmpbuff;
		if ( !usbmode ) {
			p = dscpy( p, &ConfigDescr, 9 );
			p = dscpy( p, &InterfaceDescr, 9 );
			p = dscpy( p, &EP2_TXDescr, 7 );
			p = dscpy( p, &EP2_RXDescr, 7 );
		}
		else {
			p = dscpy( p, &ConfigDescr2, 9 );
			p = dscpy( p, &InterfaceDescr2, 9 );
			p = dscpy( p, &HIDDescr2, 9 );
			p = dscpy( p, &EP1_TXDescr2, 7 );
		}
		code_transmit((unsigned char code *)tmpbuff, p - tmpbuff );
	} else if (bDescriptor == USB_STRING_DESCRIPTOR_TYPE) {
		const char *p = string[ControlData.DeviceRequest.wValue & 7];
		if ( p != NULL ) {
			int n = 2;
			while ( *p ) {
				tmpbuff[n++] = *p++;
				tmpbuff[n++] = 0;
			}
			tmpbuff[0] = n;
			tmpbuff[1] = 3;
			code_transmit((unsigned char code *)tmpbuff, n);
		}
		else {
			code_transmit((unsigned char code *)st0, 4);
		}
	} else if (bDescriptor == 0x22) {
		code_transmit((unsigned char code *)&RepoDescr2, sizeof(RepoDescr2));
		padsend();
	} else {
		stall_ep0();
	}
}




void get_configuration(void)
{
	unsigned char c = bEPPflags.bits.configuration;

	single_transmit(&c, 1);
}




void set_configuration(void)
{
	if (ControlData.DeviceRequest.wValue == 0) {
		/* put device in unconfigured state */
		single_transmit(0, 0);
		DISABLE;
		bEPPflags.bits.configuration = 0;
		ENABLE;
		init_unconfig();
	} else if (ControlData.DeviceRequest.wValue == 1) {
		/* Configure device */
		single_transmit(0, 0);

		init_unconfig();
		init_config();
		
		DISABLE;
		bEPPflags.bits.configuration = 1;
		ENABLE;
	} else
		stall_ep0();
}




void get_interface(void)
{
	unsigned char txdat = 0;        /* Only/Current interface = 0 */
	single_transmit(&txdat, 1);
}




void set_interface(void)
{
	if (ControlData.DeviceRequest.wValue == 0 && ControlData.DeviceRequest.wIndex == 0)
		single_transmit(0, 0);
	else
		stall_ep0();
}





#if 0
///**************************************************************************/
///* Subroutines For Vendor Specific Request                                */ 
///**************************************************************************/
//
//void D12Bus_Watchdog(void)
//{
//    unsigned char   i;
//    unsigned short  ChipID;
//    unsigned char   txdata[16];
//    //ChipID = Hal4D12_ReadChipID();
//    ChipID = 0x00;
//
//
//    if(ControlData.DeviceRequest.wLength == 16 ){
//        txdata[0]= ControlData.DeviceRequest.wIndex >> 8 ;
//        txdata[1]= ChipID >> 8 ;
//        txdata[2]= ControlData.DeviceRequest.wIndex ;
//        txdata[3]= ChipID ;
//        txdata[4]= ControlData.DeviceRequest.wValue >>8 ;
//        txdata[5]= ControlData.DeviceRequest.wValue ;
//        for(i=6; i<16; i++)
//            txdata[i]=0;
//
//        /* Data Encrption goes on GetTimer */
//        single_transmit(txdata,16);
//		}
//    else
//		{
//			stall_ep0();
//		}
//}
//
//
//
//void D12Bus_ControlEntry(void)
//{
//					/* No support now, just stall it. */
////	stall_ep0();    /* Unknown command */
//}
//
//
//
//#define ATACMD_FIND_DEVICE  0x00
//
//void D12Bus_ATAControlEntry(void)
//{
////    unsigned short   i;
//
//	if(ControlData.DeviceRequest.bmRequestType & (unsigned char)USB_ENDPOINT_DIRECTION_MASK) {
//		if( ControlData.DeviceRequest.wValue == ATACMD_FIND_DEVICE &&
//		    ControlData.DeviceRequest.wIndex == 0 ) 
//			{
//				D12Bus_GetIDEDeviceExtension();
//			}
//		else
//			{
//				stall_ep0();
//			}
//
//		}
//	else
//		stall_ep0();
//}
//
//
//
//void D12Bus_GetIDEDeviceExtension(void)
//{
//	//	printf("Enter D12Bus_GetIDEDeviceExtension.\n");
//	//	D12Bus_BurstTransmitEP0((unsigned char *)&Hal4ATA_DevExt, ControlData.DeviceRequest.wLength);
//	//	printf("Exit D12Bus_GetIDEDeviceExtension.\n");
//
////	code_transmit((unsigned char *)&Hal4ATA_DevExt, ControlData.DeviceRequest.wLength);
//
//}  /* end D12Bus_GetIDEDeviceExtension()*/
#endif

