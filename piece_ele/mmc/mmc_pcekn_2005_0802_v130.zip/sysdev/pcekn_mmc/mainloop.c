/*
   *************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1997 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	MainLoop.C
   // Author:		Wenkai Du
   // Created:		19 Dec 97
   // Modified:
   // Revision:		2.2
   //
   *************************************************************************
   //
   // 98/11/25		Added I/O access support on Main endpoints. (WK)
   // 15 Sep 99		Support USB mass storage class (Buan Huat)
   *************************************************************************
   //  v1.19 2003.02.14 N.SAWA connect_USB()��disconnect_USB()���C���B
   //                          D12_NOLAZYCLOCK��D12_CLOCKRUNNING�͏�ɕs�v�Ǝv���܂��B
   //  v1.19 2003.02.15 N.SAWA P/ECE�Ŏg���Ă��Ȃ��������폜
   //  v1.19 2003.02.26 N.SAWA ���C���G���h�|�C���g�̃_�u���o�b�t�@�ɂQ�̃R�}���h�����܂�ƁA
   //                          �܂Ƃ߂ĉ�ꂽ�R�}���h�Ƃ��Ĕj������Ă��܂��Ă����s����C���B
   //                          usbcmdbuff[]�T�C�Y��128->64�ɕύX�B
   //  v1.19 2003.02.27 N.SAWA Stall_EP2()�͎g���Ă��Ȃ������̂ō폜�B
*/

#include <stdio.h>
#include <string.h>

#include <piece.h>
#include "pcekn.h"

#include "d12ci.h"
#include "mainloop.h"
#include "usb100.h"
#include "chap_9.h"
//#include "protodma.h"

void pdwait( int n );






//unsigned char usbcmdbuff[128];	// 128�o�C�g�K�v�ł�
unsigned char usbcmdbuff[64];	// 2003.02.26 N.SAWA 64�o�C�g�ő���܂�




/*
*************************************************************************
// USB protocol function pointer arrays
*************************************************************************
*/


void (*const StandardDeviceRequest[])(void) =
{
	get_status,
	clear_feature,
	reserved,
	set_feature,
	reserved,
	set_address,
	get_descriptor,
	reserved,
	get_configuration,
	set_configuration,
	get_interface,
	set_interface,
	reserved,
	reserved,
	reserved,
	reserved
};

#if 0
//code void (*VendorDeviceRequest[])(void) =
//{
//	D12Bus_Watchdog,
//	D12Bus_ControlEntry,
//	D12Bus_ATAControlEntry,
//	reserved,
//	reserved,
//	reserved,
//	reserved,
//	reserved,
//	reserved,
//	reserved,
//	reserved,
//	reserved,
//	read_write_register,
//	reserved,
//	reserved,
//	reserved
//};
#endif

/*************************************************************************/
/*  Public static data                                                   */
/*************************************************************************/

//extern D12FLAGS bD12flags;
EPPFLAGS bEPPflags;
extern volatile unsigned long ClockTicks;
//extern unsigned char idata GenEpBuf[];
//extern IO_REQUEST idata ioRequest;
//unsigned char idata before,mid,after;

unsigned char idata GenEpBuf[EP1_PACKET_SIZE];
IO_REQUEST idata ioRequest;

CONTROL_XFER ControlData;

#if 0
//
//code char * _NAME_USB_REQUEST_DIRECTION[] =
//{
//"Host_to_device",
//"Device_to_host"
//};
//
//
//code char * _NAME_USB_REQUEST_RECIPIENT[] =
//{
//"Device",
//"Interface",
//"Endpoint(0)",
//"Other"
//};
//
//
//code char * _NAME_USB_REQUEST_TYPE[] =
//{
//"Standard",
//"Class",
//"Vendor",
//"Reserved"
//};
//
//
//code char * _NAME_USB_STANDARD_REQUEST[] =
//{
//"GET_STATUS",
//"CLEAR_FEATURE",
//"RESERVED",
//"SET_FEATURE",
//"RESERVED",
//"SET_ADDRESS",
//"GET_DESCRIPTOR",
//"SET_DESCRIPTOR",
//"GET_CONFIGURATION",
//"SET_CONFIGURATION",
//"GET_INTERFACE",
//"SET_INTERFACE",
//"SYNC_FRAME"
//};
//
//
//void help_devreq(unsigned char typ, unsigned char req)
//{
//	typ >>= 5;
//
//	if(typ == USB_STANDARD_REQUEST) {
//		printf("Request Type = %s, Request = %s.\n", _NAME_USB_REQUEST_TYPE[typ],
//			_NAME_USB_STANDARD_REQUEST[req]);
//	}
//	else {
//		if(bEPPflags.bits.verbose)
//			printf("Request Type = %s, bRequest = 0x%x.\n", _NAME_USB_REQUEST_TYPE[typ],
//				req);
//	}
//}
//
#endif

/* Configure Timer 0
   - Mode                  = 1
   - Interrupt             = ENABLED
   - Clock Source          = INTERNAL
   - Enable Gating Control = DISABLED
*/

//extern void interrupt (*OldTimerIsr)();
//extern void interrupt (*OldUsbIsr)();
//extern unsigned long ClockIsr;
//unsigned long dmaBuffer;
//unsigned long ioBuffer; // V2.1

//unsigned short ioSize, ioCount; // V2.1

#if 0
//void init_timer0(void)
//{
//}
//
//
///******************************************************************/
///*   Interrupt Control Unit                                       */
///*   ****  Enabled interrupts in Interrupt Enable Register ****   */
///*	 ****  GLOBAL INTERRUPT MUST BE ENABLED FOR ANY OTHER  ****   */
///*	 ****  INTERRUPT TO WORK!                              ****   */    
///*                                                                */
///*   GLOBAL INTERRUPT DISABLED ALL INTERRUPTS ARE DISABLED        */
///*   External interrupt 0                                         */
///*   Priority Level = 0                                           */
///*   Timer 0 interrupt                                            */
///*   Priority Level = 0                                           */
///******************************************************************/
//void init_special_interrupts(void)
//{
//}
//
//
//void init_port()
//{
//}
//
///**********************************************/
///*  Serial Port                               */
///*  Mode                   = 1  /8-bit UART   */
///*  Serial Port Interrupt  = Disabled         */
///*  Receive                = Enabled          */
///*  Auto Addressing        = Disabled         */
///**********************************************/
//void init_serial(void)
//{
//}
#endif



//!///// Piece Kernel Service API Reference
//! 
//! �� pceUSBDisconnect
//! 
//! USB��ؒf���܂��B
//!
//! void pceUSBDisconnect( void );
//!
//! �߂�l�F�Ȃ�
//!
//! PC �Ƃ� USB �ɂ��ڑ����������܂��B
//!
//!
void pceUSBDisconnect(void)
{
	DISABLE;
	disconnect_USB();
	*(unsigned char *)0x402dd |= 1; // P30 = 1  Power = BATT
	ENABLE;
}


//!///// Piece Kernel Service API Reference
//! 
//! �� pceUSBReconnect
//! 
//! USB��(��)�ڑ����܂��B
//!
//! void pceUSBReconnect( void );
//!
//! �߂�l�F�Ȃ�
//!
//! PC �Ƃ� USB �ɂ��ڑ����ĊJ���܂��B
//!
void pceUSBReconnect(void)
{
	DISABLE;
	reconnect_USB();
	ENABLE;
}



//!///// Piece Kernel Service API Reference
//! 
//! �� pceUSBSetupMode �y�b��d�l�z
//! 
//! USB�̓��샂�[�h��ύX���܂��B
//! 
//! int pceUSBSetupMode(
//! 		int mode,		// ���[�h
//! 		void *param2,	// �\�� �K�� NULL(0)
//! 		void *param3	// �\�� �K�� NULL(0)
//! 		);
//! 
//! �߂�l�F0(��ɐ���I��)
//! 
//! �ȉ��̃��[�h���w��ł��܂��B
//!@
//!   PUM_BASIC   (0) : �ʏ��PC�ڑ����[�h
//!   PUM_GAMEPAD (1) : Game Pad ���[�h
//!@
//! �K�� disconnect ���ɃR�[�����Ă��������B
//!

int pceUSBSetupMode( int mode, void *param2, void *param3 )
{
	usbmode = mode;
	return 0;
}


////////////////////////////////////////////////////////////////////////////


// 2003.02.15 N.SAWA �폜���܂���
//void bus_reset(void)
//{
//}



void ep0_rxdone(void)
{
	unsigned char ep_last, i;

	*(unsigned char *)0x402dd &= ~1; // P30 = 0  Power = USB

	ep_last = D12_ReadLastTransactionStatus(0); // Clear interrupt flag

	if (ep_last & D12_SETUPPACKET) {

		ControlData.wLength = 0;
		ControlData.wCount = 0;

		if( D12_ReadEndpoint(0, (unsigned char *)(&(ControlData.DeviceRequest)),
			sizeof(ControlData.DeviceRequest)) != sizeof(DEVICE_REQUEST) ) {

			D12_SetEndpointStatus(0, 1);
			D12_SetEndpointStatus(1, 1);
			bEPPflags.bits.control_state = USB_IDLE;
			return;
		}

#ifdef __C51__
//		ControlData.DeviceRequest.wValue = SWAP(ControlData.DeviceRequest.wValue);
//		ControlData.DeviceRequest.wIndex = SWAP(ControlData.DeviceRequest.wIndex);
//		ControlData.DeviceRequest.wLength = SWAP(ControlData.DeviceRequest.wLength);
#endif

		// Acknowledge setup here to unlock in/out endp
		D12_AcknowledgeEndpoint(0);
		D12_AcknowledgeEndpoint(1);

		ControlData.wLength = ControlData.DeviceRequest.wLength;
		ControlData.wCount = 0;

		if (ControlData.DeviceRequest.bmRequestType & (unsigned char)USB_ENDPOINT_DIRECTION_MASK) {
			bEPPflags.bits.setup_packet = 1;
			bEPPflags.bits.control_state = USB_IDLE;		/* get command */
		}
		else {
			if (ControlData.DeviceRequest.wLength == 0) {
				bEPPflags.bits.setup_packet = 1;
				bEPPflags.bits.control_state = USB_IDLE;		/* set command */
			}
			else {
				if(ControlData.DeviceRequest.wLength > MAX_CONTROLDATA_SIZE) {
					bEPPflags.bits.control_state = USB_IDLE;
					D12_SetEndpointStatus(0, 1);
					D12_SetEndpointStatus(1, 1);
				}
				else {
					bEPPflags.bits.control_state = USB_RECEIVE;	/* set command with OUT token */
				}
			} // set command with data
		} // else set command
	} // if setup packet

	else 
		if (bEPPflags.bits.control_state == USB_RECEIVE) {
			i =	D12_ReadEndpoint(0, ControlData.dataBuffer + ControlData.wCount,
								EP0_PACKET_SIZE);
			ControlData.wCount += i;
			if( i != EP0_PACKET_SIZE || ControlData.wCount >= ControlData.wLength) {
				bEPPflags.bits.setup_packet = 1;
				bEPPflags.bits.control_state = USB_IDLE;
			}
		}

	else {
		bEPPflags.bits.control_state = USB_IDLE;
	}
}

void ep0_txdone(void)
{
	short i = ControlData.wLength - ControlData.wCount;

	D12_ReadLastTransactionStatus(1); // Clear interrupt flag

	if (bEPPflags.bits.control_state != USB_TRANSMIT)
		return;

	if (i > EP0_PACKET_SIZE) {
		D12_WriteEndpoint(1, ControlData.pData + ControlData.wCount, EP0_PACKET_SIZE);
		ControlData.wCount += EP0_PACKET_SIZE;

		//bEPPflags.bits.control_state = USB_TRANSMIT;
	}
	else if (i > 0) {
		D12_WriteEndpoint(1, ControlData.pData + ControlData.wCount, i);
		ControlData.wCount += i;

		//dbgwrtn(&i,4);
		//dbgwrtn(&ControlData.wCount,4);
		//dbgwrtn(&ControlData.wLength,4);

		//bEPPflags.bits.control_state = USB_IDLE;
	}
	else {
		D12_WriteEndpoint(1, 0, 0); // Send zero packet at the end ???

		bEPPflags.bits.control_state = USB_IDLE;
	}
}

// 2003.02.15 N.SAWA �폜���܂���
//void dma_eot(void)
//{
//	if(bEPPflags.bits.dma_state == DMA_PENDING)
//		bEPPflags.bits.setup_dma = 1;
//	else 
//	{
//		bEPPflags.bits.dma_state = DMA_IDLE;
//
//		D12_SetDMA(0);
//		D12_SetDMA(D12_ENDP4INTENABLE | D12_ENDP5INTENABLE);
//	}
//}


// chap9.c
extern void padsend( void );

void ep1_txdone(void)
{
	D12_ReadLastTransactionStatus(3); /* Clear interrupt flag */
	padsend();
}

void ep1_rxdone(void)
{
	unsigned char len;

	D12_ReadLastTransactionStatus(2); /* Clear interrupt flag */

	len = D12_ReadEndpoint(2, GenEpBuf, sizeof(GenEpBuf));

	// 2003.02.15 N.SAWA �폜���܂���
	//if(len != 0)
	//	bEPPflags.bits.ep1_rxdone = 1;
}




// usbcom.c
void txsub( void );

void main_txdone(void)
{
	D12_ReadLastTransactionStatus(5); /* Clear interrupt flag */

	txsub();
}


//unsigned char *ppp = (unsigned char *)0x108000;

extern usbcom( char *pcmd, int len );

void main_rxdone(void)
{
	int len;
	unsigned char *p = usbcmdbuff;

	D12_ReadLastTransactionStatus(4); /* Clear interrupt flag */

//	//len = D12_ReadEndpoint(4, p, 64);
//	len = D12_ReadMainEndpoint(p);
//
//	if ( !len ) return;
//
////	*ppp++ = len;
//
//	usbcom( p, len );
// 2003.02.26 N.SAWA ���C���G���h�|�C���g�̃_�u���o�b�t�@�ɂQ�̃R�}���h�����܂�ƁA
//                   �܂Ƃ߂ĉ�ꂽ�R�}���h�Ƃ��Ĕj������Ă��܂��Ă����s����C���B
	while ( (len = D12_ReadEndpoint(4, p, 64)) != 0 ) {
		usbcom( p, len );
	}
}


void fn_usb_isr()
{
	unsigned int i_st;

	bEPPflags.bits.in_isr = 1;

	i_st = D12_ReadInterruptRegister();

	if(i_st != 0) {

		//dbgwrt1(0xaa);
		//dbgwrtn( &i_st, 2 );

		// 2003.02.15 N.SAWA �폜���܂���
		//if(i_st & D12_INT_BUSRESET) {
		//	bus_reset();
		//	bEPPflags.bits.bus_reset = 1;
		//}
		//else {
			//if(i_st & D12_INT_EOT) dma_eot();                            2003.02.15 N.SAWA �폜���܂���
			//if(i_st & D12_INT_SUSPENDCHANGE) bEPPflags.bits.suspend = 1; 2003.02.15 N.SAWA �폜���܂���

			if(i_st & D12_INT_ENDP0IN ) ep0_txdone();
			if(i_st & D12_INT_ENDP0OUT) ep0_rxdone();
			if(i_st & D12_INT_ENDP1IN ) ep1_txdone();
			if(i_st & D12_INT_ENDP1OUT) ep1_rxdone();
			if(i_st & D12_INT_ENDP2IN ) main_txdone();
			if(i_st & D12_INT_ENDP2OUT) main_rxdone();
		//}
	}

	bEPPflags.bits.in_isr = 0;
}


static char in_usb;

void usb_isr(void)
{
	INT_BEGIN2;

	//ClockIsr = ClockTicks;
	//DISABLE;

	//asm( "brk" );

	//D12Eval_outportb(0x0, 0x80);

	*(unsigned char *)0x40280 &= ~2;	// ���荞�݃N���A

	if ( !in_usb ) {
		in_usb = 1;
		//ENABLE;		// ���d���荞�݂͎~�߂܂��B
		fn_usb_isr();
		in_usb = 0;
	}

	//outportb(0x20, 0x20);

	//D12Eval_outportb(0x80, 0x80);

	//ENABLE;

	INT_END2;
}




//////////////////////////////////////////////////////////////////////////////





void InitUSB(void)
{
//	BOOL in_loop = TRUE;

	//printf( "start\n" );

	pceVectorSetTrap(17,usb_isr);

	pceVectorSetKs(KSNO_USBDisconnect, pceUSBDisconnect);
	pceVectorSetKs(KSNO_USBReconnect, pceUSBReconnect);
	pceVectorSetKs(KSNO_USBSetupMode, pceUSBSetupMode);

	/************************** Initialise SRAM  ****************************/
	//DISABLE; 2003.02.15 N.SAWA �K�v�Ȃ��Ɣ��f���āA�폜���܂���

	//init_port();
	//init_serial();
	//init_timer0();
	//init_special_interrupts();

	//printf("\nPDIUSBD12 evaluation board firmware V2.2.\n");
	//printf("Copyright (c) Philips Semiconductors, 1998.\n");

	/* Power on reset, lightup LEDs for 1 sec, */
	/* disconnect and reconnect Soft-Connect   */
	//printf("Re-connect PDIUSBD12 evaluation board to USB.\n");
	reconnect_USB();

    /*********************/ 
	/* Main program loop */
    /*********************/ 

}


void ProcUSB( void )
{
		// 2003.02.15 N.SAWA �폜���܂���
		//if (bEPPflags.bits.timer){
		//	DISABLE;
		//	bEPPflags.bits.timer = 0;
		//	ENABLE;
		//}

		// 2003.02.15 N.SAWA �폜���܂���
		//if (bEPPflags.bits.bus_reset) {
		//	DISABLE;
		//	bEPPflags.bits.bus_reset = 0;
		//	ENABLE;
		//} // if bus reset


		// 2003.02.15 N.SAWA �폜���܂���
		//if (bEPPflags.bits.suspend) {
		//	DISABLE;
		//	bEPPflags.bits.suspend= 0;
		//	ENABLE;
		//	suspend_change();
		//} // if suspend change


		if (bEPPflags.bits.setup_packet){
			DISABLE;
			bEPPflags.bits.setup_packet = 0;
			ENABLE;
			control_handler();
		} // if setup_packet


		// 2003.02.15 N.SAWA �폜���܂���
		//if(bEPPflags.bits.setup_dma) {
		//	DISABLE;
		//	bEPPflags.bits.setup_dma = 0;
		//	ENABLE;
		//	setup_dma();
		//} // if setup_dma
}



// 2003.02.15 N.SAWA �폜���܂���
//void suspend_change(void)
//{
//}



void stall_ep0(void)
{
	D12_SetEndpointStatus(0, 1);
	D12_SetEndpointStatus(1, 1);
}


// 2003.02.27 N.SAWA �폜���܂���
//void Stall_EP2(void)
//{
//	D12_SetEndpointStatus(4, 1);
//	D12_SetEndpointStatus(5, 1);
//}


void disconnect_USB(void)
{
	// Initialize D12 configuration
	D12_SetMode(0, D12_SETTOONE | D12_CLOCK_4M); // 2003.02.14 N.SAWA
}

void connect_USB(void)
{
	// 2003.02.15 N.SAWA �폜���܂���
	//// reset event flags
	//DISABLE;
	//bEPPflags.value = 0;
	//ENABLE;


	D12_SetEndpointStatus(4, 0);
	D12_SetEndpointStatus(5, 0);

	// V2.1 enable normal+sof interrupt
	D12_SetDMA(D12_ENDP4INTENABLE | D12_ENDP5INTENABLE);

	// Initialize D12 configuration
	D12_SetMode(D12_SOFTCONNECT, D12_SETTOONE | D12_CLOCK_4M); // 2003.02.14 N.SAWA
}



void reconnect_USB(void)
{
	unsigned long clk_cnt;

	disconnect_USB();

	//printf("Wait for 1 second ...");

	clk_cnt = ClockTicks;
	while(ClockTicks < clk_cnt + 200) pdwait(1000);

	//printf(" finish\n");

	connect_USB();
}



void init_unconfig(void)
{
	//unsigned char i;

	D12_SetEndpointEnable(0);	/* Disable all endpoints but EPP0. */
}



void init_config(void)
{
	D12_SetEndpointEnable(1);	/* Enable  generic/iso endpoints. */
}



void single_transmit(unsigned char * buf, unsigned char len)
{
	if( len <= EP0_PACKET_SIZE) {
		D12_WriteEndpoint(1, buf, len);
	}
}

#if 0
//void single_transmit_BOT(unsigned char * buf, unsigned char len)
//{
//	if( len <= EP0_PACKET_SIZE) {
//		D12_WriteEndpoint(4, buf, len);
//	}
//}
#endif

void code_transmit(unsigned char code * pRomData, unsigned short len)
{
	ControlData.wCount = 0;
	if(ControlData.wLength > len)
		ControlData.wLength = len;
#if 0
//	{
//		int i;
//		for ( i = 0; i < ControlData.wLength; i++ ) {
//			printf( "%02x ", pRomData[i] );
//		}
//		printf( "\n" );
//	}
#endif
	ControlData.pData = (unsigned char *)pRomData;
	if( ControlData.wLength >= EP0_PACKET_SIZE) {
		D12_WriteEndpoint(1, ControlData.pData, EP0_PACKET_SIZE);
		ControlData.wCount += EP0_PACKET_SIZE;
		DISABLE;
		bEPPflags.bits.control_state = USB_TRANSMIT;
		ENABLE;
	}
	else {
		D12_WriteEndpoint(1, (unsigned char *)pRomData, ControlData.wLength);
		ControlData.wCount += ControlData.wLength;
		DISABLE;
		bEPPflags.bits.control_state = USB_IDLE;
		ENABLE;
	}
}


#if 0
//void code_transmitEP2(unsigned char code * pRomData, unsigned short len)
//{
//	ControlData.wCount = 0;
//	if(ControlData.wLength > len)
//		ControlData.wLength = len;
//
//	ControlData.pData = pRomData;
//	if( ControlData.wLength >= EP2_PACKET_SIZE) {
//		D12_WriteEndpoint(5, ControlData.pData, EP2_PACKET_SIZE);
//		ControlData.wCount += EP2_PACKET_SIZE;
//
//		DISABLE;
////		bEPPflags.bits.control_state = USB_TRANSMIT;
////		bD12flags.bits.BOT_state = USBFSM4BOT_DATAIN;
//		ENABLE;
//	}
//	else {
//		D12_WriteEndpoint(5, pRomData, ControlData.wLength);
//		ControlData.wCount += ControlData.wLength;
//		DISABLE;
////		bEPPflags.bits.control_state = USB_IDLE;
////		bD12flags.bits.BOT_state = USBFSM4BOT_CSWPROC;
//		ENABLE;
//	}
//}
#endif





// 2003.02.15 N.SAWA �폜���܂���
//void setup_dma()
//{
//#if 0 //
//	if(!(ioRequest.bCommand & 0x80)) {
//		bEPPflags.bits.dma_disable = 1; // V2.1, x86 only
//		D12_SetDMA(D12_ENDP4INTENABLE | D12_ENDP5INTENABLE);
//		setup_io();
//
//		return;
//	}
//#endif
//
//	bEPPflags.bits.dma_disable = 0; // V2.1
//
//	//dma_start(&ioRequest);
//
//	DISABLE;
//	bEPPflags.bits.dma_state = DMA_RUNNING;
//	ENABLE;
//
////	single_transmit(0, 0);
//
//	if(ioRequest.bCommand & 0x1)
//	{
//		D12_SetDMA(0);
//		D12_SetDMA(D12_BURST_16 | D12_DMAENABLE | D12_DMA_INTOKEN);
//	}
//	else
//        {
//		D12_SetDMA(D12_BURST_16 | D12_DMAENABLE);
//        }
//}



void control_handler()
{
	unsigned char type, req;

	type = ControlData.DeviceRequest.bmRequestType & USB_REQUEST_TYPE_MASK;
	req = ControlData.DeviceRequest.bRequest & USB_REQUEST_MASK;

	//help_devreq(type, req); // print out device request

	if (type == USB_STANDARD_REQUEST) {
		(*StandardDeviceRequest[req])();
	}
	else if (type == USB_VENDOR_REQUEST) {
		//(*VendorDeviceRequest[req])();
	}
	else if (type == USB_CLASS_REQUEST) {
		//(*ClassDeviceRequest[0])();
	}
	else {
		stall_ep0();
	}
}

