
#include <stdio.h>
#include <piece.h>
#include "pcekn.h"

unsigned long _stklen = 100*1024;

// �e��G���[�̔�������

void div0( void )
{
	int a = 0;
	int b = 1;

	printf( "%d", b / a );
}

void aderr( void )
{
	unsigned long *p = (unsigned long *)0x12345;

	printf( "%d", *p );
}


void call0( void )
{
	void (*call)( int n ) = (void *)0;
	int a = 1234;
	int b = 5678;

	a *= b;

	call( 0x12345678 );
}

unsigned char buff[4096];

void File( void )
{
	FILEACC in;
	FILEACC out;

	if ( !pceFileOpen( &in, "ds.pex", FOMD_RD ) ) {
		if ( !pceFileCreate( "ds2.pex", in.fsize ) ) {
			if ( !pceFileOpen( &out, "ds2.pex", FOMD_WR ) ) {
				int sct = 0;
				unsigned long len = in.fsize;
				while ( len ) {
					unsigned long len2 = len;
					if ( len2 > 4096 ) len2 = 4096;
					pceFileReadSct( &in, buff, sct, len2 );
					pceFileWriteSct( &out, buff, sct, len2 );
					len -= len2;
					sct++;
				}
				pceFileClose( &out );
			}
		}
		pceFileClose( &in );
	}
}

void File2( void )
{
	//pceFileCreate( "ds.pex", 50*1024 );
	pceFileDelete( "ds.pex" );
}

unsigned long GetSP( void )
{
	asm( "ld.w %r10,%sp" );
	asm( "ret" );
	return 0;
}

void main( void )
{
	PCEALMTIME at;

	//div0();
	//aderr();
	//call0();
	void *p1 = pceHeapAlloc( 0x100 );
	void *p2 = pceHeapAlloc( 0x200 );
	void *p3 = pceHeapAlloc( 0x300 );
	void *p4 = pceHeapAlloc( 0x400 );
	void *p5 = pceHeapAlloc( 0x500 );
	pceHeapFree( p2 );
	pceHeapFree( p3 );
	pceHeapRealloc( p1, 0x20 );
	//File();

	printf( "SP=%x", GetSP() );

	//pceTimeGet( &at.time );
	//at.mode = ALM_ONESHOT;
	//at.time.mi+=2;
	//pceTimeSetAlarm( &at );
	
	pceVectorSetTrap(15,NULL);
	//SET_IL4;
//	ENTER_CS;
	{ int a = 4; a -= 3;
//	asm( "int 3" );
	}
//	LEAVE_CS;
	//asm( "call %r8" );

//	pcePowerForceBatt(1);
//	pcePowerEnterStandby(0);
}

