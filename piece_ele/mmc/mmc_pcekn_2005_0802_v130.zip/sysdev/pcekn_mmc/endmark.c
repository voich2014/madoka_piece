
unsigned char _endmark[4] = "END";
