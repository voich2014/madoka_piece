
#include <piece.h>

#define extern
#include "work.h"
