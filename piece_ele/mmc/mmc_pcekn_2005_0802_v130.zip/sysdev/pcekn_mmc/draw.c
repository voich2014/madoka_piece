/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : 
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by Miyakusa Masakazu (AQUAPLUS)
//
// Comments:
//
//  �`��֌W�T�|�[�g API �Q�ł��B
//
//  v1.00 2001.11.09 by Miyakusa Masakazu
//  v1.11 2001.12.03 by MIO.H  pceLCDPoint �̃o�O�C��
//  v1.19 2003.02.13 by N.SAWA pceLCDDrawObject()�̑����
//  v1.19 2003.03.29 by N.SAWA pceLCDDrawObject()�̓]�����N���b�s���O�𕜌�
//

#include <string.h>
#include <draw.h>
#include <work.h>
#include <vector.h>

#define vbuff lcdbuff

// 2003.02.13 N.SAWA
// pceLCDDrawObject()����Ăяo�����⏕�֐��̐錾�ł��B
// ���Ƃ��Ƃ������APDW_Draw_*()�⏕�֐��͍폜���܂����B
static void PDW_Draw_1BN( DRAW_OBJECT obj );
static void PDW_Draw_2BN( DRAW_OBJECT obj );
static void PDW_Draw_2BX( DRAW_OBJECT obj );

//!///// Piece Kernel Service API Reference
//! 
//! �� void pceLCDPoint(long color, long x, long y)
//! 
//! ���z�u�q�`�l��Ƀh�b�g��ł�
//!
//! unsigned char color :�F(0:�� 1:���D 2:�Z�D 3:��)
//! short x             :�w���W(0�`127)
//! short y             :�x���W(0�`87)
//! 
//! �߂�l�F�Ȃ�
//! 
//! �w����W���\�����W����O��鎞�͕`��͍s��Ȃ�
//! 
void pceLCDPoint(long color, long x, long y)
{
	if(x>=128)return;
	if(x<0)return;
	if(y>=88)return;
	if(y<0)return;	// v1.11 by MIO.H
	if(color > 3)color = 3;
	*(vbuff+y*128+x) = color;
}

//!///// Piece Kernel Service API Reference
//! 
//! �� void pceLCDLine(long color, long x1, long y1, long x2, long y2)
//! 
//! ���z�u�q�`�l��Ƀ��C����`��
//!
//! unsigned char color :�F(0:�� 1:���D 2:�Z�D 3:��)
//! short x1            :�n�_�w���W(0�`127)
//! short y1            :�n�_�x���W(0�`87)
//! short x2            :�I�_�w���W(0�`127)
//! short y2            :�I�_�x���W(0�`87)
//! 
//! �߂�l�F�Ȃ�
//! 
//! �w����W���\�����W����O��鎞�͕`��͍s��Ȃ�
//! 
void pceLCDLine(long color, long x1, long y1, long x2, long y2)
{
	int dx,dy,s,step;

	if(color > 3)color = 3;

	dx = abs(x2-x1);
	dy = abs(y2-y1);
	if(dx>dy){
		if(x1>x2){
			step = (y1 > y2)?1:-1;
			s = x1; x1 = x2; x2 = s;
			y1 = y2;
		}else{
			step = (y1 < y2)?1:-1;
		}
		*(vbuff+y1*128+x1) = color;
		s = dx>>1;
		while(++x1 <= x2){
			if((s -= dy) < 0){
				s+=dx;
				y1+=step;
			}
			*(vbuff+y1*128+x1) = color;
		}
	}else{
		if(y1>y2){
			step = (x1 > x2)?1:-1;
			s = y1; y1 = y2; y2 = s;
			x1 = x2;
		}else{
			step = (x1 < x2)?1:-1;
		}
		*(vbuff+y1*128+x1) = color;
		s = dy>>1;
		while(++y1 <= y2){
			if((s -= dx) < 0){
				s+=dy;
				x1+=step;
			}
			*(vbuff+y1*128+x1) = color;
		}
	}
}

//!///// Piece Kernel Service API Reference
//! 
//! �� void pceLCDPaint(long color, long x, long y, long w, long h)
//! 
//! ���z�u�q�`�l�ɋ�`��`��
//!
//! unsigned char color :�F(0:�� 1:���D 2:�Z�D 3:��)
//! short x             :�J�n�w���W(0�`127)
//! short y             :�J�n�x���W(0�`87)
//! short w             :��(0�`127)
//! short h             :����(0�`87)
//! 
//! �߂�l�F�Ȃ�
//! 
//! �w����W���\�����W����O��鎞�͕`��͍s��Ȃ�
//! 
void pceLCDPaint(long color, long x, long y, long w, long h)
{
	int i;

	if(x>=128)
		return;
	if(x<0){
		w+=x;
		x=0;
		if(w<=0)
			return;
	}
	if(y>=88)
		return;
	if(y<0){
		h+=y;
		y=0;
		if(h<=0)
			return;
	}
	if(x+w>=128)
		w=128-x;
	if(y+h>=88)
		h=88-y;
	if(color > 3)
		color = 3;

	for(i=y;i<y+h;i++){
		memset((pceLCDSetBuffer(INVALIDPTR)+i*128+x), color, w);
	}

}

//!///// Piece Kernel Service API Reference
//! 
//! �� void pceLCDSetObject(DRAW_OBJECT *obj, PIECE_BMP *src, int dx, int dy, int sx, int sy, int w, int h, int param )
//! 
//! ���z�u�q�`�l�ɃC���[�W�`�掞�̐ݒ�
//!
//! DRAW_OBJECT *obj    :�`����\����
//! PIECE_BMP *src      :�\������r�b�g�}�b�v�f�[�^
//! short dx            :�`��J�n�w���W(0�`127)
//! short dy            :�`��J�n�x���W(0�`87)
//! short dx            :�]�����w���W
//! short dy            :�]�����x���W
//! short w             :�`�敝(0�`127)
//! short h             :�`�捂��(0�`87)
//! 
//! �߂�l�F�Ȃ�
//! 
//! �w����W���\�����W����O��鎞�͕`��͍s��Ȃ�
//! 
void pceLCDSetObject(DRAW_OBJECT *obj, PIECE_BMP *src, int dx, int dy, int sx, int sy, int w, int h, int param )
{
	obj->dest = NULL;
	obj->dx   = dx;
	obj->dy   = dy;
	obj->dw   = w;
	obj->dh   = h;

	obj->src  = src;
	obj->sx   = sx;
	obj->sy   = sy;

	obj->clip.left   = 0;
	obj->clip.top    = 0;
	obj->clip.right  = DISP_X;
	obj->clip.bottom = DISP_Y;

	obj->param = param;
	obj->type  = TYPE_BMP;
}

//!///// Piece Kernel Service API Reference
//! 
//! �� int pceLCDDrawObject(DRAW_OBJECT dobj )
//! 
//! ���z�u�q�`�l�ɃC���[�W�`��
//!
//! DRAW_OBJECT dobj �w��̕`����\����
//! 
//! �߂�l�Fint 0:�`��Ȃ�
//!             1:�`�抮��
//! 
//! �w����W���\�����W����O��鎞�͕`��͍s��Ȃ�
//! 
int pceLCDDrawObject( DRAW_OBJECT obj )
{
	int x0, y0, x1, y1, n;
	PIECE_VRAM back_buf;

	// �]����ȗ����̊���l�ݒ�ipceLCDSetObject()���g���Ƃ����Ȃ�j
	if(!obj.dest) {
		back_buf.w = 128;
		back_buf.h = 88;
		back_buf.buf = vbuff;
		obj.dest = &back_buf;
	}

	// �]����N���b�s���O
	x0 = obj.clip.left   >           0 ? obj.clip.left   :           0;
	y0 = obj.clip.top    >           0 ? obj.clip.top    :           0;
	x1 = obj.clip.right  < obj.dest->w ? obj.clip.right  : obj.dest->w;
	y1 = obj.clip.bottom < obj.dest->h ? obj.clip.bottom : obj.dest->h;
	if(!(obj.param & DRW_REVX)) {
		if(obj.dx < x0) { n = x0 - obj.dx; obj.dx = x0; obj.dw -= n; obj.sx += n; }
		if(obj.dx + obj.dw > x1) { obj.dw = x1 - obj.dx; }
	} else {
		if(obj.dx < x0) { n = x0 - obj.dx; obj.dx = x0; obj.dw -= n; }
		if(obj.dx + obj.dw > x1) { n = obj.dx + obj.dw - x1; obj.dw -= n; obj.sx += n; }
	}
	if(obj.dw <= 0) return 0;
	if(!(obj.param & DRW_REVY)) {
		if(obj.dy < y0) { n = y0 - obj.dy; obj.dy = y0; obj.dh -= n; obj.sy += n; }
		if(obj.dy + obj.dh > y1) { obj.dh = y1 - obj.dy; }
	} else {
		if(obj.dy < y0) { n = y0 - obj.dy; obj.dy = y0; obj.dh -= n; }
		if(obj.dy + obj.dh > y1) { n = obj.dy + obj.dh - y1; obj.dh -= n; obj.sy += n; }
	}
	if(obj.dh <= 0) return 0;

	// �]�����N���b�s���O
	#define x0 0
	#define y0 0
	x1 = obj.src->header.w;
	y1 = obj.src->header.h;
	if(!(obj.param & DRW_REVX)) {
		if(obj.sx < x0) { n = x0 - obj.sx; obj.sx = x0; obj.dw -= n; obj.dx += n; }
		if(obj.sx + obj.dw > x1) { obj.dw = x1 - obj.sx; }
	} else {
		if(obj.sx < x0) { n = x0 - obj.sx; obj.sx = x0; obj.dw -= n; }
		if(obj.sx + obj.dw > x1) { n = obj.sx + obj.dw - x1; obj.dw -= n; obj.dx += n; }
	}
	if(obj.dw <= 0) return 0;
	if(!(obj.param & DRW_REVY)) {
		if(obj.sy < y0) { n = y0 - obj.sy; obj.sy = y0; obj.dh -= n; obj.dy += n; }
		if(obj.sy + obj.dh > y1) { obj.dh = y1 - obj.sy; }
	} else {
		if(obj.sy < y0) { n = y0 - obj.sy; obj.sy = y0; obj.dh -= n; }
		if(obj.sy + obj.dh > y1) { n = obj.sy + obj.dh - y1; obj.dh -= n; obj.dy += n; }
	}
	if(obj.dh <= 0) return 0;
	#undef x0
	#undef y0

	// �`�揈���Ăяo��
	switch(obj.src->header.bpp) {
	case 1:
		PDW_Draw_1BN(obj);
		break;
	case 2:
		switch(obj.param & DRW_PARAM) {
		case DRW_NOMAL:
			PDW_Draw_2BN(obj);
			break;
		case DRW_ADD:
		case DRW_SUB:
		case DRW_NOT:
		case DRW_HIGH:
		case DRW_LOW:
			PDW_Draw_2BX(obj);
			break;
		}
		break;
	}

	return TRUE;
}

static void PDW_Draw_2BN( DRAW_OBJECT obj )
{
	PIECE_VRAM dest;
	PIECE_BMP src;
	int n, x, y, step, dest_stride, src_stride;
	unsigned char *dest_buf, *src_mask, mask;
	unsigned short *src_buf, pixel;

	src = *obj.src;
	dest = *obj.dest;
	n = (src.header.w * obj.sy + obj.sx) / 8;
	src_buf = (unsigned short*)src.buf + n;
	src_mask = src.mask + n;
	src_stride = src.header.w / 8 - ((obj.sx & 7) + obj.dw - 1) / 8;

	switch(obj.param & DRW_REV) {
	case 0:
		dest_buf = dest.buf + dest.w * obj.dy + obj.dx;
		dest_stride = dest.w - obj.dw;
		y = obj.dh;
		if(!src.header.mask) {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				x = obj.dw;
				switch(step) {
LOOP_01:			pixel = *++src_buf;
#define PIXEL(p)	*dest_buf++ = pixel >> (p) * 2 & 3; if(--x == 0) break;
				case 0: PIXEL(3);
				case 1: PIXEL(2);
				case 2: PIXEL(1);
				case 3: PIXEL(0);
				case 4: PIXEL(7);
				case 5: PIXEL(6);
				case 6: PIXEL(5);
				default: PIXEL(4); goto LOOP_01;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
			} while(--y != 0);
		} else {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				mask = *src_mask;
				x = obj.dw;
				switch(step) {
LOOP_02:			pixel = *++src_buf;
					mask = *++src_mask;
#define PIXEL(p, m)	if(mask & (1 << (m))) *dest_buf = pixel >> (p) * 2 & 3; dest_buf++; if(--x == 0) break;
				case 0: PIXEL(3, 7);
				case 1: PIXEL(2, 6);
				case 2: PIXEL(1, 5);
				case 3: PIXEL(0, 4);
				case 4: PIXEL(7, 3);
				case 5: PIXEL(6, 2);
				case 6: PIXEL(5, 1);
				default: PIXEL(4, 0); goto LOOP_02;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
				src_mask += src_stride;
			} while(--y != 0);
		}
		break;
	case DRW_REVX:
		dest_buf = dest.buf + dest.w * obj.dy + obj.dx + obj.dw - 1;
		dest_stride = dest.w + obj.dw;
		y = obj.dh;
		if(!src.header.mask) {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				x = obj.dw;
				switch(step) {
LOOP_11:			pixel = *++src_buf;
#define PIXEL(p)	*dest_buf-- = pixel >> (p) * 2 & 3; if(--x == 0) break;
				case 0: PIXEL(3);
				case 1: PIXEL(2);
				case 2: PIXEL(1);
				case 3: PIXEL(0);
				case 4: PIXEL(7);
				case 5: PIXEL(6);
				case 6: PIXEL(5);
				default: PIXEL(4); goto LOOP_11;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
			} while(--y != 0);
		} else {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				mask = *src_mask;
				x = obj.dw;
				switch(step) {
LOOP_12:			pixel = *++src_buf;
					mask = *++src_mask;
#define PIXEL(p, m)	if(mask & (1 << (m))) *dest_buf = pixel >> (p) * 2 & 3; dest_buf--; if(--x == 0) break;
				case 0: PIXEL(3, 7);
				case 1: PIXEL(2, 6);
				case 2: PIXEL(1, 5);
				case 3: PIXEL(0, 4);
				case 4: PIXEL(7, 3);
				case 5: PIXEL(6, 2);
				case 6: PIXEL(5, 1);
				default: PIXEL(4, 0); goto LOOP_12;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
				src_mask += src_stride;
			} while(--y != 0);
		}
		break;
	case DRW_REVY:
		dest_buf = dest.buf + dest.w * (obj.dy + obj.dh - 1) + obj.dx;
		dest_stride = -dest.w - obj.dw;
		y = obj.dh;
		if(!src.header.mask) {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				x = obj.dw;
				switch(step) {
LOOP_21:			pixel = *++src_buf;
#define PIXEL(p)	*dest_buf++ = pixel >> (p) * 2 & 3; if(--x == 0) break;
				case 0: PIXEL(3);
				case 1: PIXEL(2);
				case 2: PIXEL(1);
				case 3: PIXEL(0);
				case 4: PIXEL(7);
				case 5: PIXEL(6);
				case 6: PIXEL(5);
				default: PIXEL(4); goto LOOP_21;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
			} while(--y != 0);
		} else {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				mask = *src_mask;
				x = obj.dw;
				switch(step) {
LOOP_22:			pixel = *++src_buf;
					mask = *++src_mask;
#define PIXEL(p, m)	if(mask & (1 << (m))) *dest_buf = pixel >> (p) * 2 & 3; dest_buf++; if(--x == 0) break;
				case 0: PIXEL(3, 7);
				case 1: PIXEL(2, 6);
				case 2: PIXEL(1, 5);
				case 3: PIXEL(0, 4);
				case 4: PIXEL(7, 3);
				case 5: PIXEL(6, 2);
				case 6: PIXEL(5, 1);
				default: PIXEL(4, 0); goto LOOP_22;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
				src_mask += src_stride;
			} while(--y != 0);
		}
		break;
	case DRW_REVX | DRW_REVY:
		dest_buf = dest.buf + dest.w * (obj.dy + obj.dh - 1) + obj.dx + obj.dw - 1;
		dest_stride = -dest.w + obj.dw;
		y = obj.dh;
		if(!src.header.mask) {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				x = obj.dw;
				switch(step) {
LOOP_31:			pixel = *++src_buf;
#define PIXEL(p)	*dest_buf-- = pixel >> (p) * 2 & 3; if(--x == 0) break;
				case 0: PIXEL(3);
				case 1: PIXEL(2);
				case 2: PIXEL(1);
				case 3: PIXEL(0);
				case 4: PIXEL(7);
				case 5: PIXEL(6);
				case 6: PIXEL(5);
				default: PIXEL(4); goto LOOP_31;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
			} while(--y != 0);
		} else {
			do {
				step = obj.sx & 7;
				pixel = *src_buf;
				mask = *src_mask;
				x = obj.dw;
				switch(step) {
LOOP_32:			pixel = *++src_buf;
					mask = *++src_mask;
#define PIXEL(p, m)	if(mask & (1 << (m))) *dest_buf = pixel >> (p) * 2 & 3; dest_buf--; if(--x == 0) break;
				case 0: PIXEL(3, 7);
				case 1: PIXEL(2, 6);
				case 2: PIXEL(1, 5);
				case 3: PIXEL(0, 4);
				case 4: PIXEL(7, 3);
				case 5: PIXEL(6, 2);
				case 6: PIXEL(5, 1);
				default: PIXEL(4, 0); goto LOOP_32;
#undef PIXEL
				}
				dest_buf += dest_stride;
				src_buf += src_stride;
				src_mask += src_stride;
			} while(--y != 0);
		}
		break;
	}
}

static void PDW_Draw_2BX( DRAW_OBJECT obj )
{
	static const BYTE AddTable[7] = { 0,1,2,3,3,3,3 }; // �O�a���Z�e�[�u��
	static const BYTE SubTable[7] = { 0,0,0,0,1,2,3 }; // �O�a���Z�e�[�u��
	//
	int   x, y, d, s;
	int   sssy, sssx, saddr;
	BYTE *dbuf = obj.dest->buf + obj.dy*obj.dest->w + obj.dx;
	int   dddx = obj.dest->w-obj.dw;
	BYTE *sbuf = obj.src->buf;
	BYTE *mask = obj.src->mask;

	if(obj.param&DRW_REVX){
		sssx = -1;
		if(obj.param&DRW_REVY) { sssy = -(obj.src->header.w-obj.dw); saddr = (obj.sy+obj.dh-1)*obj.src->header.w+obj.sx+obj.dw-1; }
		else                   { sssy =   obj.src->header.w+obj.dw ; saddr =  obj.sy          *obj.src->header.w+obj.sx+obj.dw-1; }
	}else{
		sssx = 1;
		if(obj.param&DRW_REVY) { sssy = -(obj.src->header.w+obj.dw); saddr = (obj.sy+obj.dh-1)*obj.src->header.w+obj.sx; }
		else                   { sssy =   obj.src->header.w-obj.dw ; saddr =  obj.sy          *obj.src->header.w+obj.sx; }
	}
	saddr*=2;
	sssx *=2;
	sssy *=2;

	for( y=0 ; y<obj.dh ; y++, dbuf+=dddx, saddr+=sssy ){
		for( x=0 ; x<obj.dw ; x++, dbuf++, saddr+=sssx ){
			if((!obj.src->header.mask) || (*(mask+(saddr>>4))&(0x80>>((saddr>>1)&7)))) {
				d = (*dbuf)&3; // ���zVRAM�̒l��0�`3�ł��邱�Ƃ͕ۏ؂ł��Ȃ��̂ŁA�O�̂��߃}�X�N���Ă���
				s = (*(sbuf+(saddr>>3))>>(6-(saddr&7)))&3;
				switch(obj.param & DRW_PARAM) {
				case DRW_ADD:  d = AddTable[  d+s]; break;
				case DRW_SUB:  d = SubTable[3+d-s]; break;
				case DRW_NOT:  d = 3-s; break; // ���́u~s�v�ƂȂ��Ă��܂����A�u3-s�v�̊ԈႢ���Ǝv���܂�
				case DRW_HIGH: d = (d&1) | (s&2); break;
				case DRW_LOW:  d = (d&2) | (s&1); break;
				}
				*dbuf = d;
			}
		}
	}
}

static void PDW_Draw_1BN( DRAW_OBJECT obj )
{
	//const static BYTE MaskTable[8] = { 0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01 }; // �r�b�g�}�X�N�p�e�[�u��
	//���Q�ƕp�x�������̂ŁA�����̎�Ԃ����������Ă��X�^�b�N��ɒu���������Q�Ƃ������Ȃ�͂��B�i���v���؁j
	//���������K�v�ȑ��ɎQ�Ǝ���ext���߂��Ȃ��Ȃ�̂ŁA�i���R�ɂ��j�R�[�h�T�C�Y�͕ω��Ȃ��ł��B
	const BYTE MaskTable[8] = { 0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01 }; // �r�b�g�}�X�N�p�e�[�u��
	//
	int   x, y;
	int   sssy, sssx, saddr;
	BYTE *dbuf = obj.dest->buf +obj.dy*obj.dest->w + obj.dx;
	int   dddx = obj.dest->w-obj.dw;
	BYTE *sbuf = obj.src->buf;
	int   cl1  = (obj.param   )&7;
	int   cl2  = (obj.param>>3)&7;

	if(obj.param&DRW_REVX){
		sssx = -1;
		if(obj.param&DRW_REVY) { sssy = -(obj.src->header.w-obj.dw); saddr = (obj.sy+obj.dh-1)*obj.src->header.w+obj.sx+obj.dw-1; }
		else                   { sssy =   obj.src->header.w+obj.dw ; saddr =  obj.sy          *obj.src->header.w+obj.sx+obj.dw-1; }
	}else{
		sssx = 1;
		if(obj.param&DRW_REVY) { sssy = -(obj.src->header.w+obj.dw); saddr = (obj.sy+obj.dh-1)*obj.src->header.w+obj.sx; }
		else                   { sssy =   obj.src->header.w-obj.dw ; saddr =  obj.sy          *obj.src->header.w+obj.sx; }
	}

	if(cl1!=COLOR_MASK) {
		if(cl2!=COLOR_MASK) {
			for( y=0 ; y<obj.dh ; y++, dbuf+=dddx, saddr+=sssy ){
				for( x=0 ; x<obj.dw ; x++, dbuf++, saddr+=sssx ){
					if( *(sbuf+(saddr>>3)) & MaskTable[saddr&7] ){
						*dbuf = cl1;
					}else{
						*dbuf = cl2;
					}
				}
			}
		} else {
			for( y=0 ; y<obj.dh ; y++, dbuf+=dddx, saddr+=sssy ){
				for( x=0 ; x<obj.dw ; x++, dbuf++, saddr+=sssx ){
					if( *(sbuf+(saddr>>3)) & MaskTable[saddr&7] ){
						*dbuf = cl1;
					}
				}
			}
		}
	} else {
		if(cl2!=COLOR_MASK) {
			for( y=0 ; y<obj.dh ; y++, dbuf+=dddx, saddr+=sssy ){
				for( x=0 ; x<obj.dw ; x++, dbuf++, saddr+=sssx ){
					if( !(*(sbuf+(saddr>>3))&MaskTable[saddr&7]) ){
						*dbuf = cl2;
					}
				}
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void InitDraw( void )
{
	pceVectorSetKs( KSNO_LCDPoint, pceLCDPoint);
	pceVectorSetKs( KSNO_LCDLine, pceLCDLine);
	pceVectorSetKs( KSNO_LCDPaint, pceLCDPaint);
	pceVectorSetKs( KSNO_LCDSetObject, pceLCDSetObject);
	pceVectorSetKs( KSNO_LCDDrawObject, pceLCDDrawObject);
}


