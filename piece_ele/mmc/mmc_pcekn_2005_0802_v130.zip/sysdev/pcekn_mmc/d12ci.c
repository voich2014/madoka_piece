/*
   *************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1997 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	D12CI.C
   // Author:		Wenkai Du
   // Created:		8 Jun 98
   // Modified:
   // Revision:		2.2
   //
   *************************************************************************
   //
   // 98/11/27      I/O mode Main endpoints read/write update (WK)
   // 98/12/2       Added D12_ReadMainEndpoint (WK)
   // 99/09/15		Support USB mass storage class (Buan Huat)
   *************************************************************************
   //  v1.19 2003.02.15 N.SAWA in_isr�łȂ����DISABLE/ENABLE�̃V�[�P���X���p�o���Ă��܂��B
   //                          �O���[�o���ϐ��̃r�b�g�e�X�g��C33�ł̓T�C�Y�R�X�g�������̂�
   //                          �֐��ɂ܂Ƃ߂ėe�ʍ팸���܂��B
   //  v1.19 2003.02.24 N.SAWA �g���Ă��Ȃ��֐����폜���ėe�ʍ팸���܂���
   //  v1.19 2003.02.26 N.SAWA D12_ReadMainEndpoint()���g��Ȃ��Ȃ����̂ō폜���܂����B
   */


#include <piece.h>
#include "pcekn.h"

#include "mainloop.h"
#include "d12ci.h"

#if 0
//
//#define D12_COMMAND 0x400004
//#define D12_DATA 0x400000
//
//
//
//void D12OutCmd( unsigned char dt )
//{
//	*(unsigned char *)D12_COMMAND = dt;
//}
//
//void D12OutDat( unsigned char dt )
//{
//	*(unsigned char *)D12_DATA = dt;
//}
//
//unsigned char D12InDat( void )
//{
//	return *(unsigned char *)D12_DATA;
//}
//
//void D12InDatN( unsigned char *p, unsigned len )
//{
//	do {
//		*p++ = *(unsigned char *)D12_DATA;
//	} while ( --len );
//}
//
#else

void D12OutCmd( unsigned char dt );
void D12OutDat( unsigned char dt );
unsigned char D12InDat( void );
void D12InDatN( unsigned char *p, unsigned len );
void D12OutDatN( unsigned char *p, unsigned len );
#endif

extern EPPFLAGS bEPPflags;

//{{2003.02.15 N.SAWA
static void BEGIN_USB() { if(bEPPflags.bits.in_isr == 0) DISABLE; }
static void END_USB()  { if(bEPPflags.bits.in_isr == 0) ENABLE;  }
//}}2003.02.15 N.SAWA

void D12_SetAddressEnable(unsigned char bAddress, unsigned char bEnable)
{
	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0xD0);
	if(bEnable)
		bAddress |= 0x80;
	D12OutDat(bAddress);

	END_USB(); // 2003.02.15 N.SAWA
}

void D12_SetEndpointEnable(unsigned char bEnable)
{
	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0xD8);
	if(bEnable)
		D12OutDat(1);
	else
		D12OutDat(0);

	END_USB(); // 2003.02.15 N.SAWA
}

void D12_SetMode(unsigned char bConfig, unsigned char bClkDiv)
{
	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0xF3);
	D12OutDat(bConfig);
	D12OutDat(bClkDiv);

	END_USB(); // 2003.02.15 N.SAWA
}

void D12_SetDMA(unsigned char bMode)
{
	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0xFB);
	D12OutDat(bMode);

	END_USB(); // 2003.02.15 N.SAWA
}

unsigned short D12_ReadInterruptRegister(void)
{
	unsigned char b1;
	unsigned int j;

	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0xF4);
	b1 = D12InDat();
	j = D12InDat();

	j <<= 8;
	j += b1;

//	printf( "intreg=%04x\n", j );

	END_USB(); // 2003.02.15 N.SAWA

	return j;
}

unsigned char D12_SelectEndpoint(unsigned char bEndp)
{
	unsigned char c;

	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(bEndp);
	c = D12InDat();

	END_USB(); // 2003.02.15 N.SAWA

	return c;
}

unsigned char D12_ReadLastTransactionStatus(unsigned char bEndp)
{
	unsigned char c;

	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0x40 + bEndp);
	c = D12InDat();

	END_USB(); // 2003.02.15 N.SAWA

	return c;
}

// 2003.02.24 N.SAWA �폜���܂����B
//unsigned char D12_ReadEndpointStatus(unsigned char bEndp)
//{
//	unsigned char c;
//
//	BEGIN_USB(); // 2003.02.15 N.SAWA
//
//	D12OutCmd(0x80 + bEndp);
//	c = D12InDat();
//
//	END_USB(); // 2003.02.15 N.SAWA
//
//	return c;
//}

void D12_SetEndpointStatus(unsigned char bEndp, unsigned char bStalled)
{
	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(0x40 + bEndp);
	D12OutDat(bStalled);

	END_USB(); // 2003.02.15 N.SAWA
}

// 2003.02.24 N.SAWA �폜���܂����B
//void D12_SendResume(void)
//{
//	D12OutCmd(0xF6);
//}

// 2003.02.24 N.SAWA �폜���܂����B
//unsigned short D12_ReadCurrentFrameNumber(void)
//{
//	unsigned short i,j;
//
//	BEGIN_USB(); // 2003.02.15 N.SAWA
//
//	D12OutCmd(0xF5);
//	i= D12InDat();
//	j = D12InDat();
//
//	i += (j<<8);
//
//	END_USB(); // 2003.02.15 N.SAWA
//
//	return i;
//}

// 2003.02.24 N.SAWA �폜���܂����B
//unsigned short D12_ReadChipID(void)
//{
//	unsigned short i,j;
//
//	BEGIN_USB(); // 2003.02.15 N.SAWA
//
//	D12OutCmd(0xFD);
//	i=D12InDat();
//	j=D12InDat();
//	i += (j<<8);
//
//	END_USB(); // 2003.02.15 N.SAWA
//
//	return i;
//}



unsigned char D12_ReadEndpoint(unsigned char endp, unsigned char * buf, unsigned char len)
{
	unsigned char /*i,*/ j;

	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(endp);
	if((D12InDat() & D12_FULLEMPTY) == 0) {
		END_USB(); // 2003.02.15 N.SAWA
		return 0;
	}

	D12OutCmd(0xF0);
	j = D12InDat();
	j = D12InDat();

	if(j > len)
		j = len;

	//for(i=0; i<j; i++) *(buf+i) = D12InDat();
	D12InDatN(buf,j);

//	if ( endp == 0 ) {
//		dbgwrtn(buf,j);
//	}

	D12OutCmd(0xF2);

	END_USB(); // 2003.02.15 N.SAWA

	return j;
}



#if 0
//unsigned char D12_ReadMainEndpoint(unsigned char * buf)
//{
//	unsigned char i, j;
//
//	if(bEPPflags.bits.in_isr == 0)
//		DISABLE;
//
//
//	D12OutCmd(4);
//	if((D12InDat() & D12_FULLEMPTY) == 0) {
//		if(bEPPflags.bits.in_isr == 0)
//			ENABLE;
//		return 0;
//	}
//
//
//	D12OutCmd(0xF0);
//	j = D12InDat();
//	j = D12InDat();
//
////	if(j > len)
////		j = len;
//
//	for(i=0; i<j; i++)
//		*(buf+i) = D12InDat();
//
//	D12OutCmd(0xF2);
//
//
//	if(bEPPflags.bits.in_isr == 0)
//		ENABLE;
//
//	return j;
//}
#endif

// 2003.02.26 N.SAWA �폜���܂����B
//#if 1
//// D12_ReadMainEndpoint() added by V2.2 to support double-buffering.
//// Caller should assume maxium 128 bytes of returned data.
//unsigned char D12_ReadMainEndpoint(unsigned char * buf)
//{
//	unsigned char /*i,*/ j, /*ju,*/ k = 0, bDblBuf = 1;
//
//	BEGIN_USB(); // 2003.02.15 N.SAWA
//
//	D12OutCmd(0x84);
//	if( (D12InDat() & 0x60) == 0x60)
//		bDblBuf = 2;
//
//	while(bDblBuf) {
//		D12OutCmd(4);
//		if((D12InDat() & D12_FULLEMPTY) == 0)
//			break;
//
//		D12OutCmd(0xF0);
//		j = D12InDat();
//		j = D12InDat();
//		//ju = j;
//
//		//for(i=0; i<j; i++) *(buf+i+k) = D12InDat();
//		D12InDatN(buf+k,j);
//	
//		k += j;
//
//		D12OutCmd(0xF2);
//
//		bDblBuf --;
//	}
//
//	END_USB(); // 2003.02.15 N.SAWA
//
//	return k;
//}
//#endif



unsigned char D12_WriteEndpoint(unsigned char endp, unsigned char * buf, unsigned char len)
{
//	unsigned char i;

//	if ( !len ) return len;

// len == 0 �̂Ƃ��ł��ȉ���ʂ�K�v������悤�ł��B

	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(endp);
	D12InDat();

	D12OutCmd(0xF0);
	D12OutDat(0);
	D12OutDat(len);

//	for(i=0; i<len; i++) D12OutDat(*(buf+i));
	if ( len ) D12OutDatN(buf,len);
//	if (endp == 1) {
//		dbgwrtn(buf,len);
//	}

	D12OutCmd(0xFA);

	END_USB(); // 2003.02.15 N.SAWA

	return len;
}

void D12_AcknowledgeEndpoint(unsigned char endp)
{
	BEGIN_USB(); // 2003.02.15 N.SAWA

	D12OutCmd(endp);
	D12OutCmd(0xF1);
	if(endp == 0)
		D12OutCmd(0xF2);

	END_USB(); // 2003.02.15 N.SAWA
}

