
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
//  �J�[�l�����̎�v���[�N�G���A�̒�`�ł��B
//  ���̂� -> work.c
//
//  v1.00 2001.11.09 MIO.H
//  v1.01 2001.11.10 MIO.H
//  v1.13 2001.12.13 MIO.H
//  v1.14 2001.12.21 MIO.H
//  v1.16 2002.01.05 MIO.H
//  v1.17 2002.01.13 MIO.H
//


// structure

extern SYSTEMINFO system_info;
extern PCEPWRSTAT pows;
extern unsigned short adc_v[2];

// long
extern unsigned long crc_val;
extern unsigned long apptm_wk;
extern unsigned long opetm_wk;
extern unsigned long sbtm_limit;

extern unsigned long *curapp;
extern unsigned long *smf;
extern unsigned long appcnt;

extern unsigned char *lcdbuff;
extern unsigned char *save_lcdbuff;

extern unsigned char *fnt_hp;
extern unsigned char *fnt_zp;

extern HEAPMEM *heaptop;

extern void (*contextsw)( void );

// short
extern unsigned short appcnt2;
extern unsigned short appstat;

extern signed short DispX, DispY;
extern signed short save_DispX, save_DispY;

extern unsigned short alarm_dh;

// char
extern char exec_fname[12+1];

extern unsigned char pagedir;
extern unsigned char brightness;
extern unsigned char pad_data;
extern unsigned char pad_trig;
extern unsigned char clkp1;
extern unsigned char clkp2;

extern unsigned char fnt_dt;
extern unsigned char fnt_dth;
extern unsigned char fnt_hb;
extern unsigned char fnt_zb;
extern unsigned char fnt_zc;
extern unsigned char fnt_typ;
extern unsigned char fnt_txc;
extern unsigned char fnt_bkc;

extern unsigned char save_fnt_typ;
extern unsigned char save_fnt_txc;
extern unsigned char save_fnt_bkc;

extern unsigned char powerdisp;

extern unsigned char usbmode;

extern unsigned char proc_period;
extern unsigned char save_proc_period;

extern unsigned char opetm_type;

extern unsigned char pause_stat;

extern unsigned char alarm_flag;

extern unsigned char use_dma;

extern unsigned char adc_flg;

extern unsigned char snd_flg;

