
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
//  �t���b�V���������̏������[�`���ł��B
//
//  v1.00 2001.11.09 MIO.H
//  v1.06 2001.11.24 MIO.H �E�G�C�g���Ƀp���[�_�E��
//  v1.19 2003.02.25 N.SAWA �t���b�V���������I�[�A�h���X���ς�
//



#include <piece.h>
#include "pcekn.h"


int subFlashErase( volatile unsigned short *romp )
{
	volatile unsigned short *c1p = (unsigned short *)(0xc00000 + 0x5555*2);
	volatile unsigned short *c2p = (unsigned short *)(0xc00000 + 0x2aaa*2);

	if ( romp < (volatile unsigned short *)0xc02000 ) return 1;
	//if ( romp > (volatile unsigned short *)0xc7ffff ) return 1;
	if ( romp > (volatile unsigned short *)(((int)PFFSEND)-1) ) return 1; // 2003.02.25 N.SAWA

	romp = (volatile unsigned short *)( ((unsigned)romp) &= ~0xfff );

	if ( romp != NULL ) {
		int i;
		for ( i = 0; i < 2048; i++ ) {
			if ( romp[i] != 0xffff ) goto _erase;
		}
		return 0;
	}
_erase:

	*c1p = 0xaa;
	*c2p = 0x55;
	*c1p = 0x80;
	*c1p = 0xaa;
	*c2p = 0x55;
//	if ( romp == NULL ) {
//		*c1p = 0x10;	// 0x10 : chip erase
//	}
//	else {
		*romp = 0x30;		// 0x30 : sector erase
//		*romp = 0x50;		// 0x50 : block erase
//	}

	{
		int i;
		for ( i = 0; i < 8; i++ ) {
			unsigned short d;
			int n=10*1000;
			while ( *romp != 0xffff ) {
				pdwait(5);
				if ( --n < 0 ) {
					return 1;
				}
			}
			d = *romp++;
		}
	}

	return 0;
}



