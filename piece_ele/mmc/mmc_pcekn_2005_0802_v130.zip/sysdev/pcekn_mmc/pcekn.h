// v1.19 2003.02.25 N.SAWA PFFSEND���ςɁB

#include <s1c33cpu.h>
#include "vector.h"
#include "work.h"
#include "pieceerr.h"


// �萔
//
#define SRAMTOP ((unsigned char *)0x100000)
#define SRAMEND system_info.sram_end
#define PFFSTOP ((unsigned char *)0xc28000)
//#define PFFSEND ((unsigned char *)0xc80000)
#define PFFSEND system_info.pffs_end	// 2003.02.25 N.SAWA

#define INVALIDLCDBUFFER ((void *)0x1000001)

#define APPSTARTPOS1 ((pceAPPHEAD *)0x100000)
#define APPSTARTPOS2 ((pceAPPHEAD *)0x138000)

#define SYSERRVBUFF ((unsigned char *)0x13c000)

#define INITAPPEXTBUFF ((void *)0x13e000)


// I/O�̃A�h���X
//
extern unsigned char iobaseptr[];
#define iop_c ((volatile unsigned char *)iobaseptr)
#define iop_s ((volatile unsigned short *)iobaseptr)
#define iop_l ((volatile unsigned long *)iobaseptr)
#define iop_b ((volatile unsigned char *)iobaseptr)
#define iop_h ((volatile unsigned short *)iobaseptr)
#define iop_w ((volatile unsigned long *)iobaseptr)


// �e�\�[�X

// hard.c
void InitHard( unsigned long trap_table_adrs );
void InitHard2( void );
void GetSysClock( void );
extern void pdwait( int n );

// lcd.c
void InitLCD( void );

// usb.c
void InitUSB( void );

// timer.c
void InitTimer( void );
extern volatile unsigned long ClockTicks;

// irsub.c
void InitIR( void );

// pad.c
void InitPad( void );
void setPadRepeatTime( void );

// font.c
void InitFont( void );
void PushFontParameters( void );
void PopFontParameters( void );

// runapp.c
void AppStart( void );

// snd.c
void InitSound( void );
int sndSetPowersave( int mode );

// file.c
void InitFile( void );

// rtc.c
void InitRTC( void );

// powerman.c
void InitPower( void );

// draw.c
void InitDraw( void );

// usbcom.c or other usb
void InitUSBCOM( void );
void ProcUSB( void );

// syserr.c
void InitError( void );
void APIErr( unsigned long param, unsigned long errcode );

// heapman.c
void InitHeapman( void );
void ResetHeap( void *memp );

// builtin app.
void pceAppInit( void );
void pceAppProc( int cnt );
void pceAppExit( void );
int pceAppNotify( int type, int param );
void biapp_init( void );

// setpsr.s

typedef unsigned long CRITICAL_SECTION;

void pceSyncEnterCriticalSection( CRITICAL_SECTION *pcs );
void pceSyncLeaveCriticalSection( CRITICAL_SECTION *pcs );

typedef unsigned long SEMAPHORE;

void pceSyncCreateSemaphore( SEMAPHORE *psm, int max, int now );
int pceSyncGetSemaphore( SEMAPHORE *psm, int wait );
int pceSyncReleaseSemaphore( SEMAPHORE *psm );

typedef signed long SYNCVAR;

SYNCVAR pceSyncSafetyAddition( SYNCVAR *pval, SYNCVAR delta );

void pceSyncSafetySetIL( int level );


// critical.c
void CriticalKSEntry( void );

void SyncEnterCriticalSection( CRITICAL_SECTION *pcs );
void SyncLeaveCriticalSection( CRITICAL_SECTION *pcs );
void SyncSafetySetIL( int level );
void SyncSafetyAddition( SYNCVAR *pval, SYNCVAR delta );


// snd.c
extern SYNCVAR snd_proccnt;


// fmacc.c
void InitFlashAcc( void ); // 2003.02.14 N.SAWA

// mmc_api.c
void InitMMC_API(void);								// 2004.05.03 Madoka
unsigned char mmcInit(unsigned long ulMaxFileSize);	// 2004.05.13 Madoka
void mmcExit(void);									// 2004.05.13 Madoka

//file.c
int mmcFileLoad(const char *name);	// 2004.05.03 Madoka


#define SET_SIL0 pceSyncSafetySetIL(0)
#define SET_SIL1 pceSyncSafetySetIL(1)
#define SET_SIL2 pceSyncSafetySetIL(2)
#define SET_SIL3 pceSyncSafetySetIL(3)
#define SET_SIL4 pceSyncSafetySetIL(4)
#define SET_SIL5 pceSyncSafetySetIL(5)
#define SET_SIL6 pceSyncSafetySetIL(6)
#define SET_SIL7 pceSyncSafetySetIL(7)

#define ENTER_CS {CRITICAL_SECTION __cs__; pceSyncEnterCriticalSection( &__cs__ );
#define LEAVE_CS pceSyncLeaveCriticalSection( &__cs__ );}


//
//	����RAM�ւ̃R�[�h�̃R�s�[���ȕւɍs���}�N���ł��B
//
#define FRAMCOPY(dstsect,srcsect)\
{\
extern unsigned long __START_##dstsect[];\
extern unsigned long __START_##srcsect[];\
extern unsigned long __SIZEOF_##srcsect[];\
	memcpy(\
		&__START_##dstsect,\
		&__START_##srcsect,\
		(unsigned)&__SIZEOF_##srcsect\
	);\
}

#define FRAMCLEAR(dstsect,srcsect)\
{\
extern unsigned long __START_##dstsect[];\
extern unsigned long __SIZEOF_##srcsect[];\
	memset(\
		&__START_##dstsect,\
		0,\
		(unsigned)&__SIZEOF_##srcsect\
	);\
}

