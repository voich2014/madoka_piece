make 
make img
make bios
