
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
//  WAVE�o�͗p�̃A�Z���u���ɂ�鍂�����[�`���ł��B
//
//  v1.00 2001.11.09 MIO.H
//



	.global	make_xwave16_fast

make_xwave16_fast:

__LX10:				; __L10:

	ld.h	%r10,[%r13]+
	mlt.h	%r10,%r15
	ld.w	%r10,[%r12]
	ld.w	%r11,%alr
	add	%r10,%r11
	ld.w	[%r12]+,%r10

	sub	%r14,1
	jrne	__LX10

	ld.w	%r10,%r13

	ret

	.global	make_xwave8_fast

make_xwave8_fast:

	xld.w	%r11,-128	; 0xffffff80

__LX15:				; __L15:

	ld.ub	%r10,[%r13]+
	add	%r10,%r11
	sll	%r10,8
	mlt.h	%r10,%r15
	ld.w	%r10,[%r12]
	ld.w	%r4,%alr
	add	%r10,%r4
	ld.w	[%r12]+,%r10

	sub	%r14,1
	jrne	__LX15

	ld.w	%r10,%r13

	ret


	.global	make_buff44_fast

;make_buff44_fast:
;	xld.w	%r4,544		; PWMC2
;	add	%r13,2
;__LX20:
;	ld.h	%r10,[%r13]
;	add	%r10,%r4
;	add	%r15,%r10
;	srl	%r15,1
;	ld.h	[%r12]+,%r15
;	add	%r13,4
;	ld.h	[%r12]+,%r10
;
;	sub	%r14,1
;	jrne.d	__LX20
;	ld.w	%r15,%r10	; (�f�B���C�h�Ή�!!)
;
;	ret

make_buff44_fast:
	xld.w	%r5,749			; PWMC2
	xld.w	%r4,1499		; PWMC*2-1
	add	%r13,2
make_buff44_loop:
	ld.h	%r10,[%r13]

	add	%r10,%r5
	cmp	%r10,%r4		; +1
	jrugt	make_buff44_clip	; +1
make_buff44_cont:
	add	%r15,%r10
	srl	%r15,1
	ld.h	[%r12]+,%r15
	add	%r13,4
	ld.h	[%r12]+,%r10

	sub	%r14,1
	jrne.d	make_buff44_loop
	ld.w	%r15,%r10		;delay
	ret

make_buff44_clip:
	cmp	%r10,0
	jrge.d	make_buff44_cont
	ld.w	%r10,%r4		;delay
	jp.d	make_buff44_cont
	ld.w	%r10,0			;delay

	.endfile

