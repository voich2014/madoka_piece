
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
//  �t���b�V���������̏������݃��[�`���ł��B
//
//  v1.00 2001.11.09 MIO.H
//  v1.19 2003.02.25 N.SAWA �t���b�V���������I�[�A�h���X���ς�
//

#include <piece.h>
#include "pcekn.h"



int subFlashWrite( volatile unsigned short *romp, unsigned char *memp, int len )
{
	volatile unsigned short *c1p = (unsigned short *)(0xc00000+0x5555*2);
	volatile unsigned short *c2p = (unsigned short *)(0xc00000+0x2aaa*2);

	if ( romp < (volatile unsigned short *)0xc02000 ) return 1;
	//if ( romp > (volatile unsigned short *)0xc7ffff ) return 1;
	if ( romp > (volatile unsigned short *)(((int)PFFSEND)-1) ) return 1; // 2003.02.25 N.SAWA

	*c1p = 0xf0;

	do {
		unsigned short d = memp[0] + (memp[1]<<8);
		memp += 2;
		if ( d != 0xffff && d != *romp ) {
			*c1p = 0xaa;
			*c2p = 0x55;
			*c1p = 0xa0;
			*romp  = d;
			asm( "nop" );
#if 0
			{
				unsigned short an, ao = *romp;
				while ( 1 ) {
					an = *romp;
					if ( !( ( an ^ ao ) & 0x40 ) ) break;
					ao = an;
				}
			}
#else
			while ( (d ^ *romp) & 0x80 );
#endif
		}
		romp++;
	} while ( --len );

	*c1p = 0xf0;

	return 0;
}




