
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
//  �s����O���̏�����ł��B
//  
//  �e���W�X�^���_���v���āA�������[�v�ɓ���܂��B
//  
//  v1.00 2001.11.09 MIO.H
//  v1.01 2001.11.10 MIO.H 4x6�h�b�g�t�H���g�ɑΉ�
//  v1.03 2001.11.20 MIO.H API�G���[
//



#include <piece.h>
#include <string.h>
#include "pcekn.h"


static const char *const trapname[8] = {
	"Call address 0",			// 0  �{����Reset�ł����A���Ӗ��Ȃ̂Łc
	"PIECE API Error #%d",		// 1  �������g�����Ⴂ�܂��傤
	NULL,						// 2
	NULL,						// 3
	"Zero division",			// 4
	NULL,						// 5
	"Address error exception",	// 6
	"NMI",						// 7
};

static void disp_factor( int n, unsigned long params )
{
	pceFontPrintf( "!! TRAP\n" );

	if ( n < 8 && trapname[n] ) {
		pceFontPrintf( trapname[n], params );
		pceFontPutStr( "\n" );
	}
	else {
		pceFontPrintf( "Vector no=%02x\n", n );
	}
}


void disp_error( int fn, unsigned long *ip )
{
	int i;
	ip += 2;
	disp_factor( fn, ip[13] );
	pceFontSetType(0x82);
	pceFontPrintf( "PC =%08X PSR=%08X\n", ip[16+1], ip[16+0] );
	pceFontPrintf( "SP =%08X(SP)=%08X\n", ip+18, ip[18] );
	for ( i = 0; i < 8; i++ ) {
		pceFontPrintf( "R%-2d=%08X R%-2d=%08X\n", i, ip[i], i+8, ip[i+8] );
	}
	pceFontPrintf( "AHR=%08X ALR=%08X\n", ip[-1], ip[-2] );
}


void _error( int fn, unsigned long *ip )
{
//	asm( "xld.w	%r9,0x2000" );
//	asm( "ld.w	%sp,%r9" );
	SET_SIL7;

	{
		unsigned char *vbuff = SYSERRVBUFF;

		pceLCDSetBuffer( vbuff );
		pceFontSetType( 0x80 );
		pceFontSetTxColor( 3 );
		pceFontSetBkColor( 0 );
		pceLCDSetOrientation( 0 );
		memset( vbuff, 0, 128*88 );

		pceFontSetPos( 0, 0 );

		disp_error( fn, ip );

		pceLCDTrans();
		pceLCDDispStart();
	}

	SET_SIL0;

	while ( 1 ) pdwait( 10000 );
}





static void biDiv0_ent( void )
{
	INT_BEGIN2;
	asm( "ld.w	%r12,4" );
	asm( "ld.w	%r13,%sp" );
	asm( "jp	_error" );
}

static void biAder_ent( void )
{
	INT_BEGIN2;
	asm( "ld.w	%r12,6" );
	asm( "ld.w	%r13,%sp" );
	asm( "jp	_error" );
}
#if 0
static void biNMI_ent( void )
{
	INT_BEGIN2;
	asm( "ld.w	%r12,7" );
	asm( "ld.w	%r13,%sp" );
	asm( "jp	_error" );
}
#endif
static void biCall0_ent( void )
{
	asm( "sub	%sp,1" );			// PSR �̗̈�m��
	INT_BEGIN2;
	asm( "ld.w	%r10,%psr" );
	asm( "ld.w	[%sp+18],%r10" );	// PSR�������Ă����c
	asm( "ld.w	%r12,0" );
	asm( "ld.w	%r13,%sp" );
	asm( "jp	_error" );
}

void APIErr( unsigned long param, unsigned long errcode )
{
	asm( "sub	%sp,1" );			// PSR �̗̈�m��
	INT_BEGIN2;
	asm( "ld.w	%r10,%psr" );
	asm( "ld.w	[%sp+18],%r10" );	// PSR�������Ă����c
	asm( "ld.w	%r12,1" );
	asm( "ld.w	%r13,%sp" );
	asm( "jp	_error" );
}


void InitError( void )
{
	pceVectorSetTrap( 4, biDiv0_ent );
	pceVectorSetTrap( 6, biAder_ent );
//	pceVectorSetTrap( 7, biNMI_ent );
	{
		unsigned short *sp = (unsigned short *)0;
		long x = (long)biCall0_ent - (long)&sp[2];
		x >>= 1;
		sp[2] = 0x1e00 + (x & 0xff);	// jp sign8
		x >>= 8;
		sp[1] = 0xc000 + (x & 0x1fff);	// ext imm13
		x >>= (13-3);
		sp[0] = 0xc000 + (x & 0x1fff);	// ext imm13
	}
}



