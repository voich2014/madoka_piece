;  
;	Copyright (C) SEIKO EPSON CORP. 1997 - 1998
;
;	flash memory demonstration command "led2.cmd"
;		1)execute chip erase
;		2)load program to flash memory
;		3)TTBR set 0x200000
;
;		M.Igarashi	98/09/03
;		M.Kudo		99/03/18 	modify
lf ..\flash\sst39vf400.srf	;load flash erase and write routine to IRAM area
fls				;flash set command
1				;1:set 2:clear
c00000				;flash area start address is 0xc00000
cfffff				;flash area end address is 0xcfffff
FLASH_ERASE			;flash erase routine top address
FLASH_LOAD			;flash load routine top address
fle				;flash erase command
c00000				;flash contorol regester is 0xc00000
1				;erase start block 0:all area 1-19:section
32				;erase end block 1-19:sector if start block is 0 ,then this parameter is ignored.
lf pcekn.srf
