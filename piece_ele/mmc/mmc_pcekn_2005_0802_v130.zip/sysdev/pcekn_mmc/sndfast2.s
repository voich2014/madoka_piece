
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by Katsumasa Tsuneyoshi
//
// Comments:
//
//  WAVE�o��(ADPCM)�p�̃A�Z���u���ɂ�鍂�����[�`���ł��B
//
//  v1.00 2001.11.27 Katsumasa Tsuneyoshi
//

	.global	make_xwavead1_fast

make_xwavead1_fast:
;r1����->16000
	pushn	%r3
	add	%r13,2
	ld.uh	%r0,[%r13]+
	ld.w	%r7,[%r13]
	add	%r13,16
	ld.h	%r6,[%r13]+
	ld.h	%r5,[%r13]+
	ld.h	%r4,[%r13]+
	mlt.h	%r5,%r15
	ld.uh	%r11,[%r13]
	sub	%r13,6
	xld.w	%r2,dct+16
	xld.w	%r1,16000
__L25:
	sub	%r11,%r0
	xjruge	__L28
	add	%r11,%r1
	cmp	%r4,0x0
	xjrne	__L29
	ld.ub	%r4,[%r7]+
	ld.w	%r10,%r4
	xsra	%r10,4
	jp.d	__L30
	or	%r4,0x10	;delay
__L29:
	ld.w	%r10,%r4
	xand	%r10,%r10,0x0000000f
	ld.w	%r4,0x0
__L30:
	sub	%r10,8
	mlt.h	%r6,%r10
	ld.w	%r3,%alr
	add	%r5,%r3
	xsll	%r10,1
	add	%r10,%r2
	xld.h	%r10,[%r10]
	mlt.h	%r6,%r10
	ld.w	%r6,%alr
	xsra	%r6,8
	mlt.h	%r5,%r15
__L28:
	xld.w	%r10,[%r12]
	ld.w	%r3,%alr
	add	%r10,%r3
	ld.w	[%r12]+,%r10
	xsub	%r14,%r14,1
	xjrne	__L25
	ld.h	[%r13]+,%r6
	ld.h	[%r13]+,%r5
	ld.h	[%r13]+,%r4
	ld.h	[%r13],%r11
	ld.w	%r10,%r7
	popn	%r3
	ret
