
/////////////////////////////////////////////////////////////////////////////
//
//             /
//      -  P  /  E  C  E  -
//           /                 mobile equipment
//
//              System Programs
//
//
// PIECE KERNEL : Ver 1.00
//
// Copyright (C)2001 AUQAPLUS Co., Ltd. / OeRSTED, Inc. all rights reserved.
//
// Coded by MIO.H (OeRSTED)
//
// Comments:
//
//  �g�ݍ��݃A�v���ł��B
//  ���̓V�X�e�����j���[���̂��̂ł��B
//  �܂��A�K�؂� startup.pex ��������Ȃ������ꍇ���N�����܂��B
//  ���҂ł́A�N���̃v���Z�X���኱�قȂ�܂��B
//
//  v1.00 2001.11.09 MIO.H
//  v1.01 2001.11.10 MIO.H ����̕ύX
//  v1.04 2001.11.21 MIO.H �X�^���o�C���A���͂��̂܂ܕ��A
//  v1.07 2001.11.28 MIO.H �����͂���ς��߂�
//  v1.08 2001.11.29 MIO.H �V�X�e�����j���[���C�A�E�g�ύX�A�����ēx����(^^;
//  v1.09 2001.11.30 MIO.H �d�����j�^ON/OFF�̑���ύX
//  v1.12 2001.12.03 MIO.H �d�����j�^ON/OFF�̌��ݒl�擾
//  v1.13 2001.12.13 MIO.H �V�X�e�����j���[�Ƃ��ċN�������ꍇ�� pceFontSetType ����B
//  v1.14 2001.12.21 MIO.H �V�X�e�����j���[�Q�y�[�W���B�T�E���h�ȓd�͐ݒ�ǉ��B
//  v1.19 2003.02.14 N.SAWA go_sandby()�̒���pceUSBReconnect()��pcePowerEnterStandby()�̒��ɋ��ʉ��B
//  v1.27 2005.04.02 Madoka �V�X�e�����j���[�ɃJ�[�l����MMC�������L���ݒ��ǉ�
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <piece.h>
#include <pcekn.h>
#ifdef __PCEKN__
#include <work.h>
#endif

//2005/04/02 Add by Madoka
extern unsigned char g_bMMCInitEnable;		//�J�[�l����MMC�������L���t���O

static unsigned char draw;
static unsigned char cur;
static unsigned char page;
static unsigned char flg;
static unsigned char last_sec;
static unsigned char txcol;
static unsigned char bgcol;

typedef struct tagMENUITEM {
	char *const pname;
	int (*const procUD)( int d );
	int (*const procA)( void );
	void (*const disp)( void );
} MENUITEM;


static const unsigned char colormap[3][2] = {
	{ 2, 0 },	// ��I��
	{ 3, 1 },	// �I��
	{ 0, 3 },	// �^�C�g��
};

void setcol( int n )
{
	pceFontSetTxColor(txcol = colormap[n][0]);
	pceFontSetBkColor(bgcol = colormap[n][1]);
}

void revcol( int f )
{
	pceFontSetTxColor(f?bgcol:txcol);
	pceFontSetBkColor(f?txcol:bgcol);
}


void go_standby( void );


void disp_stat( void )
{
	PCETIME time;

	pceTimeGet( &time );
	if ( last_sec != time.ss ) {
		last_sec = time.ss;
		setcol(2);
		pceFontSetPos( 128-5*20, 88-10 );
		pceFontPrintf( "%04d-%02d-%02d %02d:%02d:%02d",
			time.yy, time.mm, time.dd, time.hh, time.mi, time.ss );
		draw = 1;
	}
}


static int nop( void )
{
	return 0;
}



// ����

const static unsigned char volmap[] = {
	99,			// 0
	127-90,		// 1
	127-97,		// 2
	127-103,	// 3
	127-107,	// 4
	127-111,	// 5
	127-115,	// 6
	127-119,	// 7
	127-123,	// 8
	127-127,	// 9
};


static int getnowvol( void )
{
	int i, x = pceWaveSetMasterAtt(INVALIDVAL);
	for ( i = sizeof(volmap)-1; i; i-- ) {
		if ( x <= volmap[i] ) break;
	}
	return i;
}


static int volud( int d )
{
	int x = getnowvol() + d;
	if ( x < 0 ) x = 0;
	else if ( x > 9 ) x = 9;
	pceWaveSetMasterAtt( volmap[x] );
//	pceWaveSetMasterAtt( pceWaveSetMasterAtt(INVALIDVAL) - d );
	return 1;
}

static void voldisp( void )
{
	pceFontPrintf( "<< %2d >>", getnowvol() );
//	pceFontPrintf( "(%ddB) ", pceWaveSetMasterAtt(INVALIDVAL) );
}



// �R���g���X�g

static int getnowbri( void )
{
	int x = pceLCDSetBright(INVALIDVAL) - 25;
	if ( x < 0 ) x = 0;
	return x;
}

static int conud( int d )
{
	int x = getnowbri() + d;
	if ( x < 0 ) x = 0;
	pceLCDSetBright(25+x);
	return 1;
}

static void condisp( void )
{
	pceFontPrintf( "<< %2d >>", getnowbri() );
//	pceFontPrintf( "(%d) ", pceLCDSetBright(INVALIDVAL) );
}


// �d�����j�^�[

static void box( int x, int y, int c )
{
	unsigned char *vbuff = pceLCDSetBuffer( INVALIDPTR );
	vbuff += x + y * 128;
	for ( x = 0; x < 11; x++ ) {
		memset( vbuff, c, 20 );
		vbuff+=128;
	}
}

static int batud( int d )
{
	flg ^= 1;
	pcePowerSetReport( (flg&1) ? PWR_RPTON : PWR_RPTOFF );
	return 1;
}

static void onoffdisp( int y, int f )
{
	revcol(f);
	box( 65, y-1, f ? txcol : bgcol );
	pceFontSetPos( 71, y );
	pceFontPrintf( "ON" );
	revcol(!f);
	box( 93, y-1, f ? bgcol : txcol );
	pceFontSetPos( 95, y );
	pceFontPrintf( "OFF" );
}

static void batdisp( void )
{
	onoffdisp( 55, (flg&1) );
}



// �d���I�t(�X�^���o�C)
static int standby( void )
{
	go_standby();
	return 0;
}

// �߂�
static int smexit( void )
{
	pceAppReqExit(0);
	return 0;
}


// �T�E���h�ȓd��
static void snddisp( void )
{
	onoffdisp( 22, (flg&2) );
}

static int sndud( int d )
{
	flg ^= 2;
	sndSetPowersave( (flg&2)>>1 );
	return 1;
}

//2005/04/02 Add by Madoka
//�J�[�l����MMC�������L���ݒ�
static void mmcdisp( void )
{
	onoffdisp( 33, (g_bMMCInitEnable & 1) );
}

//2005/04/02 Add by Madoka
static int mmcen( int d )
{
	g_bMMCInitEnable ^= 1;
	
	return 1;
}

#define NOP ((void *)nop)

static const MENUITEM menuitem[2][5] = {
{
	{	"�d���n�e�e"               , NOP,   standby, NOP     },
	{	"����"                     , volud, NOP,     voldisp },
	{	"�R���g���X�g"             , conud, NOP,     condisp },
	{	"�d�r�c�ʕ\��     /"       , batud, NOP,     batdisp },
	{	"�A�v���ɖ߂�     Page1/2" , NOP,   smexit,  NOP     },
},
{
	{	"����ޏȓd��      /"       , sndud, NOP,     snddisp },
	{	"MMC/SD           /"       , mmcen, NOP,     mmcdisp }, //2005/04/02 Add by Madoka
	{	""                         , NOP,   NOP,     NOP     },
	{	""                         , NOP,   NOP,     NOP     },
	{	"�A�v���ɖ߂�     Page2/2" , NOP,   smexit,  NOP     },
},
};



static void disp( int n )
{
	unsigned char *vbuff = pceLCDSetBuffer( INVALIDPTR );
	const MENUITEM *pmi = &menuitem[page][n];
	int y = n*11+22;

	setcol( n == cur );

	memset( vbuff+y*128-128, bgcol, 128*11 );

	pceFontSetPos( 0, y );
	pceFontPrintf( "%s", pmi->pname );
	pceFontSetPos( 70, y );
	pmi->disp();

	draw = 1;
}





void disp_frame( void )
{
	unsigned char *vbuff = pceLCDSetBuffer( INVALIDPTR );

	{
		const SYSTEMINFO *sip = pceSystemGetInfo();
		int i;
		pceFontSetType( 0 );
		pceFontSetPos( 0, 0 );
		setcol(2);
		memset( vbuff, bgcol,  128*10 );
		memset( vbuff+128*78, bgcol,  128*10 );
		pceFontPrintf( "��PIECE System Menu\n"  );
		setcol(0);
		memset( vbuff+128*10, bgcol, 128*68 );
		pceFontPrintf( "BIOS ver%d.%02d ", sip->bios_ver>>8, sip->bios_ver&255 );
		pceFontPrintf( "20%02d.%02d.%02d\n", sip->bios_date>>9, (sip->bios_date>>5)&15, sip->bios_date&31 );
		memset( vbuff+128*19, txcol, 128 );
		for ( i = 0; i < 5; i++ ) disp( i );
		last_sec = 0xff;
	}

	draw = 1;
}




void go_standby( void )
{
	unsigned char *vbuff = pceLCDSetBuffer( INVALIDPTR );

	//pceUSBDisconnect();
	memset( vbuff, 0, 88*128 );
	pceFontSetPos(0,0);
	pceFontPrintf("�X�^���o�C��\n");
	pceFontPrintf("in standby mode\n");
	//pcePowerSetReport(PWR_RPTOFF);
	pceLCDTrans();
	pceLCDDispStop();

	if ( !pcePowerEnterStandby(0) ) {
		pceAppReqExit(0);
	}

	//pceUSBReconnect(); 2003.02.14 N.SAWA pcePowerEnterStandby()�̒��ֈڂ��܂���
	//pcePowerSetReport(PWR_RPTON);

	disp_frame();
	pceLCDDispStart();
}








void biapp_init( void )
{
	cur = flg = 0;
#ifdef __PCEKN__
	if ( powerdisp ) flg |= 1;
	if ( sndSetPowersave( INVALIDVAL ) ) flg |= 2;
#endif

	pceAppSetProcPeriod( 50 );

	disp_frame();

	pceLCDTrans();
	pceLCDDispStart();
}



void pceAppInit( void )
{
#ifdef __PCEKN__
	pceLCDSetBuffer( system_info.sram_end - 128*88 );
#else
	pceLCDSetBuffer( pceSystemGetInfo()->sram_end - 128*88 );
#endif
	pceDebugSetMon(0);
	biapp_init();
}



void pceAppProc( int cnt )
{
	int a = pcePadGet();
	const MENUITEM *pmi = &menuitem[page][cur];
#if 0
	if ( dispstat < 2 ) {
		disp_frame();
		dispstat = 2;
		return;
	}
#endif
	if ( a & TRG_B ) {
		if (a & PAD_SELECT) go_standby();
		else pceAppReqExit(0);
	}
	else if ( a & TRG_A ) {
		if ( pmi->procA() ) disp(cur);
	}

	if ( a & TRG_RI ) {
		if ( pmi->procUD( 1 ) ) disp(cur);
	}
	if ( a & TRG_LF ) {
		if ( pmi->procUD( -1 ) ) disp(cur);
	}

	if ( a & TRG_UP ) {
		if ( cur ) {
			cur--;
			disp(cur+1);
			disp(cur);
		}
		else if ( page ) {
			page = 0;
			cur = 4;
			disp_frame();
		}
	}
	if ( a & TRG_DN ) {
		if ( cur < 4 ) {
			cur++;
			disp(cur-1);
			disp(cur);
		}
		else if ( !page ) {
			page = 1;
			cur = 0;
			disp_frame();
		}
	}

	disp_stat();

	if ( draw ) {
		pceLCDTrans();
		draw = 0;
	}
}


void pceAppExit( void )
{
}

int pceAppNotify( int type, int param )
{
	return APPNR_IGNORE;
}



