

#include <stdio.h>
#include <stdlib.h>

unsigned char fontbuff[256*1024];

unsigned char font[84*94*18];
unsigned char han[256*12];

struct {
	unsigned short ofs;
	unsigned char s;
	unsigned char e;
} idx[84];

int fs_dt;	// �P�t�H���g�̃h�b�g�T�C�Y		10/12
int fs_hb;	// (���p)�P�t�H���g�̃o�C�g��	10/12
int fs_zb;	// (�S�p)�P�t�H���g�̃o�C�g��	15/18


void loadsub( unsigned char h, unsigned char l, unsigned char *ip )
{
	unsigned char *np;
	int y;

	// �V�t�gJIS�R�[�h(h,l)�����_�R�[�h(0,0�`)�ɕϊ�
	if ( h >= 0xe0 ) h -= 0x40;
	h -= 0x81;
	h *= 2;
	if ( l >= 0x80 ) l--;
	l-= 0x40;
	if ( l >= 94 ) { l-=94; h++; }

	np = &font[(h*94+l)*fs_zb];

	for ( y = 0; y < fs_dt; y+=2 ) {
		np[0] = ip[0];
		np[1] = ip[1] + (ip[2]>>4);
		np[2] = (ip[2]<<4) + (ip[3]>>4);
		np+=3;
		ip+=4;
	}
}


void load( char *name )
{
	FILE *fp = fopen( name, "rb" );

	if ( !fp ) return;

	fread( fontbuff, 1, sizeof(fontbuff), fp );
	fclose( fp );

	printf( "ok\n" );

	{
		int c = fontbuff[17];
		unsigned char *cp = fontbuff+18;
		unsigned char *ip = fontbuff+18+c*4;

		do {
			unsigned char n;
			for ( n = cp[0]; n <= cp[2]; n++ ) {
				loadsub( cp[1], n, ip );
				ip += (fs_dt*2);
			}
			cp+=4;
		} while ( --c );
	}
}



void search( void )
{
	int k, s, e;
	static unsigned char z[18];
	int n = 0;

	font[0] ^= 1;

	for ( k = 0; k < 84; k++ ) {
		for ( s = 0; s < 94; s++ ) {
			if ( memcmp( &font[(k*94+s)*fs_zb], z, fs_zb ) ) break;
		}
		for ( e = 93; e >= s; e-- ) {
			if ( memcmp( &font[(k*94+e)*fs_zb], z, fs_zb ) ) break;
		}
		if ( s < e ) {
			//printf( "%d %d-%d\n", k+1, s+1, e+1 );
			idx[k].ofs = n;
			idx[k].s = s;
			idx[k].e = e;
			n += (e-s+1);
		}
	}

	font[0] ^= 1;
	printf( "n=%d (%dbytes)\n", n, n*fs_zb );
}



void load_han( char *name )
{
	FILE *fp = fopen( name, "rb" );
	if ( fp ) {
		fseek(fp,17,SEEK_SET);
		fread(han,fs_hb,256,fp);
		fclose( fp );
		printf( "ok\n" );
	}
}



void save( char *name )
{
	FILE *fp = fopen( name, "wb" );
	if ( fp ) {
		int i;
		fwrite(&han[0x20*fs_hb],fs_hb,0x60,fp);
		fwrite(&han[0xa0*fs_hb],fs_hb,0x40,fp);
		fwrite( idx, 1, sizeof(idx), fp );
		for ( i = 0; i < 84; i++ ) {
			int s = idx[i].s;
			int e = idx[i].e;
			if ( s < e ) {
				fwrite( &font[(i*94+s)*fs_zb], fs_zb, e-s+1, fp );
			}
		}
		fclose( fp );
	}
}

#if 0
void cutfile( char *name )
{
	FILE *fp = fopen( name, "rb" );
	if ( fp ) {
		int i;
		for ( i = 0; i < 100; i++ ) {
			FILE *wfp;
			char name2[32];
			int n = fread( fontbuff, 1, 0x8000, fp );
			if ( !n ) break;
			sprintf( name2, "zf%d.bin", i );
			wfp = fopen( name2, "wb" );
			if ( wfp ) {
				fwrite( fontbuff, 1, n, wfp );
				fclose( wfp );
			}
		}
		fclose( fp );
	}
}
#endif


void setup( int n )
{
	fs_dt = n;
	fs_hb = n;
	fs_zb = n+n/2;
	memset( font, 0, sizeof(font) );
	memset( idx, 0, sizeof(idx) );
}

int inrange( int x, int y )
{
	x -= 3;
	y -= 5;
	if ( x < 0 || y < 0 ) return 0;
	if ( x >= 9*16 ) return 0;
	x %= 9;
	y %= 20;
	if ( x >= 8 || y >= 16 ) return 0;
	return 1;
}

// ���p(�傫���t�H���g 8x16)�̐���

void load_han2( char *fname )
{
	FILE *fp = fopen( fname, "rb" );
	if ( fp ) {
		fread( fontbuff, 1, sizeof(fontbuff), fp );
		fclose( fp );
		fontbuff[54+4*2+1] = 0xe0;
		fontbuff[54+4*2+2] = 0xe0;
	}
}



void write1font( FILE *fp, unsigned char *p )
{
	int x, y;
	for ( y = 0; y < 16; y++ ) {
		unsigned char a = 0;
		for ( x = 0; x < 8; x++ ) {
			a <<= 1;
			if ( !p[x] ) a |= 1; else p[x] = 2;
		}
		fputc( a, fp );
		p -= 128;
	}
}




void save_han2( char *fname )
{
	FILE *fp = fopen( fname, "wb" );
	if ( fp ) {
		unsigned char *p;
		int x, y;
		for ( y = 0; y < 6; y++ ) {
			for ( x = 0; x < 16; x++ ) {
				p = fontbuff + 54 + 1024 + (95-(y*16))*128 + x*8;
				write1font( fp, p );
			}
		}
		fclose( fp );
		// �؂�o���m�F�p bmp �t�@�C��
		fp = fopen( "tmp.bmp", "wb" );
		if ( fp ) {
			fwrite( fontbuff, 1, 19926, fp );
			fclose( fp );
		}
	}
}



// ���p(�ɏ��t�H���g 5x6)�̐���

void load_han3( char *fname )
{
	FILE *fp = fopen( fname, "rb" );
	if ( fp ) {
		fread( fontbuff, 1, sizeof(fontbuff), fp );
		fclose( fp );
		fontbuff[54+4*2+1] = 0xe0;
		fontbuff[54+4*2+2] = 0xe0;
	}
}



void write1font3( FILE *fp, unsigned char *p )
{
	int x, y;
	for ( y = 0; y < 6; y++ ) {
		unsigned char a = 0;
		for ( x = 0; x < 5; x++ ) {
			a <<= 1;
			if ( !p[x] ) a |= 1; else p[x] = 2;
		}
		fputc( a, fp );
		p -= 80;
	}
}




void save_han3( char *fname )
{
	FILE *fp = fopen( fname, "wb" );
	if ( fp ) {
		unsigned char *p;
		int x, y;
		for ( y = 0; y < 2; y++ ) {
			for ( x = 0; x < 16; x++ ) {
				p = fontbuff + 54 + 1024 + (15-(y*8))*80 + x*5;
				write1font3( fp, p );
			}
		}
		fclose( fp );
		// �m�F�p bmp �t�@�C��
		fp = fopen( "tmp3.bmp", "wb" );
		if ( fp ) {
			fwrite( fontbuff, 1, 2358, fp );
			fclose( fp );
		}
	}
}




// ���p(�ɏ��t�H���g 5x6)�̐���

void load_han4( char *fname )
{
	FILE *fp = fopen( fname, "rb" );
	if ( fp ) {
		fread( fontbuff, 1, sizeof(fontbuff), fp );
		fclose( fp );
		fontbuff[54+4*2+1] = 0xe0;
		fontbuff[54+4*2+2] = 0xe0;
	}
}



void write1font4( FILE *fp, unsigned char *p )
{
	int x, y;
	for ( y = 0; y < 6; y++ ) {
		unsigned char a = 0;
		for ( x = 0; x < 4; x++ ) {
			a <<= 1;
			if ( p[x] ) a |= 1; else p[x] = 2;
		}
		a <<= 4;
		fputc( a, fp );
		p -= 64;
	}
}



void save_han4( char *fname )
{
	FILE *fp = fopen( fname, "wb" );
	if ( fp ) {
		unsigned char *p;
		int x, y;
		for ( y = 0; y < 6; y++ ) {
			for ( x = 0; x < 16; x++ ) {
				p = fontbuff + 54 + 1024 + (35-(y*6))*64 + x*4;
				write1font4( fp, p );
			}
		}
		fclose( fp );
		// �m�F�p bmp �t�@�C��
		fp = fopen( "tmp4.bmp", "wb" );
		if ( fp ) {
			fwrite( fontbuff, 1, 54 + 1024 + 64*36, fp );
			fclose( fp );
		}
	}
}




void main( void )
{
#if 0	// 12�h�b�g�t�H���g�̐���
	setup( 12 );
	load_han( "KNMHN12X.MNF" );
	load( "KNMZN12X.MNF" );
	load( "MLT12X12.NA" );
	memset(&font[(12-1)*94*fs_zb],0,fs_zb*94);	// �P�Q�������
	search();
	save( "zfont12.bin" );
#endif
		// 10�h�b�g�t�H���g�̐���
	setup( 10 );
	load_han( "5x10rk.fnt" );
	//load( "maru10.fnt" );
	load( "knj10.fnt" );
	memset(&font[(12-1)*94*fs_zb],0,fs_zb*94);	// �P�Q�������
	search();
	save( "zfont10.bin" );

	// 16�h�b�g�t�H���g�̐����i���p�p�����̂݁j
	load_han2( "lfont16.bmp" );
	save_han2( "lfont16.bin" );

	// 5x6�h�b�g�t�H���g�̐����i32�������̂݁j
	load_han3( "sfont6.bmp" );
	save_han3( "sfont6.bin" );

	// 4x6�h�b�g�t�H���g�̐����i���p�p�����̂݁j
	load_han4( "ascii4x6.bmp" );
	save_han4( "ascii4x6.bin" );
}



