make pex
run mmc_menu
