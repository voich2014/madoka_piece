make pex
run maze
