make pex
run ltbbs
