make pex
run ositest
