make pex
run adtest
