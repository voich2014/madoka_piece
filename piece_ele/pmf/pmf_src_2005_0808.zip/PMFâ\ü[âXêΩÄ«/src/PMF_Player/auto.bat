make pex
run pmf_play
