//------------------------------------------------------------------------------
// File: PieceMovieFileMux.h
//
// BaseClasses��Transform.h����������PieceMovieFile�p��MUX�t�B���^���쐬
//
// Copyright (c)2005 �܂ǂ�@CircleSoft  All rights reserved.
//------------------------------------------------------------------------------

#ifndef __PMF_MUX__
#define __PMF_MUX__

#include "IPieceMovieFileMux.h"

//---------------------------------------------------------------------------
//���� CLSID��` ������������������������������������������������������������
//---------------------------------------------------------------------------

// {F9278E33-B8D1-4fb2-8CFC-C9615F52CB8C}
DEFINE_GUID(CLSID_PieceMovieFileMux, 
0xf9278e33, 0xb8d1, 0x4fb2, 0x8c, 0xfc, 0xc9, 0x61, 0x5f, 0x52, 0xcb, 0x8c);

//---------------------------------------------------------------------------

//���̃t�B���^�̃v���W�F�N�g�ł́A���ׂĂ̊���̃��C�u����
//�𖳎�����w��ɂȂ��Ă���̂ŁASTL���g���ꍇ�́Alibcpmt.lib
//�������N����K�v������܂��B
//�v���W�F�N�g�̃v���p�e�B�́u�����J�v�́u���́v�́u�ǉ��̈ˑ�
//�t�@�C���v��libcpmt.lib��ǉ����ĉ������B(Debug/Release�Ƃ�)
//
//libcpmt.lib�͕W��C++���C�u�����̃}���`�X���b�h�łł��B
//STL�͂��̃��C�u�����Ɋ܂܂�Ă���A���̃��C�u�����������N����
//�����Ȃ��ƃ����N�G���[�ɂȂ�܂��B

#include <map>
#include <deque>
#include <vector>	//2005/06/05 Added by Madoka

class CPieceMovieFileMuxFilter;

// ==================================================
// Implements the input pin
// ==================================================

class CMuxFilterInputPin : public CBaseInputPin
{
    friend class CPieceMovieFileMuxFilter;

protected:
    CPieceMovieFileMuxFilter *m_pMuxFilter;

public:

    CMuxFilterInputPin(
        TCHAR *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#ifdef UNICODE
    CMuxFilterInputPin(
        char *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#endif

    STDMETHODIMP QueryId(LPWSTR * Id)
    {
        return AMGetWideString(L"In", Id);
    }

    // Grab and release extra interfaces if required

    HRESULT CheckConnect(IPin *pPin);
    HRESULT BreakConnect();
    HRESULT CompleteConnect(IPin *pReceivePin);

    // check that we can support this output type
    virtual HRESULT CheckMediaType(const CMediaType* mtIn) PURE;

    // set the connection media type
    virtual HRESULT SetMediaType(const CMediaType* mt) PURE;

    // --- IMemInputPin -----

    // here's the next block of data from the stream.
    // AddRef it yourself if you need to hold it beyond the end
    // of this call.
    virtual STDMETHODIMP Receive(IMediaSample * pSample) PURE;

    // provide EndOfStream that passes straight downstream
    // (there is no queued data)
    STDMETHODIMP EndOfStream(void);

    // passes it to CTransformFilter::BeginFlush
    STDMETHODIMP BeginFlush(void);

    // passes it to CTransformFilter::EndFlush
    STDMETHODIMP EndFlush(void);

    STDMETHODIMP NewSegment(
                        REFERENCE_TIME tStart,
                        REFERENCE_TIME tStop,
                        double dRate);

    // Check if it's OK to process samples
    virtual HRESULT CheckStreaming();

    // Media type
public:
    CMediaType& CurrentMediaType() { return m_mt; };

};

//Video�p���̓s���N���X
class CMuxFilterVideoInputPin : public CMuxFilterInputPin
{

	 friend class CPieceMovieFileMuxFilter;

public:

    CMuxFilterVideoInputPin(
        TCHAR *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#ifdef UNICODE
    CMuxFilterVideoInputPin(
        char *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#endif

	// check that we can support this output type
    virtual HRESULT CheckMediaType(const CMediaType* mtIn);

    // set the connection media type
    virtual HRESULT SetMediaType(const CMediaType* mt);

	// --- IMemInputPin -----

    // here's the next block of data from the stream.
    // AddRef it yourself if you need to hold it beyond the end
    // of this call.
    virtual STDMETHODIMP Receive(IMediaSample * pSample);
	
};

//Audio�p���̓s���N���X
class CMuxFilterAudioInputPin : public CMuxFilterInputPin
{

	 friend class CPieceMovieFileMuxFilter;

public:

    CMuxFilterAudioInputPin(
        TCHAR *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#ifdef UNICODE
    CMuxFilterAudioInputPin(
        char *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#endif

	// check that we can support this output type
    virtual HRESULT CheckMediaType(const CMediaType* mtIn);

    // set the connection media type
    virtual HRESULT SetMediaType(const CMediaType* mt);

	// --- IMemInputPin -----

    // here's the next block of data from the stream.
    // AddRef it yourself if you need to hold it beyond the end
    // of this call.
    virtual STDMETHODIMP Receive(IMediaSample * pSample);
	
};

// ==================================================
// Implements the output pin
// ==================================================

class CMuxFilterOutputPin : public CBaseOutputPin
{
    friend class CPieceMovieFileMuxFilter;

protected:
    CPieceMovieFileMuxFilter *m_pMuxFilter;

public:

    // implement IMediaPosition by passing upstream
    IUnknown * m_pPosition;

    CMuxFilterOutputPin(
        TCHAR *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#ifdef UNICODE
    CMuxFilterOutputPin(
        CHAR *pObjectName,
        CPieceMovieFileMuxFilter *pMuxFilter,
        HRESULT * phr,
        LPCWSTR pName);
#endif
    ~CMuxFilterOutputPin();

    // override to expose IMediaPosition
    STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void **ppv);

    // --- CBaseOutputPin ------------

    STDMETHODIMP QueryId(LPWSTR * Id)
    {
        return AMGetWideString(L"Out", Id);
    }

    // Grab and release extra interfaces if required

    HRESULT CheckConnect(IPin *pPin);
    HRESULT BreakConnect();
    HRESULT CompleteConnect(IPin *pReceivePin);

    // check that we can support this output type
    HRESULT CheckMediaType(const CMediaType* mtOut);

    // set the connection media type
    HRESULT SetMediaType(const CMediaType *pmt);

    // called from CBaseOutputPin during connection to ask for
    // the count and size of buffers we need.
    HRESULT DecideBufferSize(
                IMemAllocator * pAlloc,
                ALLOCATOR_PROPERTIES *pProp);

    // returns the preferred formats for a pin
    HRESULT GetMediaType(int iPosition,CMediaType *pMediaType);

    // inherited from IQualityControl via CBasePin
    STDMETHODIMP Notify(IBaseFilter * pSender, Quality q);

    // Media type
public:
    CMediaType& CurrentMediaType() { return m_mt; };
};

typedef struct tag_PMF_VideoData
{
	BYTE			m_abyVideo[PIECE_MOVIE_VIDEO_DATA_MAXSIZE];	//�������ݗpVideo�t���[���f�[�^	
} PMF_VIDEO_DATA;

typedef struct tag_PMF_AudioData
{
	BYTE			m_abyAudio[PIECE_MOVIE_AUDIO_DATA_SIZE];	//�������ݗpAudio�t���[���f�[�^
} PMF_AUDIO_DATA;

typedef struct tag_TransformIndoType
{
	DWORD			m_dwVideoFrame;			//Video�f�[�^�̏����σt���[���C���f�b�N�X
	DWORD			m_dwAudioFrame;			//Audio�f�[�^�̏����σt���[���C���f�b�N�X
	DWORD			m_dwMuxFrame;			//Mux�����ς݃t���[����

	DWORD			m_dwPMFDataSize;		//�������ݍς݃f�[�^�T�C�Y
	
    BYTE			m_abyOldFrame[PIECE_SCREEN_WIDTH * PIECE_SCREEN_HEIGHT];	//�O���Video�t���[���f�[�^
	BYTE			m_abyFrame[PIECE_SCREEN_WIDTH * PIECE_SCREEN_HEIGHT];		//�����Video�t���[���f�[�^
	PMF_VIDEO_DATA  m_tVideo;				//�ϊ���Video�f�[�^

	PMF_AUDIO_DATA	m_tWorkAudio;			//Audio�f�[�^�������̗]��
	int				m_nWorkAudioSize;		//Audio�f�[�^�������̗]��T�C�Y

	std::deque<PMF_VIDEO_DATA> m_queVideo;	//Video�f�[�^�L���[
	std::deque<PMF_AUDIO_DATA> m_queAudio;	//Audio�f�[�^�L���[
	std::map<DWORD,WORD> m_mapFrameHeader;	//�t���[���w�b�_�}�b�v

	std::vector<PMF_KEY_FRAME_OFFSET_INFO_TYPE>
		m_vecKeyFrameOffset;				//�L�[�t���[���I�t�Z�b�g�z�� 2005/06/05 Added by Madoka

	int				m_nUseStream;			//���p�X�g���[����

	//�R���X�g���N�^
	tag_TransformIndoType()
	{
		//�����o�̏�����
		Init();
	}
	
	//������
	void Init(void)
	{
		m_dwVideoFrame   = 0xFFFFFFFF;
		m_dwAudioFrame   = 0xFFFFFFFF;
		m_dwMuxFrame     = 0xFFFFFFFF;
		m_nWorkAudioSize = 0;
		m_dwPMFDataSize  = 0;
		m_nUseStream     = 0;

		memset(m_abyOldFrame,0,sizeof(m_abyOldFrame));

		m_queVideo.clear();
		m_queAudio.clear();
		m_mapFrameHeader.clear();
		m_vecKeyFrameOffset.clear();	//2005/06/05 Added by Madoka
	}

	//�����ς݃`�F�b�N
	BOOL IsVideoTramsformComplete(void)
	{
		return (m_queVideo.size() > 0); 
	}
	BOOL IsAudioTransformComplete(void)
	{
		return (m_queAudio.size() > 0);
	}
	
	//�t���[���w�b�_�̎擾
	WORD& GetFrameHeaderForVideo(void)
	{
		return m_mapFrameHeader[m_dwVideoFrame];
	}
	WORD& GetFrameHeaderForAudio(void)
	{
		return m_mapFrameHeader[m_dwAudioFrame];
	}

	//�X�g���[���I���`�F�b�N
	//�S�ẴX�g���[�����I��������TRUE��Ԃ�
	BOOL StreamEnd(void)
	{
		m_nUseStream--;
		return (m_nUseStream == 0);
	}

} TRANSFORM_INFO_TYPE;

class /*AM_NOVTABLE*/ CPieceMovieFileMuxFilter : public CBaseFilter,public IPieceMovieFileMux
{

public:

    // map getpin/getpincount for base enum of pins to owner
    // override this to return more specialised pin objects

    virtual int GetPinCount();
    virtual CBasePin * GetPin(int n);
    STDMETHODIMP FindPin(LPCWSTR Id, IPin **ppPin);

    // override state changes to allow derived transform filter
    // to control streaming start/stop
    STDMETHODIMP Stop();
    STDMETHODIMP Pause();

public:

    CPieceMovieFileMuxFilter(TCHAR *, LPUNKNOWN, REFCLSID clsid);
#ifdef UNICODE
    CPieceMovieFileMuxFilter(CHAR *, LPUNKNOWN, REFCLSID clsid);
#endif
    ~CPieceMovieFileMuxFilter();

	DECLARE_IUNKNOWN;
	static CUnknown * WINAPI CreateInstance(LPUNKNOWN punk, HRESULT *phr);

    // =================================================================
    // ----- override these bits ---------------------------------------
    // =================================================================

    // These must be supplied in a derived class

    // check if you can support mtIn
    virtual HRESULT CheckVideoInputType(const CMediaType* mtIn);/* PURE;*/
	virtual HRESULT CheckAudioInputType(const CMediaType* mtIn);/* PURE;*/

    // check if you can support the transform from this input to this output
    virtual HRESULT CheckVideoTransform(const CMediaType* mtIn, const CMediaType* mtOut);/* PURE;*/
	virtual HRESULT CheckAudioTransform(const CMediaType* mtIn, const CMediaType* mtOut);/* PURE;*/

    // this goes in the factory template table to create new instances
    // static CCOMObject * CreateInstance(LPUNKNOWN, HRESULT *);

    // call the SetProperties function with appropriate arguments
    virtual HRESULT DecideBufferSize(
                        IMemAllocator * pAllocator,
                        ALLOCATOR_PROPERTIES *pprop);/* PURE;*/

    // override to suggest OUTPUT pin media types
    virtual HRESULT GetMediaType(int iPosition, CMediaType *pMediaType);/* PURE;*/



    // =================================================================
    // ----- Optional Override Methods           -----------------------
    // =================================================================

    // you can also override these if you want to know about streaming
    virtual HRESULT StartStreaming();
    virtual HRESULT StopStreaming();

    // override if you can do anything constructive with quality notifications
    virtual HRESULT AlterQuality(Quality q);

    // override this to know when the media type is actually set
    virtual HRESULT SetMediaType(PIN_DIRECTION direction,const CMediaType *pmt);

    // chance to grab extra interfaces on connection
    virtual HRESULT CheckConnect(PIN_DIRECTION dir,IPin *pPin);
    virtual HRESULT BreakConnect(PIN_DIRECTION dir);
    virtual HRESULT CompleteConnect(PIN_DIRECTION direction,IPin *pReceivePin);

    // chance to customize the transform process
    HRESULT VideoReceive(IMediaSample *pSample);
	HRESULT VideoTransform(IMediaSample *pIn);
	HRESULT GetFrameData(IMediaSample *pIn);
	HRESULT VideoKeyFrameTransform(void);
	HRESULT AudioReceive(IMediaSample *pSample);
	HRESULT AudioTransform(IMediaSample *pIn);
	HRESULT PieceMovieMux(IMediaSample *pOutSample);
	HRESULT LastTransform(void);
	
    // Standard setup for output sample
    HRESULT InitializeOutputSample(IMediaSample *pSample, IMediaSample **ppOutSample);

    // if you override Receive, you may need to override these three too
    virtual HRESULT EndOfStream(void);
    virtual HRESULT BeginFlush(void);
    virtual HRESULT EndFlush(void);
    virtual HRESULT NewSegment(
                        REFERENCE_TIME tStart,
                        REFERENCE_TIME tStop,
                        double dRate);

	//2005/07/31 Added by Madoka
	//�A�v���P�[�V���������QueryInterface�ɉ�����ׂ̃I�[�o�[���C�h
	STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void ** ppv);

	//2005/07/31 Added by Madoka
	//PieceMovieFileMux�p�̃C���^�[�t�F�[�X
	STDMETHODIMP get_ConvertedFrameCount(DWORD *pdwFrameCount);	//�ϊ��ς݂̃t���[�����擾
    
#ifdef PERF
    // Override to register performance measurement with a less generic string
    // You should do this to avoid confusion with other filters
    virtual void RegisterPerfId()
         {m_idTransform = MSR_REGISTER(TEXT("Transform"));}
#endif // PERF


// implementation details

protected:

#ifdef PERF
    int m_idTransform;                 // performance measuring id
#endif
    BOOL m_bEOSDelivered;              // have we sent EndOfStream
    BOOL m_bSampleSkipped;             // Did we just skip a frame
    BOOL m_bQualityChanged;            // Have we degraded?

	TRANSFORM_INFO_TYPE m_tTransformInfo;	//�ϊ����

    // critical section protecting filter state.

    CCritSec m_csFilter;
	
    // critical section stopping state changes (ie Stop) while we're
    // processing a sample.
    //
    // This critical section is held when processing
    // events that occur on the receive thread - Receive() and EndOfStream().
    //
    // If you want to hold both m_csReceive and m_csFilter then grab
    // m_csFilter FIRST - like CTransformFilter::Stop() does.

    CCritSec m_csReceive;

	CCritSec m_FrameCountLock;			//�ϊ��ς݃t���[�����擾�r������p�N���e�B�J���Z�N�V�����I�u�W�F�N�g		//2005/07/31 Added by Madoka
	
    // these hold our input and output pins

	friend class CMuxFilterInputPin;
    friend class CMuxFilterVideoInputPin;
    friend class CMuxFilterAudioInputPin;
    friend class CMuxFilterOutputPin;
    CMuxFilterVideoInputPin  *m_pVideoInput;
	CMuxFilterAudioInputPin  *m_pAudioInput;
    CMuxFilterOutputPin *m_pOutput;
};

#endif /* __PMF_MUX__ */


