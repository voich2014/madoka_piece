//------------------------------------------------------------------------------
// File: PieceMovieFileMux.cpp
//
// BaseClasses��Transform.cpp����������PieceMovieFile�p��MUX�t�B���^���쐬
//
// Copyright (c)2005 �܂ǂ�@CircleSoft  All rights reserved.
//------------------------------------------------------------------------------


#include <streams.h>
#include <measure.h>
#include <aviriff.h>
#include <malloc.h>
#include <mmreg.h>
#include "..\\lib\\PMF_Header.h"
#include "PieceMovieFileMux.h"
#include "DllMain.h"

//�t�B���^��
static TCHAR *g_szFilterName = "Piece Movie File Mux";

#define TRACE_LEVEL	(2)	//0���ƃg���[�XON 2���ƃg���[�XOFF
//---------------------------------------------------------------------------
//���� P/ECE�̃X�N���[���萔 ������������������������������������������������������
//---------------------------------------------------------------------------
#define PCE_CC_VIDEO		'PCEG'	//PieceGray�t�H�[�}�b�g��FOURCC
#define PCE_CC_AUDIO		'PCEA'	//PieceADPCM�t�H�[�}�b�g��FOURCC

#define PCE_GRAYSCALE_DEPTH	(13)	//P/ECE�̑��K���\���̐[�x(������K����)

//���K���p���b�g
RGBQUAD g_atPalette[PCE_GRAYSCALE_DEPTH] = 
{
	{ 255,255,255,0 },	//��
	{ 234,234,234,0 },
	{ 213,213,213,0 },
	{ 191,191,191,0 },
	{ 170,170,170,0 },	//�����D�F
	{ 149,149,149,0 },
	{ 128,128,128,0 },
	{ 106,106,106,0 },
	{  85, 85, 85,0 },	//�Z���D�F
	{  64, 64, 64,0 },
	{  43, 43, 43,0 },
	{  21, 21, 21,0 },
	{   0,  0,  0,0 },	//��
};

//AV�����̃^�C���A�E�g����
#define AVSYNC_TIMEOUT	(1000 * 30)


// =================================================================
// Implements the CPieceMovieFileMuxFilter class
// =================================================================

CPieceMovieFileMuxFilter::CPieceMovieFileMuxFilter(TCHAR     *pName,
												   LPUNKNOWN pUnk,
												   REFCLSID  clsid) :
    CBaseFilter(pName,pUnk,&m_csFilter, clsid),
    m_pVideoInput(NULL),
    m_pAudioInput(NULL),
    m_pOutput(NULL),
    m_bEOSDelivered(FALSE),
    m_bQualityChanged(FALSE),
    m_bSampleSkipped(FALSE)
{
#ifdef PERF
    RegisterPerfId();
#endif //  PERF
}

#ifdef UNICODE
CPieceMovieFileMuxFilter::CPieceMovieFileMuxFilter(char     *pName,
												   LPUNKNOWN pUnk,
												   REFCLSID  clsid) :
    CBaseFilter(pName,pUnk,&m_csFilter, clsid),
    m_pVideoInput(NULL),
    m_pAudioInput(NULL),
    m_pOutput(NULL),
    m_bEOSDelivered(FALSE),
    m_bQualityChanged(FALSE),
    m_bSampleSkipped(FALSE)
{
#ifdef PERF
    RegisterPerfId();
#endif //  PERF
}
#endif

// destructor

CPieceMovieFileMuxFilter::~CPieceMovieFileMuxFilter()
{
    // Delete the pins

    delete m_pVideoInput;
    delete m_pAudioInput;
    delete m_pOutput;
}

CUnknown * WINAPI CPieceMovieFileMuxFilter::CreateInstance(LPUNKNOWN pUnk, HRESULT *pHr)
{
	//�C���X�^���X�̍쐬

    CPieceMovieFileMuxFilter *pFilter
	 = new CPieceMovieFileMuxFilter(g_szFilterName,
									pUnk,CLSID_PieceMovieFileMux);
    if (pFilter== NULL) 
    {
        *pHr = E_OUTOFMEMORY;
    }
    return pFilter;
}

//2005/07/27 Added by Madoka
STDMETHODIMP CPieceMovieFileMuxFilter::NonDelegatingQueryInterface(REFIID riid, void **ppv)
{
	//�A�v���P�[�V���������QueryInterface�ɉ�����

    CheckPointer(ppv,E_POINTER);

	//PieceMovieFileMux�̃C���^�[�t�F�[�X�v�����H
    if (riid == IID_IPieceMovieFileMux) {
        return GetInterface((IPieceMovieFileMux *) this, ppv);				//�ԓ�
    } else {
        return CBaseFilter::NonDelegatingQueryInterface(riid, ppv);	//�f�t�H���g����
    }
}

//2005/07/27 Added by Madoka
STDMETHODIMP CPieceMovieFileMuxFilter::get_ConvertedFrameCount(DWORD *pdwFrameCount)
{
	//�����R���g���X�g�����t���O�̎擾
    CheckPointer(pdwFrameCount,E_POINTER);
    CAutoLock cAutoLock(&m_FrameCountLock);

    *pdwFrameCount = m_tTransformInfo.m_dwMuxFrame;

    return NOERROR;
}

// check if you can support mtIn
HRESULT CPieceMovieFileMuxFilter::CheckVideoInputType(const CMediaType* mtIn)
{
	
	//�`�����̃`�F�b�N
	FOURCCMap fccMap = FOURCCMap(PCE_CC_VIDEO); 
        
	if ((mtIn->majortype  != MEDIATYPE_Video)           ||
        (mtIn->subtype    != static_cast<GUID>(fccMap)) ||
        (mtIn->formattype != FORMAT_VideoInfo)          ||  
        (mtIn->cbFormat   != (sizeof(VIDEOINFOHEADER) +
						      sizeof(RGBQUAD) * PCE_GRAYSCALE_DEPTH)))
    {
		//���̌`���̓T�|�[�g���Ă��܂���
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

	//Video�^�C�v�̃`�F�b�N

	//DIB���̃`�F�b�N
	//8bit�̖����kDIB��128*88�̃T�C�Y���H
	VIDEOINFOHEADER *pVih = 
		reinterpret_cast<VIDEOINFOHEADER*>(mtIn->pbFormat);
	if ((pVih->bmiHeader.biBitCount    != 8)                  ||
		(pVih->bmiHeader.biCompression != BI_RGB)             ||
		(pVih->bmiHeader.biWidth       != PIECE_SCREEN_WIDTH) ||
		(pVih->bmiHeader.biHeight      != PIECE_SCREEN_HEIGHT))
	{
		//���̌`���̓T�|�[�g���Ă��܂���
		return VFW_E_TYPE_NOT_ACCEPTED;
	}
	
	//�S�Ė��Ȃ�
	return S_OK;
}

HRESULT CPieceMovieFileMuxFilter::CheckAudioInputType(const CMediaType* mtIn)
{
	
	//�`�����̃`�F�b�N
	FOURCCMap fccMap = FOURCCMap(PCE_CC_AUDIO); 
       
	if ((mtIn->majortype  != MEDIATYPE_Audio)           ||
        (mtIn->subtype    != static_cast<GUID>(fccMap)) ||
		(mtIn->formattype != FORMAT_WaveFormatEx)       ||  
        (mtIn->cbFormat   != sizeof(WAVEFORMATEX)))
    {
		//���̌`���̓T�|�[�g���Ă��܂���
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

	//Audio�^�C�v�̃`�F�b�N
	//WAVE���̃`�F�b�N
	//16kHz4bit���m������ADPCM���H
	WAVEFORMATEX *pAih = 
		reinterpret_cast<WAVEFORMATEX*>(mtIn->pbFormat);
	if((pAih->wFormatTag      != WAVE_FORMAT_ADPCM) ||	//ADPCM
		(pAih->nSamplesPerSec != 16000)			    ||	//16kHz
		(pAih->wBitsPerSample != 4)                 ||	//4bit
		(pAih->nBlockAlign    != 1)                 ||	//�ق�Ƃ�0.5������
		(pAih->nChannels      != 1))					//���m����
	{
		//���̌`���̓T�|�[�g���Ă��܂���
		return VFW_E_TYPE_NOT_ACCEPTED;
	}

	//�S�Ė��Ȃ�
	return S_OK;
}

// check if you can support the transform from this input to this output
HRESULT CPieceMovieFileMuxFilter::CheckVideoTransform(const CMediaType* mtIn, const CMediaType* mtOut)
{

	//�񎦂��ꂽ�o�̓^�C�v�����݂̓��̓^�C�v��
	//�݊��������邩�ǂ����𒲂ׂ�

	//�Ƃ肠�������̓^�C�v��OK�Ȃ���Ȃ�
	HRESULT hr;

    if(FAILED(hr = CheckVideoInputType(mtIn)))
    {
        return hr;
    }

	// ���ׂĖ��Ȃ�
    return S_OK;
}

HRESULT CPieceMovieFileMuxFilter::CheckAudioTransform(const CMediaType* mtIn, const CMediaType* mtOut)
{

	//�񎦂��ꂽ�o�̓^�C�v�����݂̓��̓^�C�v��
	//�݊��������邩�ǂ����𒲂ׂ�

	//�Ƃ肠�������̓^�C�v��OK�Ȃ���Ȃ�
	HRESULT hr;

    if(FAILED(hr = CheckAudioInputType(mtIn)))
    {
        return hr;
    }

	// ���ׂĖ��Ȃ�
    return S_OK;
}

// call the SetProperties function with appropriate arguments
HRESULT CPieceMovieFileMuxFilter::DecideBufferSize(IMemAllocator * pAllocator,
											 	   ALLOCATOR_PROPERTIES *pprop)
{

	//�A���P�[�^����ݒ�

	//�ڑ��ς݂��H
	if((m_pVideoInput->IsConnected() == FALSE) &&
	   (m_pAudioInput->IsConnected() == FALSE))
    {
        return E_UNEXPECTED;
    }

	//�A���P�[�^�v���p�e�B�ɒl���Z�b�g
    CheckPointer(pAllocator,E_POINTER);
    CheckPointer(pprop,E_POINTER);

    pprop->cBuffers = 1;
    pprop->cbAlign  = 1;
	
	pprop->cbBuffer = PIECE_MOVIE_FRAME_HEADER_SIZE +
					  ((m_pVideoInput->IsConnected() == TRUE) ? PIECE_MOVIE_VIDEO_DATA_MAXSIZE : 0) +
					  ((m_pAudioInput->IsConnected() == TRUE) ? PIECE_MOVIE_AUDIO_DATA_SIZE : 0);

    // �A���P�[�^ �v���p�e�B��ݒ肷��
    ALLOCATOR_PROPERTIES Actual;
	HRESULT hr;
    hr = pAllocator->SetProperties(pprop,&Actual);
    if(FAILED(hr))
    {
        return hr;
    }

	ASSERT(Actual.cBuffers == 1);

	// ���������ꍇ���A���ۂ̌��ʂ��m�F����
    if(pprop->cBuffers > Actual.cBuffers ||
       pprop->cbBuffer > Actual.cbBuffer)
    {
        return E_FAIL;
    }

    return S_OK;
}

// override to suggest OUTPUT pin media types
HRESULT CPieceMovieFileMuxFilter::GetMediaType(int iPosition, CMediaType *pMediaType)
{

	//���f�B�A�^�C�v�̎擾

	ASSERT(iPosition == 0 || iPosition == 1);

    if(iPosition == 0)
    {
        CheckPointer(pMediaType,E_POINTER);

        pMediaType->SetType(&MEDIATYPE_Stream);
        pMediaType->SetSubtype(&MEDIASUBTYPE_None);	//�Ǝ��`��
        return S_OK;
    }

    return VFW_S_NO_MORE_ITEMS;
}


// return the number of pins we provide

int CPieceMovieFileMuxFilter::GetPinCount()
{
    return 3;
}


// return a non-addrefed CBasePin * for the user to addref if he holds onto it
// for longer than his pointer to us. We create the pins dynamically when they
// are asked for rather than in the constructor. This is because we want to
// give the derived class an oppportunity to return different pin objects

// We return the objects as and when they are needed. If either of these fails
// then we return NULL, the assumption being that the caller will realise the
// whole deal is off and destroy us - which in turn will delete everything.

CBasePin *
CPieceMovieFileMuxFilter::GetPin(int n)
{
    HRESULT hr = S_OK;

    // Create an input pin if necessary

    if (m_pVideoInput == NULL) {

        m_pVideoInput = new CMuxFilterVideoInputPin(NAME("PieceMovie Video input pin"),
													this,				      // Owner filter
													&hr,					  // Result code
													L"PieceMovie Video In");  // Pin name


        //  Can't fail
        ASSERT(SUCCEEDED(hr));
        if (m_pVideoInput == NULL) {
            return NULL;
        }

		m_pAudioInput = new CMuxFilterAudioInputPin(NAME("PieceMovie Audio input pin"),
													this,				      // Owner filter
													&hr,					  // Result code
													L"PieceMovie Audio In");  // Pin name


        //  Can't fail
        ASSERT(SUCCEEDED(hr));
        if (m_pAudioInput == NULL) {
            delete m_pVideoInput;
			m_pVideoInput = NULL;
			return NULL;
        }

        m_pOutput = new CMuxFilterOutputPin(NAME("PieceMovie output pin"),
                                            this,				 // Owner filter
                                            &hr,				 // Result code
                                            L"PieceMovie Out");  // Pin name

        // Can't fail
        ASSERT(SUCCEEDED(hr));
        if (m_pOutput == NULL) {
            delete m_pVideoInput;
			m_pVideoInput = NULL;
			delete m_pAudioInput;
			m_pAudioInput = NULL;			
        }
    }

    // Return the appropriate pin

    if (n == 0) {
        return m_pVideoInput;
    } else
    if (n == 1) {
        return m_pAudioInput;
	} else
	if (n == 2) {
        return m_pOutput;
    } else {
        return NULL;
    }
}


//
// FindPin
//
// If Id is In or Out then return the IPin* for that pin
// creating the pin if need be.  Otherwise return NULL with an error.

STDMETHODIMP CPieceMovieFileMuxFilter::FindPin(LPCWSTR Id, IPin **ppPin)
{
    CheckPointer(ppPin,E_POINTER);
    ValidateReadWritePtr(ppPin,sizeof(IPin *));

    if (0==lstrcmpW(Id,L"In"))
	{
		//Video�p�̃s���͐ڑ��ς݂��H
		if((m_pVideoInput != NULL) && (m_pVideoInput->IsConnected() == TRUE))
			*ppPin = GetPin(1);	//Audio�p�s���������o��
		else
			*ppPin = GetPin(0);	//Video�p�s���������o��
    } else if (0==lstrcmpW(Id,L"Out")) {
        *ppPin = GetPin(2);
    } else {
        *ppPin = NULL;
        return VFW_E_NOT_FOUND;
    }

    HRESULT hr = NOERROR;
    //  AddRef() returned pointer - but GetPin could fail if memory is low.
    if (*ppPin) {
        (*ppPin)->AddRef();
    } else {
        hr = E_OUTOFMEMORY;  // probably.  There's no pin anyway.
    }
    return hr;
}


// override these two functions if you want to inform something
// about entry to or exit from streaming state.

HRESULT
CPieceMovieFileMuxFilter::StartStreaming()
{
	//�������ݏ��̏�����
	m_tTransformInfo.Init();

	//�t���[���C���f�b�N�X�̏�����
	m_tTransformInfo.m_dwVideoFrame = 0;
	m_tTransformInfo.m_dwAudioFrame = 0;
m_FrameCountLock.Lock();					//2005/07/31 Added by Madoka
	m_tTransformInfo.m_dwMuxFrame   = 0;
m_FrameCountLock.Unlock();					//2005/07/31 Added by Madoka

	//���p�X�g���[�������Z�b�g
	if(m_pVideoInput->IsConnected())
		m_tTransformInfo.m_nUseStream++;
	if(m_pAudioInput->IsConnected())
		m_tTransformInfo.m_nUseStream++;

    return NOERROR;
}


HRESULT
CPieceMovieFileMuxFilter::StopStreaming()
{
	//PMF�t�@�C���w�b�_����������

	HRESULT hr;

	if(m_pOutput->IsConnected() == FALSE)
        return E_FAIL;

	//�_�E���X�g���[��(���i)�̓��̓s�����擾
    IStream *pStream;
    IPin * pDwnstrmInputPin = m_pOutput->GetConnected();

    if(!pDwnstrmInputPin)
        return E_FAIL;

	//�X�g���[���C���^�[�t�F�[�X(�������ݐ�t�@�C���X�g���[��)�̎擾
    hr = ((IMemInputPin *) pDwnstrmInputPin)->QueryInterface(IID_IStream, 
                                                             (void **)&pStream);
    if(SUCCEEDED(hr))
    {
		//PMF�t�@�C���w�b�_�����쐬
        BYTE *pb = new BYTE[PMF_FILE_HEADER_SIZE];
		PMF_FILE_HEADER_TYPE *pPMFFileHeader = (PMF_FILE_HEADER_TYPE*)pb;

		pPMFFileHeader->dwSignature        = FCC(PMF_FCC);
		pPMFFileHeader->wfix8FPS           = PMF_FPS_FIXED;
		pPMFFileHeader->wAudioDataSize     = PIECE_MOVIE_AUDIO_DATA_SIZE;
		pPMFFileHeader->dwTotalFrames      = m_tTransformInfo.m_dwMuxFrame;
		//pPMFFileHeader->dwReserve        = 0;	//Ver.PMF1
		pPMFFileHeader->dwOffsetForKeyList = PMF_FILE_HEADER_SIZE + m_tTransformInfo.m_dwPMFDataSize;

		//�t�@�C���X�g���[���̐擪�Ɉړ�
        LARGE_INTEGER li;
        ZeroMemory(&li, sizeof(li));
		
		hr = pStream->Seek(li, STREAM_SEEK_SET, 0);

        if(SUCCEEDED(hr))
        {
			//PMF�t�@�C���w�b�_�̏�������
            hr = pStream->Write(pb, PMF_FILE_HEADER_SIZE, 0);
        }

		//���[�N�����
		delete[] pb;
		pb = NULL;

		//2005/06/05 Added by Madoka >>> ��������
		//�L�[�t���[�����X�g�����쐬
		DWORD dwSize = (DWORD)(PMF_KEY_LIST_HEADER_INFO_SIZE + 
					           PMF_KEY_FRAME_OFFSET_INFO_SIZE * 
					           m_tTransformInfo.m_vecKeyFrameOffset.size());
		pb = new BYTE[dwSize];
		PMF_KEY_LIST_HEADER_TYPE *pPMFKeyListHeader = (PMF_KEY_LIST_HEADER_TYPE*)pb;
		long lIndex;

		pPMFKeyListHeader->dwSignature = FCC(KLH_FCC);
		pPMFKeyListHeader->lKeyFrames = (long)m_tTransformInfo.m_vecKeyFrameOffset.size();
		
		for(lIndex = 0;lIndex < pPMFKeyListHeader->lKeyFrames;++lIndex)
		{
			pPMFKeyListHeader->atKeyFrameList[lIndex] = m_tTransformInfo.m_vecKeyFrameOffset[lIndex];
		}
		
		//�t�@�C���X�g���[���̖����Ɉړ�
        ZeroMemory(&li, sizeof(li));
		
		hr = pStream->Seek(li, STREAM_SEEK_END, 0);

        if(SUCCEEDED(hr))
        {
			//�L�[�t���[�����X�g�̏�������
            hr = pStream->Write(pb, dwSize, 0);
        }

		//���[�N���
		delete[] pb;
		pb = NULL;

		//2005/06/05 Added by Madoka <<< �����܂�
		
        pStream->Release();
    }

	return hr;
}


// override this to grab extra interfaces on connection

HRESULT
CPieceMovieFileMuxFilter::CheckConnect(PIN_DIRECTION dir,IPin *pPin)
{
    UNREFERENCED_PARAMETER(dir);
    UNREFERENCED_PARAMETER(pPin);
    return NOERROR;
}


// place holder to allow derived classes to release any extra interfaces

HRESULT
CPieceMovieFileMuxFilter::BreakConnect(PIN_DIRECTION dir)
{
    UNREFERENCED_PARAMETER(dir);
    return NOERROR;
}


// Let derived classes know about connection completion

HRESULT
CPieceMovieFileMuxFilter::CompleteConnect(PIN_DIRECTION direction,IPin *pReceivePin)
{
    UNREFERENCED_PARAMETER(direction);
    UNREFERENCED_PARAMETER(pReceivePin);
    return NOERROR;
}


// override this to know when the media type is really set

HRESULT
CPieceMovieFileMuxFilter::SetMediaType(PIN_DIRECTION direction,const CMediaType *pmt)
{
    UNREFERENCED_PARAMETER(direction);
    UNREFERENCED_PARAMETER(pmt);
    return NOERROR;
}


// Set up our output sample
HRESULT
CPieceMovieFileMuxFilter::InitializeOutputSample(IMediaSample *pSample, IMediaSample **ppOutSample)
{
    IMediaSample *pOutSample;

    // default - times are the same

    AM_SAMPLE2_PROPERTIES * const pProps
	 = (m_pVideoInput->IsConnected() == TRUE) ? m_pVideoInput->SampleProps()
											  : m_pAudioInput->SampleProps();
    DWORD dwFlags = m_bSampleSkipped ? AM_GBF_PREVFRAMESKIPPED : 0;

    // This will prevent the image renderer from switching us to DirectDraw
    // when we can't do it without skipping frames because we're not on a
    // keyframe.  If it really has to switch us, it still will, but then we
    // will have to wait for the next keyframe
    if (!(pProps->dwSampleFlags & AM_SAMPLE_SPLICEPOINT)) {
	dwFlags |= AM_GBF_NOTASYNCPOINT;
    }

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux OutInit1")));

    ASSERT(m_pOutput->m_pAllocator != NULL);
    HRESULT hr = m_pOutput->m_pAllocator->GetBuffer(
             &pOutSample
             , pProps->dwSampleFlags & AM_SAMPLE_TIMEVALID ?
                   &pProps->tStart : NULL
             , pProps->dwSampleFlags & AM_SAMPLE_STOPVALID ?
                   &pProps->tStop : NULL
             , dwFlags
         );

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux OutInit2")));

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux OutAdd")));
    *ppOutSample = pOutSample;
    if (FAILED(hr)) {
        return hr;
    }

    ASSERT(pOutSample);
    IMediaSample2 *pOutSample2;
    if (SUCCEEDED(pOutSample->QueryInterface(IID_IMediaSample2,
                                             (void **)&pOutSample2))) {
        /*  Modify it */
        AM_SAMPLE2_PROPERTIES OutProps;
        EXECUTE_ASSERT(SUCCEEDED(pOutSample2->GetProperties(
            FIELD_OFFSET(AM_SAMPLE2_PROPERTIES, tStart), (PBYTE)&OutProps)
        ));
        OutProps.dwTypeSpecificFlags = pProps->dwTypeSpecificFlags;
        OutProps.dwSampleFlags =
            (OutProps.dwSampleFlags & AM_SAMPLE_TYPECHANGED) |
            (pProps->dwSampleFlags & ~AM_SAMPLE_TYPECHANGED);
        OutProps.tStart = pProps->tStart;
        OutProps.tStop  = pProps->tStop;
        OutProps.cbData = FIELD_OFFSET(AM_SAMPLE2_PROPERTIES, dwStreamId);
        hr = pOutSample2->SetProperties(
            FIELD_OFFSET(AM_SAMPLE2_PROPERTIES, dwStreamId),
            (PBYTE)&OutProps
        );
        if (pProps->dwSampleFlags & AM_SAMPLE_DATADISCONTINUITY) {
            m_bSampleSkipped = FALSE;
        }
        pOutSample2->Release();
    } else {
        if (pProps->dwSampleFlags & AM_SAMPLE_TIMEVALID) {
            pOutSample->SetTime(&pProps->tStart,
                                &pProps->tStop);
        }
        if (pProps->dwSampleFlags & AM_SAMPLE_SPLICEPOINT) {
            pOutSample->SetSyncPoint(TRUE);
        }
        if (pProps->dwSampleFlags & AM_SAMPLE_DATADISCONTINUITY) {
            pOutSample->SetDiscontinuity(TRUE);
            m_bSampleSkipped = FALSE;
        }
        // Copy the media times

        LONGLONG MediaStart, MediaEnd;
        if(pSample != NULL)
		{
			if (pSample->GetMediaTime(&MediaStart,&MediaEnd) == NOERROR) {
		        pOutSample->SetMediaTime(&MediaStart,&MediaEnd);
			}
		}
    }
    return S_OK;
}

// override this to customize the transform process

HRESULT CPieceMovieFileMuxFilter::VideoReceive(IMediaSample *pSample)
{
	/*  Check for other streams and pass them on */
    AM_SAMPLE2_PROPERTIES * const pProps = m_pVideoInput->SampleProps();
    if(pProps->dwStreamId != AM_STREAM_MEDIA) {
        return m_pOutput->m_pInputPin->Receive(pSample);	//�X���[
    }
    HRESULT hr;
    ASSERT(pSample);
    
	//Video�̏�������
	hr = VideoTransform(pSample);

	if(FAILED(hr))
		return hr;

	//Audio�������ς݂��H
	if((m_pAudioInput->IsConnected() == FALSE) ||
	   m_tTransformInfo.IsAudioTransformComplete() == TRUE)
	{
		//�o�͐�o�b�t�@�̏�����
		IMediaSample * pOutSample = NULL;

		// If no output to deliver to then no point sending us data

		ASSERT (m_pOutput != NULL) ;

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux VideoReceive IN1")));

		// Set up the output sample
		hr = InitializeOutputSample(pSample, &pOutSample);

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux VideoReceive IN2")));

		if(FAILED(hr))
			return hr;

		//Mux����
		hr = PieceMovieMux(pOutSample);
	}

    return hr; 
}

HRESULT CPieceMovieFileMuxFilter::VideoTransform(IMediaSample *pIn)
{
	//Video�f�[�^�̕ϊ�����

	HRESULT hr = NOERROR;

	//����̃t���[���f�[�^���擾
	//(128*88��8bitBMP(DIB)�Ƃ��ăf�[�^�͂���Ă���)
	hr = GetFrameData(pIn);

	if(FAILED(hr))
		return hr;

	//����̓L�[�t���[�����H
	if((m_tTransformInfo.m_dwVideoFrame % PIECE_MOVIE_VIDEO_KEY_CYCLE) == 0)
	{
		//�L�[�t���[���̕ϊ�����
		hr = VideoKeyFrameTransform();
	}
	//�O��̃t���[���ƑS���������H
	else if(memcmp(m_tTransformInfo.m_abyOldFrame,m_tTransformInfo.m_abyFrame,
		           sizeof(m_tTransformInfo.m_abyOldFrame)) == 0)
	{
		//�O�ƑS�������t���[���t���O���Z�b�g
		m_tTransformInfo.GetFrameHeaderForVideo() &= ~(PIECE_MOVIE_VIDEO_SAME_MASK | PIECE_MOVIE_VIDEO_KEY_MASK);
		m_tTransformInfo.GetFrameHeaderForVideo() |= PIECE_MOVIE_VIDEO_SAME_MASK;

		//Video�t���[���̃f�[�^�T�C�Y��0��
		m_tTransformInfo.GetFrameHeaderForVideo() &= ~PIECE_MOVIE_VIDEO_SIZE_MASK;	

		//����I��
		hr = NOERROR;
	}
	else
	{
		//�t���[���Ԉ��k���Ȃ��珑�����ݗp�f�[�^���쐬
		
		//Video�t���[���t���O�̃N���A
		m_tTransformInfo.GetFrameHeaderForVideo() &= ~(PIECE_MOVIE_VIDEO_SAME_MASK | PIECE_MOVIE_VIDEO_KEY_MASK);
	
		//�ϊ�����
		WORD wBitStreamSize = 0;	//�r�b�g�X�g���[���̃T�C�Y
		int nRawPixels      = 0;	//�O�̃t���[���ƈႤ(�����k)�s�N�Z���̐�
		int nBits           = 0;	//�����r�b�g��
		BYTE *pOldFrame = m_tTransformInfo.m_abyOldFrame;		//�O��̃t���[���f�[�^�ւ̃|�C���^
		BYTE *pNowFrame = m_tTransformInfo.m_abyFrame;			//����̃t���[���f�[�^�ւ̃|�C���^
		BYTE *pStream   = m_tTransformInfo.m_tVideo.m_abyVideo;	//Video�f�[�^Bit�X�g���[���ւ̃|�C���^
		int i;					
		int nMax = PIECE_SCREEN_WIDTH * PIECE_SCREEN_HEIGHT;
		#define CHECK_8BIT do{ if(nBits == 8){ pStream++; nBits = 0; } }while(0)
		#define NEXT_BIT   do{ (*pStream) <<= 1; nBits++; wBitStreamSize++; }while(0) 
		
		for(i = 0;i < nMax;++i)
		{
			//�O��̃t���[���ƃs�N�Z�����r
			if(*pOldFrame == *pNowFrame)
			{
				//���̃r�b�g��
				NEXT_BIT;

				//���k�r�b�g�t���O(=1)��ǉ�
				(*pStream) |= 0x01;
				
				//8bit���܂������H
				CHECK_8BIT;
			}	
			else
			{
				//���̃r�b�g��
				//�����k�̃r�b�g�t���O��0�Ȃ̂�
				//����1�V�t�g�����i�K�ŃZ�b�g����
				NEXT_BIT;

				//8bit���܂������H
				CHECK_8BIT;

				//�s�N�Z���l(4bit)����������
				BYTE byColor = *pNowFrame;
				int p;
				for(p = 0;p < 4;++p)
				{	
					//���̃r�b�g��
					NEXT_BIT;

					//�s�N�Z���l��������
					(*pStream) |= ((byColor & 0x08) >> 3);
					byColor <<= 1;

					//8bit���܂������H
					CHECK_8BIT;
				}

				//�O�̃t���[���ƈႤ�s�N�Z���̐����X�V
				nRawPixels++;
			}

			//���̃s�N�Z����
			pOldFrame++;
			pNowFrame++;

			//�O�̃t���[���ƈႤ(�����k)�s�N�Z���̐���
			//���k���E��臒l�𒴂��Ă��Ȃ����H
			if(nRawPixels >= PIECE_MOVIE_VIDEO_KEY_THRESHOLD)
			{
				//����ȏ�͈��k�ɂȂ�Ȃ��̂ŁA�L�[�t���[���Ƃ��Ĉ���
				//�܂��A����ȏ㈳�k���Ă��A�W�J�Ɏ��Ԃ��������Ă��܂���
				//15fps(���ۂ�1�t���[����4��ŕ\������̂�60fps)�̍Đ�
				//�ɊԂɍ���Ȃ��̂ŁA�����ň��k���~�߂�
				hr = VideoKeyFrameTransform();
				goto TRANSFORM_END;
			}
		}

		//�f�[�^�T�C�Y���Z�b�g
		wBitStreamSize = (wBitStreamSize + 7 ) / 8;
		
		//�T�C�Y�������ꍇ�͖���
		if(wBitStreamSize == 0)
			return NOERROR;

		m_tTransformInfo.GetFrameHeaderForVideo() &= ~PIECE_MOVIE_VIDEO_SIZE_MASK;
		m_tTransformInfo.GetFrameHeaderForVideo() |= wBitStreamSize;

		//����I��
		hr = NOERROR;
	}

TRANSFORM_END:

	//�O��̃t���[���f�[�^�Ƃ��ĕۑ�
	memcpy(m_tTransformInfo.m_abyOldFrame,m_tTransformInfo.m_abyFrame,
		   sizeof(m_tTransformInfo.m_abyOldFrame));

	//����̃f�[�^���L���[�ɒǉ�
	m_tTransformInfo.m_queVideo.push_back(m_tTransformInfo.m_tVideo);

	//�����σt���[���C���f�b�N�X�X�V
	m_tTransformInfo.m_dwVideoFrame++;
	
	return hr;
}

HRESULT CPieceMovieFileMuxFilter::GetFrameData(IMediaSample *pIn)
{
	//�t���[���f�[�^�̎擾
	//(128*88��8bitBMP(DIB)�Ƃ��ăf�[�^�͂���Ă���̂ŁA
	// �㉺���]���Ď擾)
	
	//��ɂȂ�o�b�t�@�ւ̃|�C���^���擾����
    BYTE *pBufferIn;
    HRESULT hr;

	hr = pIn->GetPointer(&pBufferIn);
    if (FAILED(hr))
    {
        return hr;
    }
    
	//�㉺���]���Ď擾
	int i;
	int nMax = PIECE_SCREEN_WIDTH * PIECE_SCREEN_HEIGHT;
	
	for(i = 0;i < nMax;++i)
	{
		//�摜�̍������|�C���^�̌��_�ƂȂ�̂�
		//������Ɩʓ|�ȃA�h���X�v�Z�ɂȂ�܂�
		m_tTransformInfo.m_abyFrame[i]
		 = pBufferIn[nMax - PIECE_SCREEN_WIDTH * (i / PIECE_SCREEN_WIDTH + 1)
			              + (i % PIECE_SCREEN_WIDTH)];
	}
	
	return NOERROR;
}

HRESULT CPieceMovieFileMuxFilter::VideoKeyFrameTransform(void)
{
	//Video�L�[�t���[���̕ϊ�����
	
	HRESULT hr = NOERROR;
	
	//�t���[���w�b�_�ɃL�[�t���[���t���O���Z�b�g
	m_tTransformInfo.GetFrameHeaderForVideo() &= ~(PIECE_MOVIE_VIDEO_SAME_MASK | PIECE_MOVIE_VIDEO_KEY_MASK);
	m_tTransformInfo.GetFrameHeaderForVideo() |= PIECE_MOVIE_VIDEO_KEY_MASK;

	//�t���[���w�b�_�Ƀf�[�^�T�C�Y���Z�b�g
	m_tTransformInfo.GetFrameHeaderForVideo() &= ~PIECE_MOVIE_VIDEO_SIZE_MASK;
	m_tTransformInfo.GetFrameHeaderForVideo() |= PIECE_MOVIE_VIDEO_DATA_MAXSIZE;

	//�ϊ�����
	BYTE *pNowFrame = m_tTransformInfo.m_abyFrame;			//����̃t���[���f�[�^�ւ̃|�C���^
	BYTE *pStream   = m_tTransformInfo.m_tVideo.m_abyVideo;	//Video�f�[�^Bit�X�g���[���ւ̃|�C���^
	BYTE byColor;
	int i,j,p;					
	int nMax = (PIECE_SCREEN_WIDTH / 2) * PIECE_SCREEN_HEIGHT;
	
	for(i = 0;i < nMax;++i)
	{
		//2�s�N�Z��������
		//1�ڂ̃s�N�Z���͏��4bit�Ɋi�[
		//2�ڂ̃s�N�Z���͉���4bit�Ɋi�[
		for(j = 0;j < 2;++j)
		{
			byColor = *pNowFrame;
			for(p = 0;p < 4;++p)
			{
				//���̃r�b�g��
				(*pStream) <<= 1;

				//�s�N�Z���l��������
				(*pStream) |= ((byColor & 0x08) >> 3);
				byColor <<= 1;
			}

			//���̃s�N�Z����
			pNowFrame++;
		}

		//���̈ʒu��
		pStream++;
	}

	return hr;
}

HRESULT CPieceMovieFileMuxFilter::AudioReceive(IMediaSample *pSample)
{
	/*  Check for other streams and pass them on */
    AM_SAMPLE2_PROPERTIES * const pProps = m_pAudioInput->SampleProps();
    if(pProps->dwStreamId != AM_STREAM_MEDIA) {
        return m_pOutput->m_pInputPin->Receive(pSample);	//�X���[
    }
    HRESULT hr;
    ASSERT(pSample);
	
	//Audio�̏�������
	hr = AudioTransform(pSample);

	if(FAILED(hr)) {
		return hr;
	}

	//Video�������ς݂��H
	if((m_pVideoInput->IsConnected() == FALSE) ||
	   m_tTransformInfo.IsVideoTramsformComplete() == TRUE)
	{
		//�o�͐�o�b�t�@�̏�����
		IMediaSample * pOutSample = NULL;

		// If no output to deliver to then no point sending us data

		ASSERT (m_pOutput != NULL) ;

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux AudioReceive IN1")));

		// Set up the output sample
		hr = InitializeOutputSample(pSample, &pOutSample);

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux AudioReceive IN2")));

		if (FAILED(hr)) {
			return hr;
		}		
	
		//Mux����
		hr = PieceMovieMux(pOutSample);
	}

    return hr; 
}

HRESULT CPieceMovieFileMuxFilter::AudioTransform(IMediaSample *pIn)
{
	//Audio�f�[�^�̕ϊ�����

	HRESULT hr = NOERROR;
	
	//���̓s���̃o�b�t�@�ւ̃|�C���^���擾����
    BYTE *pBufferIn;

	hr = pIn->GetPointer(&pBufferIn);
    if (FAILED(hr))
    {
        return hr;
    }
    
	//���̓T�C�Y���擾
	long lSize = pIn->GetActualDataLength();

	//�O��̗]�肪���邩�H
	if(m_tTransformInfo.m_nWorkAudioSize > 0)
	{
		//PIECE_MOVIE_AUDIO_DATA_SIZE�܂ł�
		//�c�蕪�ɑ���邩�H
		if(lSize >= (PIECE_MOVIE_AUDIO_DATA_SIZE - m_tTransformInfo.m_nWorkAudioSize))
		{
			//Audio�̗��p�r�b�g���Z�b�g
			m_tTransformInfo.GetFrameHeaderForAudio() |= PIECE_MOVIE_AUDIO_USE_MASK; 

			//�O��̗]��ɍ���̃f�[�^��ǉ�
			int nSize = PIECE_MOVIE_AUDIO_DATA_SIZE -
		       			m_tTransformInfo.m_nWorkAudioSize;

			memcpy((m_tTransformInfo.m_tWorkAudio.m_abyAudio +
					m_tTransformInfo.m_nWorkAudioSize),
					pBufferIn,nSize);

			//�L���[�ɒǉ�
			m_tTransformInfo.m_queAudio.push_back(m_tTransformInfo.m_tWorkAudio);

			//�����σt���[���C���f�b�N�X�X�V
			m_tTransformInfo.m_dwAudioFrame++;

			//�ǉ�����������������
			lSize     -= nSize;
			pBufferIn += nSize;
		}
		else
		{
			//�S���擾
			memcpy((m_tTransformInfo.m_tWorkAudio.m_abyAudio +
					m_tTransformInfo.m_nWorkAudioSize),
					pBufferIn,lSize);
			m_tTransformInfo.m_nWorkAudioSize += lSize;	

			//�I��
			goto ABORT;
		}
	}

	//�����ɂ���Audio�f�[�^��1�t���[���P�ʂ̎��ԕ��ł͂Ȃ��̂ŁA
	//1�t���[���̎��ԕ��̃T�C�Y�ŕ������ăf�[�^�L���[�ɓo�^���܂��B
	int nMax = lSize / PIECE_MOVIE_AUDIO_DATA_SIZE;
	int i;
	for(i = 0;i < nMax;++i)
	{
		//Audio�̗��p�r�b�g���Z�b�g
		m_tTransformInfo.GetFrameHeaderForAudio() |= PIECE_MOVIE_AUDIO_USE_MASK; 

		//�f�[�^���R�s�[
		memcpy(m_tTransformInfo.m_tWorkAudio.m_abyAudio,
			   pBufferIn,PIECE_MOVIE_AUDIO_DATA_SIZE);

		//�L���[�ɒǉ�
		m_tTransformInfo.m_queAudio.push_back(m_tTransformInfo.m_tWorkAudio);

		//�����σt���[���C���f�b�N�X�X�V
		m_tTransformInfo.m_dwAudioFrame++;

		//�|�C���^��i�߂�
		pBufferIn += PIECE_MOVIE_AUDIO_DATA_SIZE;
	}

	//�]���ۑ�
	m_tTransformInfo.m_nWorkAudioSize = lSize % PIECE_MOVIE_AUDIO_DATA_SIZE;
	if(m_tTransformInfo.m_nWorkAudioSize > 0)
	{
		ZeroMemory(m_tTransformInfo.m_tWorkAudio.m_abyAudio,PIECE_MOVIE_AUDIO_DATA_SIZE);
		memcpy(m_tTransformInfo.m_tWorkAudio.m_abyAudio,pBufferIn,
			   m_tTransformInfo.m_nWorkAudioSize);
	}

ABORT:
	return hr;
}

HRESULT CPieceMovieFileMuxFilter::PieceMovieMux(IMediaSample *pOutSample)
{

	//Piece Movie File��Mux����

	// Start timing the transform (if PERF is defined)
    MSR_START(m_idTransform);

	//�t���[���w�b�_���擾
	WORD wFrameHeader = m_tTransformInfo.m_mapFrameHeader[m_tTransformInfo.m_dwMuxFrame];
	m_tTransformInfo.m_mapFrameHeader.erase(m_tTransformInfo.m_dwMuxFrame);	//�p�ς݃f�[�^�͍폜
	
	//�f�[�^����������
    BYTE *pDestBuffer;
    long lSourceSize = 0;
	WORD wVideoSize  = wFrameHeader & PIECE_MOVIE_VIDEO_SIZE_MASK;
	BOOL bVideoSame  = ((wFrameHeader & PIECE_MOVIE_VIDEO_SAME_MASK) > 0) ? TRUE : FALSE;
	BOOL bVideoUse   = ((bVideoSame == TRUE) || (wVideoSize > 0)) ? TRUE : FALSE;
	BOOL bAudioUse   = ((wFrameHeader & PIECE_MOVIE_AUDIO_USE_MASK)  > 0) ? TRUE : FALSE;
	
	//�������ރf�[�^�T�C�Y���Z�o
	lSourceSize += PIECE_MOVIE_FRAME_HEADER_SIZE;
	lSourceSize += wVideoSize;
	lSourceSize += (bAudioUse == TRUE) ? PIECE_MOVIE_AUDIO_DATA_SIZE : 0;
		
#ifdef DEBUG    
    ASSERT(pOutSample);
	long lDestSize = pOutSample->GetSize();
    ASSERT(lDestSize >= lSourceSize);
#endif

	//�������ݐ�̃|�C���^���擾
    pOutSample->GetPointer(&pDestBuffer);
    
	//�t���[���w�b�_�̏�������(�R�s�[)
	CopyMemory((PVOID)pDestBuffer,&wFrameHeader,PIECE_MOVIE_FRAME_HEADER_SIZE);	
	pDestBuffer += PIECE_MOVIE_FRAME_HEADER_SIZE;

	//Video�t���[���f�[�^�̏�������(�R�s�[)
	if(bVideoUse)
	{
		PMF_VIDEO_DATA *pVideo = &m_tTransformInfo.m_queVideo.front(); 
	
		if(wVideoSize > 0)
		{
			CopyMemory((PVOID)pDestBuffer,pVideo->m_abyVideo,wVideoSize);	
			pDestBuffer += wVideoSize;
		}

		//�p�ς݃f�[�^�̍폜
		m_tTransformInfo.m_queVideo.pop_front();		
	}

	//Audio�t���[���f�[�^�̏�������(�R�s�[)
	if(bAudioUse)
	{
		PMF_AUDIO_DATA *pAudio = &m_tTransformInfo.m_queAudio.front(); 
	
		CopyMemory((PVOID)pDestBuffer,pAudio->m_abyAudio,PIECE_MOVIE_AUDIO_DATA_SIZE);	
		pDestBuffer += PIECE_MOVIE_AUDIO_DATA_SIZE;
		
		//�p�ς݃f�[�^�̍폜
		m_tTransformInfo.m_queAudio.pop_front();
	}
	
	//�������񂾃f�[�^�T�C�Y���Z�b�g
    pOutSample->SetActualDataLength(lSourceSize);

    //�ꉞ�`�F�b�N
    LONG lActual = pOutSample->GetActualDataLength();

    if((m_tTransformInfo.m_dwPMFDataSize + PMF_FILE_HEADER_SIZE + lActual)
	   < (m_tTransformInfo.m_dwPMFDataSize + PMF_FILE_HEADER_SIZE))
    { 
        return E_FAIL;      // overflow
    }

	//2005/06/05 Added by Maodka
	//����̓L�[�t���[�����H
	if((m_tTransformInfo.m_dwMuxFrame % PIECE_MOVIE_VIDEO_KEY_CYCLE) == 0)
	{
		//�L�[�t���[���̃I�t�Z�b�g�������X�g�ɒǉ�
		PMF_KEY_FRAME_OFFSET_INFO_TYPE tKeyFrameOffsetInfo;
		DWORD dwOffset = m_tTransformInfo.m_dwPMFDataSize + PMF_FILE_HEADER_SIZE;

		//�t�@�C���̐擪���炱���܂ł̃Z�N�^��
		tKeyFrameOffsetInfo.dwSector = dwOffset / PIECE_SECTOR_SIZE;
		
		//�Y���Z�N�^���ł̃I�t�Z�b�g�o�C�g��
		tKeyFrameOffsetInfo.dwOffsetBytes
		 = dwOffset - (tKeyFrameOffsetInfo.dwSector * PIECE_SECTOR_SIZE);

		//���X�g�ɒǉ�
		m_tTransformInfo.m_vecKeyFrameOffset.push_back(tKeyFrameOffsetInfo);
	}

	//�������݈ʒu���w��
    REFERENCE_TIME rtStart, rtEnd;
	HRESULT hr;

	rtStart = m_tTransformInfo.m_dwPMFDataSize + PMF_FILE_HEADER_SIZE;
    rtEnd   = rtStart + lActual;
    m_tTransformInfo.m_dwPMFDataSize += lActual;

    hr = pOutSample->SetTime(&rtStart, &rtEnd);
	
	//Mux�����σt���[�����̍X�V
m_FrameCountLock.Lock();					//2005/07/31 Added by Madoka
	m_tTransformInfo.m_dwMuxFrame++;
m_FrameCountLock.Unlock();					//2005/07/31 Added by Madoka

    // Stop the clock and log it (if PERF is defined)
    MSR_STOP(m_idTransform);

    if (FAILED(hr)) {
	DbgLog((LOG_TRACE,1,TEXT("Error from transform")));
    } else {
        // the Transform() function can return S_FALSE to indicate that the
        // sample should not be delivered; we only deliver the sample if it's
        // really S_OK (same as NOERROR, of course.)
        if (hr == NOERROR) {
    	    hr = m_pOutput->m_pInputPin->Receive(pOutSample);
            m_bSampleSkipped = FALSE;	// last thing no longer dropped
        } else {
            // S_FALSE returned from Transform is a PRIVATE agreement
            // We should return NOERROR from Receive() in this cause because returning S_FALSE
            // from Receive() means that this is the end of the stream and no more data should
            // be sent.
            if (S_FALSE == hr) {

                //  Release the sample before calling notify to avoid
                //  deadlocks if the sample holds a lock on the system
                //  such as DirectDraw buffers do
                pOutSample->Release();
                m_bSampleSkipped = TRUE;
                if (!m_bQualityChanged) {
                    NotifyEvent(EC_QUALITY_CHANGE,0,0);
                    m_bQualityChanged = TRUE;
                }
                return NOERROR;
            }
        }
    }

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux OutRelease")));

	//�o�͐�̉��
	pOutSample->Release();

    return hr;
}
	
HRESULT CPieceMovieFileMuxFilter::LastTransform(void)
{

	//�Ō�̕ϊ�����
	//EndOfStream����Ăяo����܂�

	HRESULT hr;

	//�܂�Audio�̗]�肪���邩�H
	if(m_tTransformInfo.m_nWorkAudioSize > 0)
	{
		//�c����N���A
		memset(m_tTransformInfo.m_tWorkAudio.m_abyAudio + 
			   m_tTransformInfo.m_nWorkAudioSize,0,
			   (PIECE_MOVIE_AUDIO_DATA_SIZE - 
			    m_tTransformInfo.m_nWorkAudioSize));

		//Audio�̗��p�r�b�g���Z�b�g
		m_tTransformInfo.GetFrameHeaderForAudio() |= PIECE_MOVIE_AUDIO_USE_MASK; 

		//�Ō�̃f�[�^���L���[�ɒǉ�
		m_tTransformInfo.m_queAudio.push_back(m_tTransformInfo.m_tWorkAudio);

		//�����σt���[���C���f�b�N�X�X�V
		m_tTransformInfo.m_dwAudioFrame++;
	}

	//�c��̕ϊ����s��
	while(m_tTransformInfo.IsVideoTramsformComplete())
	{
		//�o�͐�o�b�t�@�̏�����
		IMediaSample * pOutSample = NULL;

		// If no output to deliver to then no point sending us data

		ASSERT (m_pOutput != NULL) ;

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux LastTransform IN1")));

		// Set up the output sample
		hr = InitializeOutputSample(NULL, &pOutSample);

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("Mux LastTransform IN2")));

		if (FAILED(hr)) {
			return hr;
		}		
	
		//Mux����
		hr = PieceMovieMux(pOutSample);
	}

	return NOERROR;
}

	
// Return S_FALSE to mean "pass the note on upstream"
// Return NOERROR (Same as S_OK)
// to mean "I've done something about it, don't pass it on"
HRESULT CPieceMovieFileMuxFilter::AlterQuality(Quality q)
{
    UNREFERENCED_PARAMETER(q);
    return S_FALSE;
}


// EndOfStream received. Default behaviour is to deliver straight
// downstream, since we have no queued data. If you overrode Receive
// and have queue data, then you need to handle this and deliver EOS after
// all queued data is sent
HRESULT
CPieceMovieFileMuxFilter::EndOfStream(void)
{
    HRESULT hr = NOERROR;

	//Video��Audio�̃X�g���[���ł��ꂼ��Ăяo����܂�
	//�܂�A�����ɂ�2�񗈂܂�

	//�f�[�^��Video�EAudio�̏��Ԃł����Ɨ���̂ł͂Ȃ��A
	//��������Audio���΁[���Ƃ��������āA���񂩂Ɉ��
	//Video������Ƃ��������ł��B
	//�ł��̂ŁA�e�f�[�^�̓L���[�ɗ��߂āA1�t���[������
	//�f�[�^������������_��Mux�t�B���^�ɑ��M���܂��B

	//�X�g���[���̏I��
	if(m_tTransformInfo.StreamEnd())
	{
		//�Ō�̕ϊ����s��
		hr = LastTransform();
		if(FAILED(hr)) return hr;

		if (m_pOutput != NULL) {
			hr = m_pOutput->DeliverEndOfStream();
		}
	}

    return hr;
}


// enter flush state. Receives already blocked
// must override this if you have queued data or a worker thread
HRESULT
CPieceMovieFileMuxFilter::BeginFlush(void)
{
    HRESULT hr = NOERROR;
    if (m_pOutput != NULL) {
	// block receives -- done by caller (CBaseInputPin::BeginFlush)

	// discard queued data -- we have no queued data

	// free anyone blocked on receive - not possible in this filter

	// call downstream
	hr = m_pOutput->DeliverBeginFlush();
    }
    return hr;
}


// leave flush state. must override this if you have queued data
// or a worker thread
HRESULT
CPieceMovieFileMuxFilter::EndFlush(void)
{
    // sync with pushing thread -- we have no worker thread

    // ensure no more data to go downstream -- we have no queued data

    // call EndFlush on downstream pins
    ASSERT (m_pOutput != NULL);
    return m_pOutput->DeliverEndFlush();

    // caller (the input pin's method) will unblock Receives
}


// override these so that the derived filter can catch them

STDMETHODIMP
CPieceMovieFileMuxFilter::Stop()
{
    CAutoLock lck1(&m_csFilter);
    if (m_State == State_Stopped) {
        return NOERROR;
    }

    // Succeed the Stop if we are not completely connected

    ASSERT(m_pVideoInput == NULL || m_pAudioInput == NULL || m_pOutput != NULL);
    if (m_pVideoInput == NULL || m_pVideoInput->IsConnected() == FALSE ||
        m_pAudioInput == NULL || m_pAudioInput->IsConnected() == FALSE ||
		m_pOutput->IsConnected() == FALSE) {
                m_State = State_Stopped;
                m_bEOSDelivered = FALSE;
                return NOERROR;
    }

    ASSERT(m_pVideoInput);
    ASSERT(m_pAudioInput);
    ASSERT(m_pOutput);

    // decommit the input pin before locking or we can deadlock
    m_pVideoInput->Inactive();
	m_pAudioInput->Inactive();

    // synchronize with Receive calls

    CAutoLock lck2(&m_csReceive);
    m_pOutput->Inactive();

    // allow a class derived from CTransformFilter
    // to know about starting and stopping streaming

    HRESULT hr = StopStreaming();
    if (SUCCEEDED(hr)) {
	// complete the state transition
	m_State = State_Stopped;
	m_bEOSDelivered = FALSE;
    }
    return hr;
}


STDMETHODIMP
CPieceMovieFileMuxFilter::Pause()
{
    CAutoLock lck(&m_csFilter);
    HRESULT hr = NOERROR;

    if (m_State == State_Paused) {
        // (This space left deliberately blank)
    }

    // If we have no input pin or it isn't yet connected then when we are
    // asked to pause we deliver an end of stream to the downstream filter.
    // This makes sure that it doesn't sit there forever waiting for
    // samples which we cannot ever deliver without an input connection.

    else if (m_pVideoInput == NULL || 
			 m_pAudioInput == NULL ||
			 ((m_pVideoInput->IsConnected() == FALSE) && (m_pAudioInput->IsConnected() == FALSE))) {
        if (m_pOutput && m_bEOSDelivered == FALSE) {
            m_pOutput->DeliverEndOfStream();
            m_bEOSDelivered = TRUE;
        }
        m_State = State_Paused;
    }

    // We may have an input connection but no output connection
    // However, if we have an input pin we do have an output pin

    else if (m_pOutput->IsConnected() == FALSE) {
        m_State = State_Paused;
    }

    else {
	if (m_State == State_Stopped) {
	    // allow a class derived from CTransformFilter
	    // to know about starting and stopping streaming
            CAutoLock lck2(&m_csReceive);
	    hr = StartStreaming();
	}
	if (SUCCEEDED(hr)) {
	    hr = CBaseFilter::Pause();
	}
    }

    m_bSampleSkipped = FALSE;
    m_bQualityChanged = FALSE;
    return hr;
}

HRESULT
CPieceMovieFileMuxFilter::NewSegment(
    REFERENCE_TIME tStart,
    REFERENCE_TIME tStop,
    double dRate)
{
    if (m_pOutput != NULL) {
        return m_pOutput->DeliverNewSegment(tStart, tStop, dRate);
    }
    return S_OK;
}

// Check streaming status
HRESULT
CMuxFilterInputPin::CheckStreaming()
{
    ASSERT(m_pMuxFilter->m_pOutput != NULL);
    if (!m_pMuxFilter->m_pOutput->IsConnected()) {
        return VFW_E_NOT_CONNECTED;
    } else {
        //  Shouldn't be able to get any data if we're not connected!
        ASSERT(IsConnected());

        //  we're flushing
        if (m_bFlushing) {
            return S_FALSE;
        }
        //  Don't process stuff in Stopped state
        if (IsStopped()) {
            return VFW_E_WRONG_STATE;
        }
        if (m_bRunTimeError) {
    	    return VFW_E_RUNTIME_ERROR;
        }
        return S_OK;
    }
}


// =================================================================
// Implements the CMuxFilterInputPin class
// =================================================================


// constructor

CMuxFilterInputPin::CMuxFilterInputPin(
    TCHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pName)
    : CBaseInputPin(pObjectName, pMuxFilter, &pMuxFilter->m_csFilter, phr, pName)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterInputPin::CMuxFilterInputPin")));
    m_pMuxFilter = pMuxFilter;
}

#ifdef UNICODE
CMuxFilterInputPin::CMuxFilterInputPin(
    CHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pName)
    : CBaseInputPin(pObjectName, pMuxFilter, &pMuxFilter->m_csFilter, phr, pName)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterInputPin::CMuxFilterInputPin")));
    m_pMuxFilter = pMuxFilter;
}
#endif

// provides derived filter a chance to grab extra interfaces

HRESULT
CMuxFilterInputPin::CheckConnect(IPin *pPin)
{
    HRESULT hr = m_pMuxFilter->CheckConnect(PINDIR_INPUT,pPin);
    if (FAILED(hr)) {
    	return hr;
    }
    return CBaseInputPin::CheckConnect(pPin);
}


// provides derived filter a chance to release it's extra interfaces

HRESULT
CMuxFilterInputPin::BreakConnect()
{
    //  Can't disconnect unless stopped
    ASSERT(IsStopped());
    m_pMuxFilter->BreakConnect(PINDIR_INPUT);
    return CBaseInputPin::BreakConnect();
}


// Let derived class know when the input pin is connected

HRESULT
CMuxFilterInputPin::CompleteConnect(IPin *pReceivePin)
{
    HRESULT hr = m_pMuxFilter->CompleteConnect(PINDIR_INPUT,pReceivePin);
    if (FAILED(hr)) {
        return hr;
    }
    return CBaseInputPin::CompleteConnect(pReceivePin);
}


// =================================================================
// Implements IMemInputPin interface
// =================================================================


// provide EndOfStream that passes straight downstream
// (there is no queued data)
STDMETHODIMP
CMuxFilterInputPin::EndOfStream(void)
{
    CAutoLock lck(&m_pMuxFilter->m_csReceive);
    HRESULT hr = CheckStreaming();
    if (S_OK == hr) {
       hr = m_pMuxFilter->EndOfStream();
    }
    return hr;
}


// enter flushing state. Call default handler to block Receives, then
// pass to overridable method in filter
STDMETHODIMP
CMuxFilterInputPin::BeginFlush(void)
{
    CAutoLock lck(&m_pMuxFilter->m_csFilter);
    //  Are we actually doing anything?
    ASSERT(m_pMuxFilter->m_pOutput != NULL);
    if (!IsConnected() ||
        !m_pMuxFilter->m_pOutput->IsConnected()) {
        return VFW_E_NOT_CONNECTED;
    }
    HRESULT hr = CBaseInputPin::BeginFlush();
    if (FAILED(hr)) {
    	return hr;
    }

    return m_pMuxFilter->BeginFlush();
}


// leave flushing state.
// Pass to overridable method in filter, then call base class
// to unblock receives (finally)
STDMETHODIMP
CMuxFilterInputPin::EndFlush(void)
{
    CAutoLock lck(&m_pMuxFilter->m_csFilter);
    //  Are we actually doing anything?
    ASSERT(m_pMuxFilter->m_pOutput != NULL);
    if (!IsConnected() ||
        !m_pMuxFilter->m_pOutput->IsConnected()) {
        return VFW_E_NOT_CONNECTED;
    }

    HRESULT hr = m_pMuxFilter->EndFlush();
    if (FAILED(hr)) {
        return hr;
    }

    return CBaseInputPin::EndFlush();
}


// override to pass downstream
STDMETHODIMP
CMuxFilterInputPin::NewSegment(
    REFERENCE_TIME tStart,
    REFERENCE_TIME tStop,
    double dRate)
{
    //  Save the values in the pin
    CBasePin::NewSegment(tStart, tStop, dRate);
    return m_pMuxFilter->NewSegment(tStart, tStop, dRate);
}

// =================================================================
// Implements the CMuxFilterVideoInputPin class
// =================================================================

// constructor

CMuxFilterVideoInputPin::CMuxFilterVideoInputPin(
    TCHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pName)
    : CMuxFilterInputPin(pObjectName, pMuxFilter, phr, pName)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterVideoInputPin::CMuxFilterVideoInputPin")));
    m_pMuxFilter = pMuxFilter;
}

#ifdef UNICODE
CMuxFilterVideoInputPin::CMuxFilterVideoInputPin(
    CHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pName)
    : CMuxFilterInputPin(pObjectName, pMuxFilter, &pMuxFilter->m_csFilter, phr, pName)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterVideoInputPin::CMuxFilterVideoInputPin")));
    m_pMuxFilter = pMuxFilter;
}
#endif

// check that we can support a given media type

HRESULT
CMuxFilterVideoInputPin::CheckMediaType(const CMediaType* pmt)
{
    // Check the input type

    HRESULT hr = m_pMuxFilter->CheckVideoInputType(pmt);
    if (S_OK != hr) {
        return hr;
    }

    // if the output pin is still connected, then we have
    // to check the transform not just the input format

    if ((m_pMuxFilter->m_pOutput != NULL) &&
        (m_pMuxFilter->m_pOutput->IsConnected())) {
            return m_pMuxFilter->CheckVideoTransform(pmt,&m_pMuxFilter->m_pOutput->CurrentMediaType());
    } else {
        return hr;
    }
}

// set the media type for this connection

HRESULT
CMuxFilterVideoInputPin::SetMediaType(const CMediaType* mtIn)
{
    // Set the base class media type (should always succeed)
    HRESULT hr = CBasePin::SetMediaType(mtIn);
    if (FAILED(hr)) {
        return hr;
    }

    // check the transform can be done (should always succeed)
    ASSERT(SUCCEEDED(m_pMuxFilter->CheckVideoInputType(mtIn)));

    return m_pMuxFilter->SetMediaType(PINDIR_INPUT,mtIn);
}

// here's the next block of data from the stream.
// AddRef it yourself if you need to hold it beyond the end
// of this call.

HRESULT
CMuxFilterVideoInputPin::Receive(IMediaSample * pSample)
{
    HRESULT hr;
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("VideoReceive IN1")));
    CAutoLock lck(&m_pMuxFilter->m_csReceive);
    ASSERT(pSample);
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("VideoReceive IN2")));

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("VideoReceive IN3")));
    // check all is well with the base class
    hr = CBaseInputPin::Receive(pSample);
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("VideoReceive IN4")));

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("VideoReceive IN5")));
    if (S_OK == hr) {
        hr = m_pMuxFilter->VideoReceive(pSample);
    }
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("VideoReceive IN6")));
    return hr;
}


// =================================================================
// Implements the CMuxFilterAudioInputPin class
// =================================================================

// constructor

CMuxFilterAudioInputPin::CMuxFilterAudioInputPin(
    TCHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pName)
    : CMuxFilterInputPin(pObjectName, pMuxFilter, phr, pName)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterAudioInputPin::CMuxFilterAudioInputPin")));
    m_pMuxFilter = pMuxFilter;
}

#ifdef UNICODE
CMuxFilterAudioInputPin::CMuxFilterAudioInputPin(
    CHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pName)
    : CMuxFilterInputPin(pObjectName, pMuxFilter, &pMuxFilter->m_csFilter, phr, pName)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterAudioInputPin::CMuxFilterAudioInputPin")));
    m_pMuxFilter = pMuxFilter;
}
#endif

// check that we can support a given media type

HRESULT
CMuxFilterAudioInputPin::CheckMediaType(const CMediaType* pmt)
{
    // Check the input type

    HRESULT hr = m_pMuxFilter->CheckAudioInputType(pmt);
    if (S_OK != hr) {
        return hr;
    }

    // if the output pin is still connected, then we have
    // to check the transform not just the input format

    if ((m_pMuxFilter->m_pOutput != NULL) &&
        (m_pMuxFilter->m_pOutput->IsConnected())) {
            return m_pMuxFilter->CheckAudioTransform(pmt,&m_pMuxFilter->m_pOutput->CurrentMediaType());
    } else {
        return hr;
    }
}

// set the media type for this connection

HRESULT
CMuxFilterAudioInputPin::SetMediaType(const CMediaType* mtIn)
{
    // Set the base class media type (should always succeed)
    HRESULT hr = CBasePin::SetMediaType(mtIn);
    if (FAILED(hr)) {
        return hr;
    }

    // check the transform can be done (should always succeed)
    ASSERT(SUCCEEDED(m_pMuxFilter->CheckAudioInputType(mtIn)));

    return m_pMuxFilter->SetMediaType(PINDIR_INPUT,mtIn);
}

// here's the next block of data from the stream.
// AddRef it yourself if you need to hold it beyond the end
// of this call.

HRESULT
CMuxFilterAudioInputPin::Receive(IMediaSample * pSample)
{
    HRESULT hr;
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("AudioReceive IN1")));
    CAutoLock lck(&m_pMuxFilter->m_csReceive);
    ASSERT(pSample);
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("AudioReceive IN2")));
    
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("AudioReceive IN3")));
    // check all is well with the base class
	hr = CBaseInputPin::Receive(pSample);
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("AudioReceive IN4")));

DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("AudioReceive IN5")));
	if (S_OK == hr) {
        hr = m_pMuxFilter->AudioReceive(pSample);
    }
DbgLog((LOG_TRACE,TRACE_LEVEL,TEXT("AudioReceive IN6")));
    return hr;
}

// =================================================================
// Implements the CMuxFilterOutputPin class
// =================================================================


// constructor

CMuxFilterOutputPin::CMuxFilterOutputPin(
    TCHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pPinName)
    : CBaseOutputPin(pObjectName, pMuxFilter, &pMuxFilter->m_csFilter, phr, pPinName),
      m_pPosition(NULL)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterOutputPin::CMuxFilterOutputPin")));
    m_pMuxFilter = pMuxFilter;

}

#ifdef UNICODE
CMuxFilterOutputPin::CMuxFilterOutputPin(
    CHAR *pObjectName,
    CPieceMovieFileMuxFilter *pMuxFilter,
    HRESULT * phr,
    LPCWSTR pPinName)
    : CBaseOutputPin(pObjectName, pTransformFilter, &pTransformFilter->m_csFilter, phr, pPinName),
      m_pPosition(NULL)
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterOutputPin::CMuxFilterOutputPin")));
    m_pMuxFilter = pMuxFilter;

}
#endif

// destructor

CMuxFilterOutputPin::~CMuxFilterOutputPin()
{
    DbgLog((LOG_TRACE,2,TEXT("CMuxFilterOutputPin::~CMuxFilterOutputPin")));

    if (m_pPosition) m_pPosition->Release();
}


// overriden to expose IMediaPosition and IMediaSeeking control interfaces

STDMETHODIMP
CMuxFilterOutputPin::NonDelegatingQueryInterface(REFIID riid, void **ppv)
{
    CheckPointer(ppv,E_POINTER);
    ValidateReadWritePtr(ppv,sizeof(PVOID));
    *ppv = NULL;

    if (riid == IID_IMediaPosition || riid == IID_IMediaSeeking) {

        // we should have an input pin by now

        ASSERT(m_pMuxFilter->m_pVideoInput != NULL);
		ASSERT(m_pMuxFilter->m_pAudioInput != NULL);

        if (m_pPosition == NULL) {

            HRESULT hr = CreatePosPassThru(
                             GetOwner(),
                             FALSE,
                             (IPin *)m_pMuxFilter->m_pVideoInput,
                             &m_pPosition);
            if (FAILED(hr)) {
                return hr;
            }
        }
        return m_pPosition->QueryInterface(riid, ppv);
    } else {
        return CBaseOutputPin::NonDelegatingQueryInterface(riid, ppv);
    }
}


// provides derived filter a chance to grab extra interfaces

HRESULT
CMuxFilterOutputPin::CheckConnect(IPin *pPin)
{
    // we should have an input connection first

    ASSERT(m_pMuxFilter->m_pVideoInput != NULL);
    ASSERT(m_pMuxFilter->m_pAudioInput != NULL);
    if ((m_pMuxFilter->m_pVideoInput->IsConnected() == FALSE)) {
	    return E_UNEXPECTED;
    }

    HRESULT hr = m_pMuxFilter->CheckConnect(PINDIR_OUTPUT,pPin);
    if (FAILED(hr)) {
	    return hr;
    }
    return CBaseOutputPin::CheckConnect(pPin);
}


// provides derived filter a chance to release it's extra interfaces

HRESULT
CMuxFilterOutputPin::BreakConnect()
{
    //  Can't disconnect unless stopped
    ASSERT(IsStopped());
    m_pMuxFilter->BreakConnect(PINDIR_OUTPUT);
    return CBaseOutputPin::BreakConnect();
}


// Let derived class know when the output pin is connected

HRESULT
CMuxFilterOutputPin::CompleteConnect(IPin *pReceivePin)
{
    HRESULT hr = m_pMuxFilter->CompleteConnect(PINDIR_OUTPUT,pReceivePin);
    if (FAILED(hr)) {
        return hr;
    }
    return CBaseOutputPin::CompleteConnect(pReceivePin);
}


// check a given transform - must have selected input type first

HRESULT
CMuxFilterOutputPin::CheckMediaType(const CMediaType* pmtOut)
{
    // must have selected input first
    ASSERT(m_pMuxFilter->m_pVideoInput != NULL);
    ASSERT(m_pMuxFilter->m_pAudioInput != NULL);
    if ((m_pMuxFilter->m_pVideoInput->IsConnected() == FALSE)) {
	        return E_INVALIDARG;
    }

	//Video���̓s���͐ڑ��ς݂��H
	if(m_pMuxFilter->m_pVideoInput->IsConnected())
	{	
		return m_pMuxFilter->CheckVideoTransform(
				    &m_pMuxFilter->m_pVideoInput->CurrentMediaType(),
				    pmtOut);
	}
	//Audio���̓s���͐ڑ��ς݂��H
	else if(m_pMuxFilter->m_pAudioInput->IsConnected())
	{
		return m_pMuxFilter->CheckAudioTransform(
				    &m_pMuxFilter->m_pAudioInput->CurrentMediaType(),
				    pmtOut);
	}
	else return E_INVALIDARG;
}


// called after we have agreed a media type to actually set it in which case
// we run the CheckTransform function to get the output format type again

HRESULT
CMuxFilterOutputPin::SetMediaType(const CMediaType* pmtOut)
{
    HRESULT hr = NOERROR;
    ASSERT(m_pMuxFilter->m_pVideoInput != NULL);
	ASSERT(m_pMuxFilter->m_pAudioInput != NULL);
	
	if(m_pMuxFilter->m_pVideoInput->IsConnected())
	{
		ASSERT(m_pMuxFilter->m_pVideoInput->CurrentMediaType().IsValid());
	}
	if(m_pMuxFilter->m_pAudioInput->IsConnected())
	{
		ASSERT(m_pMuxFilter->m_pAudioInput->CurrentMediaType().IsValid());
	}

    // Set the base class media type (should always succeed)
    hr = CBasePin::SetMediaType(pmtOut);
    if (FAILED(hr)) {
        return hr;
    }

#ifdef DEBUG
	if(m_pMuxFilter->m_pVideoInput->IsConnected())
	{
		if (FAILED(m_pMuxFilter->CheckVideoTransform(&m_pMuxFilter->
				m_pVideoInput->CurrentMediaType(),pmtOut))) {
		DbgLog((LOG_ERROR,0,TEXT("*** This filter is accepting an output media type")));
		DbgLog((LOG_ERROR,0,TEXT("    that it can't currently video-transform to.  I hope")));
		DbgLog((LOG_ERROR,0,TEXT("    it's smart enough to reconnect its video-input.")));
	    }
	}
	if(m_pMuxFilter->m_pAudioInput->IsConnected())
	{
		if (FAILED(m_pMuxFilter->CheckAudioTransform(&m_pMuxFilter->
				m_pAudioInput->CurrentMediaType(),pmtOut))) {
		DbgLog((LOG_ERROR,0,TEXT("*** This filter is accepting an output media type")));
		DbgLog((LOG_ERROR,0,TEXT("    that it can't currently audio-transform to.  I hope")));
		DbgLog((LOG_ERROR,0,TEXT("    it's smart enough to reconnect its audio-input.")));
	    }
	}
#endif

    return m_pMuxFilter->SetMediaType(PINDIR_OUTPUT,pmtOut);
}


// pass the buffer size decision through to the main transform class

HRESULT
CMuxFilterOutputPin::DecideBufferSize(
    IMemAllocator * pAllocator,
    ALLOCATOR_PROPERTIES* pProp)
{
    return m_pMuxFilter->DecideBufferSize(pAllocator, pProp);
}



// return a specific media type indexed by iPosition

HRESULT
CMuxFilterOutputPin::GetMediaType(
    int iPosition,
    CMediaType *pMediaType)
{
    ASSERT(m_pMuxFilter->m_pVideoInput != NULL);
	ASSERT(m_pMuxFilter->m_pAudioInput != NULL);

    //  We don't have any media types if our input is not connected

    if (m_pMuxFilter->m_pVideoInput->IsConnected()) {
        return m_pMuxFilter->GetMediaType(iPosition,pMediaType);
    } else {
        return VFW_S_NO_MORE_ITEMS;
    }
}


// Override this if you can do something constructive to act on the
// quality message.  Consider passing it upstream as well

// Pass the quality mesage on upstream.

STDMETHODIMP
CMuxFilterOutputPin::Notify(IBaseFilter * pSender, Quality q)
{
    UNREFERENCED_PARAMETER(pSender);
    ValidateReadPtr(pSender,sizeof(IBaseFilter));

    // First see if we want to handle this ourselves
    HRESULT hr = m_pMuxFilter->AlterQuality(q);
    if (hr!=S_FALSE) {
        return hr;        // either S_OK or a failure
    }

    // S_FALSE means we pass the message on.
    // Find the quality sink for our input pin and send it there

    ASSERT(m_pMuxFilter->m_pVideoInput != NULL);
	ASSERT(m_pMuxFilter->m_pAudioInput != NULL);

    return m_pMuxFilter->m_pVideoInput->PassNotify(q);

} // Notify


// the following removes a very large number of level 4 warnings from the microsoft
// compiler output, which are not useful at all in this case.
#pragma warning(disable:4514)
