//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PMF_Convertor.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PMF_CONVERTOR_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_FRAME_INPUT                 1000
#define IDC_FRAME_OUTPUT                1001
#define IDC_BUTTON_OUTDIR               1002
#define IDC_LABEL_INPUT_FILE_PATH       1003
#define IDC_LABEL_OUTPUT_FILEPATH       1004
#define IDC_BUTTON_RUN                  1005
#define IDC_LABEL_HP                    1007
#define IDC_LABEL_MESSAGE               1008
#define IDC_FRAME_TITLE                 1009
#define IDC_FRAME_MEDIA_INFO            1010
#define IDC_LABEL_STREAM_TITLE          1011
#define IDC_LABEL_MEDIA_INFO            1011
#define IDC_COMBO_SAMPLE_LEN            1012
#define IDC_FRAME_OUT_OPTION            1013
#define IDC_LABEL_OUT_OFFSET            1014
#define IDC_EDIT_OUT_OFFSET             1015
#define IDC_SPIN_OUT_OFFSET             1016
#define IDC_CHECK_OUT_SAMPLE_LEN        1017
#define IDC_LABEL_SAMPLE_HELP           1018
#define IDC_CHECK1                      1019
#define IDC_CHECK_AUTO_CONTRAST         1019
#define IDC_CHECK_AUTO_CONTRAST2        1020
#define IDC_CHECK_GAMMA_CORRECT         1020
#define IDC_PROGRESS1                   1021
#define IDC_PROGRESS                    1021
#define IDC_LABEL_SAMPLE_HELP2          1022
#define IDC_LABEL_CONTRAST_HELP         1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
